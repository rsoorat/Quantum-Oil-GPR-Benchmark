import pandas as pd
import numpy as np
import yaml

def main():
    print("=== Step 3: Feature Engineering (HAR-RV, Exogenous Controls, Strict Lags) ===")
    
    # Load configuration
    with open("config.yaml", "r") as f:
        config = yaml.safe_load(f)
        
    clean_path = config['data']['clean_wti_path']
    output_path = config['data']['oil_model_dataset_path']
    vol_target_window = config['models']['volatility_target_window']
    
    # Load cleaned dataset
    df = pd.read_csv(clean_path)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    
    # 1. Handling of Negative WTI Price (2020-04-20)
    # The negative settlement price of -$36.98/bbl on 2020-04-20 was an idiosyncratic delivery constraint event.
    # To maintain continuous, mathematically valid logarithmic returns ln(P_t/P_{t-1}), we interpolate the negative
    # price using the surrounding valid trading prices (2020-04-17: $18.27, 2020-04-21: $10.01 -> $14.14).
    df['WTI_adj'] = df['WTI'].copy()
    neg_mask = df['WTI_adj'] <= 0
    neg_indices = df[neg_mask].index
    for idx in neg_indices:
        prev_val = df.loc[idx - 1, 'WTI_adj'] if idx > 0 else np.nan
        next_val = df.loc[idx + 1, 'WTI_adj'] if idx < len(df) - 1 else np.nan
        df.loc[idx, 'WTI_adj'] = np.nanmean([prev_val, next_val])
        print(f"  Adjusted negative WTI price on {df.loc[idx, 'date'].strftime('%Y-%m-%d')} from {df.loc[idx, 'WTI']} to {df.loc[idx, 'WTI_adj']:.2f}")
        
    # 2. Compute Log Returns: R_t = 100 * ln(P_t / P_{t-1})
    df['WTI_Return'] = 100 * np.log(df['WTI_adj'] / df['WTI_adj'].shift(1))
    df = df.dropna(subset=['WTI_Return']).reset_index(drop=True)
    
    # 3. Compute Realized Volatility Targets
    # Daily 1-day realized volatility proxy (absolute return / rolling std)
    df['Daily_Vol'] = np.abs(df['WTI_Return'])
    # Primary target: 5-day rolling standard deviation of daily returns
    df['Target_Vol'] = df['WTI_Return'].rolling(window=vol_target_window).std()
    
    # HAR Components (Corsi, 2009): Daily, Weekly (5-day), Monthly (22-day)
    df['HAR_d'] = df['Target_Vol']
    df['HAR_w'] = df['Target_Vol'].rolling(5).mean()
    df['HAR_m'] = df['Target_Vol'].rolling(22).mean()
    
    # 4. Generate Strict Lagged Predictors (F_{t-1} Information Set - Zero Look-Ahead Bias)
    # Volatility Lags
    df['Vol_Lag1'] = df['Target_Vol'].shift(1)
    df['Vol_Lag2'] = df['Target_Vol'].shift(2)
    df['HAR_d_Lag1'] = df['HAR_d'].shift(1)
    df['HAR_w_Lag1'] = df['HAR_w'].shift(1)
    df['HAR_m_Lag1'] = df['HAR_m'].shift(1)
    
    # Return Lags
    df['Return_Lag1'] = df['WTI_Return'].shift(1)
    df['Return_Lag2'] = df['WTI_Return'].shift(2)
    
    # Geopolitical Risk Predictors (Strictly Lagged)
    df['GPRD_Lag1'] = df['GPRD'].shift(1)
    df['GPRD_ACT_Lag1'] = df['GPRD_ACT'].shift(1)
    df['GPRD_THREAT_Lag1'] = df['GPRD_THREAT'].shift(1)
    df['GPRD_Diff_Lag1'] = df['GPRD'].diff().shift(1)
    df['GPR_AI_Lag1'] = df['GPR_AI'].shift(1)
    df['GPR_OIL_Lag1'] = df['GPR_OIL'].shift(1)
    df['GPR_AI_Diff_Lag1'] = df['GPR_AI'].diff().shift(1)
    
    # Financial Market Controls (Strictly Lagged Returns / Changes)
    df['VIX_Lag1'] = df['VIX'].shift(1)
    df['VIX_Diff_Lag1'] = df['VIX'].diff().shift(1)
    df['Gold_Return_Lag1'] = (100 * np.log(df['Gold'] / df['Gold'].shift(1))).shift(1)
    df['Dollar_Return_Lag1'] = (100 * np.log(df['DollarIndex'] / df['DollarIndex'].shift(1))).shift(1)
    df['Gas_Return_Lag1'] = (100 * np.log(df['NaturalGas'] / df['NaturalGas'].shift(1))).shift(1)
    df['Brent_Return_Lag1'] = (100 * np.log(df['BrentCrude'] / df['BrentCrude'].shift(1))).shift(1)
    df['Treasury_Diff_Lag1'] = df['TreasuryYield'].diff().shift(1)
    
    # Technical Indicators (Strictly Lagged)
    df['MA5_Ret'] = df['WTI_Return'].rolling(5).mean()
    df['MA20_Ret'] = df['WTI_Return'].rolling(20).mean()
    df['MA_Cross_Lag1'] = (df['MA5_Ret'] - df['MA20_Ret']).shift(1)
    df['Momentum_Lag1'] = (df['WTI_adj'].shift(1) - df['WTI_adj'].shift(6))
    
    # Clean NaNs caused by rolling and lagging
    df_clean = df.dropna().reset_index(drop=True)
    
    # Save dataset
    df_clean.to_csv(output_path, index=False)
    print(f"Feature engineered dataset saved to {output_path}. Shape: {df_clean.shape}")
    print(f"Date range: {df_clean['date'].min().strftime('%Y-%m-%d')} to {df_clean['date'].max().strftime('%Y-%m-%d')} (Total: {len(df_clean)} trading days)")

if __name__ == "__main__":
    main()
