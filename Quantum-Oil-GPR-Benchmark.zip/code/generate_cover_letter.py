import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
import subprocess
import os

def generate_cover_letter_tex():
    tex_content = r"""\documentclass[10pt,a4paper]{article}
\usepackage[top=0.65in,bottom=0.65in,left=0.75in,right=0.75in]{geometry}
\usepackage{amsmath}
\usepackage{charter}
\usepackage{xurl}
\usepackage[colorlinks=true,linkcolor=blue,citecolor=blue,urlcolor=blue]{hyperref}
\usepackage{microtype}
\usepackage{setspace}

\singlespacing

\begin{document}

\noindent \textbf{Dr. Uvesh Husain} (Corresponding Author) \\
Associate Professor, Economics and Business Studies Department, Mazoon College, Muscat, Sultanate of Oman \\
\textit{Email:} \href{mailto:u78.husain@gmail.com}{u78.husain@gmail.com} \\[0.2em]
\noindent \textbf{Co-Authors:} \\
\textbf{Ram Soorat} (\href{mailto:rsoorat@gmail.com}{rsoorat@gmail.com}, Woxsen University), 
\textbf{Afzalur Rahman} (\href{mailto:afzalur.rahman@woxsen.edu.in}{afzalur.rahman@woxsen.edu.in}, Woxsen University), \\
\textbf{Priyanka} (\href{mailto:priyanka292c@gmail.com}{priyanka292c@gmail.com}, University of Delhi)

\vspace{0.35em}
\hrule
\vspace{0.45em}

\noindent \today

\vspace{0.35em}

\noindent \textbf{To:} \\
The Editor-in-Chief / Section Editor (Banking, Finance \& Risk Management) \\
\textit{Cogent Business \& Management} \\
Taylor \& Francis Group / Cogent OA (ISSN: 2331-1975)

\vspace{0.35em}

\noindent \textbf{Subject: Submission of Original Research Article for Peer Review}

\vspace{0.35em}

\noindent Dear Editor and Editorial Board Members,

\vspace{0.25em}

\noindent We are pleased to submit our original research manuscript entitled:
\begin{center}
\textbf{``Quantum Kernel Regression and Geopolitical Risk in Crude Oil Volatility Forecasting: An Empirical Out-of-Sample Benchmark''}
\end{center}
for consideration for publication as a Research Article in \textit{Cogent Business \& Management} (Section: Banking, Finance \& Risk Management).

\vspace{0.25em}
\noindent \textbf{Aim, Scope \& Major Empirical Contributions:} \\
Predicting crude oil volatility under geopolitical uncertainty is vital for energy risk surveillance, portfolio allocation, and macroeconomic stabilization. This study delivers the first large-scale empirical out-of-sample benchmark (2016--2026, $N = 2,473$ clean trading days, 655-day test window) evaluating a 4-qubit Parameterized Quantum Circuit (PQC) kernel regression model (QSVR) against twelve classical econometric and machine learning benchmarks (HAR-RV, GARCH, EGARCH, GJR-GARCH, ElasticNet, SVR, Random Forest, XGBoost, LightGBM, LSTM):
\begin{itemize}\itemsep=0.12em \parsep=0pt
    \item \textbf{Loss-Dependent Forecasting Hierarchy:} Linear specifications (HAR-RV, $\text{RMSE} = 0.6708$; SVR-Linear, $\text{RMSE} = 0.6717$) dominate point forecasts under RMSE, while tree ensembles excel under asymmetric QLIKE loss (XGBoost, $\text{QLIKE} = 0.1574$). Diebold-Mariano tests with FDR adjustments ($p_{\text{FDR}} = 0.1712$) confirm no statistical point superiority for QSVR over linear benchmarks.
    \item \textbf{Controlled Quantum Kernel Representation:} On identical 4-feature inputs, the quantum kernel ($\text{RMSE} = 0.7007$) improves over Gaussian RBF ($\text{RMSE} = 0.7140$), providing a rich non-linear representation in Hilbert-Schmidt operator space.
    \item \textbf{Econometric Role of Geopolitical Risk:} In dynamic multivariate HAC regressions (VIF $< 3.0$), lagged GPR is not an incremental daily point predictor ($\beta = 0.0008, p = 0.1544$), functioning primarily as a regime-stratification and stress-testing variable.
    \item \textbf{Risk Management \& Portfolio Utility:} Parametric Student-$t$ GARCH models achieve near-nominal 95\% VaR coverage ($4.73\%$--$4.89\%$). QSVR VaR exceedances satisfy temporal independence (Christoffersen $p = 0.5904$). In dynamic volatility targeting, the QSVR strategy achieves $+8.91\%$ net return vs $-3.86\%$ for buy-and-hold.
\end{itemize}

\vspace{0.25em}
\noindent \textbf{Declarations:} The manuscript is original, has not been published, and is not under review elsewhere. All authors have approved submission with no conflicts of interest. All data, quantum circuits, and code are open-access: \url{https://github.com/Antigravity-Research/Quantum-Oil-GPR-Benchmark}.

\vspace{0.25em}
\noindent \textbf{Suggested Reviewers:} (1) Prof. Matteo Iacoviello (Federal Reserve Board); (2) Prof. Fulvio Corsi (Univ. of Pisa); (3) Prof. Andrew J. Patton (Duke Univ.); (4) Prof. Maria Schuld (Xanadu / Univ. of KwaZulu-Natal).

\vspace{0.4em}

\noindent Sincerely,

\vspace{0.2em}

\noindent \textbf{Dr. Uvesh Husain} (On behalf of all authors) \\
Associate Professor, Economics and Business Studies Department, Mazoon College, Muscat, Sultanate of Oman \\
\textit{Email:} \href{mailto:u78.husain@gmail.com}{u78.husain@gmail.com}

\end{document}
"""
    with open("cover_letter.tex", "w", encoding="utf-8") as f:
        f.write(tex_content)
    print("Cover letter LaTeX file generated: cover_letter.tex")

def generate_cover_letter_docx():
    doc = docx.Document()
    for section in doc.sections:
        section.top_margin = Inches(0.65)
        section.bottom_margin = Inches(0.65)
        section.left_margin = Inches(0.75)
        section.right_margin = Inches(0.75)
        
    p_hdr = doc.add_paragraph()
    r = p_hdr.add_run("Dr. Uvesh Husain (Corresponding Author)\n")
    r.font.bold = True
    r.font.size = Pt(10.5)
    p_hdr.add_run("Associate Professor, Economics and Business Studies Department, Mazoon College, Muscat, Sultanate of Oman\nEmail: u78.husain@gmail.com\n\n").font.size = Pt(9.5)
    
    r_co = p_hdr.add_run("Co-Authors: ")
    r_co.font.bold = True
    r_co.font.size = Pt(9.5)
    p_hdr.add_run("Ram Soorat (rsoorat@gmail.com, Woxsen University), Afzalur Rahman (afzalur.rahman@woxsen.edu.in, Woxsen University), Priyanka (priyanka292c@gmail.com, University of Delhi)\n").font.size = Pt(9.0)
    p_hdr.paragraph_format.space_after = Pt(4)
    
    p_date = doc.add_paragraph()
    p_date.add_run("August 23, 2026").font.size = Pt(10)
    p_date.paragraph_format.space_after = Pt(4)
    
    p_to = doc.add_paragraph()
    r_to = p_to.add_run("To:\nThe Editor-in-Chief / Section Editor (Banking, Finance & Risk Management)\nCogent Business & Management\nTaylor & Francis Group / Cogent OA (ISSN: 2331-1975)\n")
    r_to.font.bold = True
    r_to.font.size = Pt(10)
    p_to.paragraph_format.space_after = Pt(4)
    
    p_subj = doc.add_paragraph()
    r_sub = p_subj.add_run("Subject: Submission of Original Research Article for Peer Review")
    r_sub.font.bold = True
    r_sub.font.size = Pt(10.5)
    r_sub.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D)
    p_subj.paragraph_format.space_after = Pt(4)
    
    p_body = doc.add_paragraph()
    p_body.paragraph_format.line_spacing = 1.12
    p_body.add_run("Dear Editor and Editorial Board Members,\n\nWe are pleased to submit our original research manuscript entitled:\n\n")
    
    p_title = doc.add_paragraph()
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r_t = p_title.add_run("“Quantum Kernel Regression and Geopolitical Risk in Crude Oil Volatility Forecasting:\nAn Empirical Out-of-Sample Benchmark”")
    r_t.font.bold = True
    r_t.font.size = Pt(10.5)
    r_t.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D)
    p_title.paragraph_format.space_after = Pt(4)
    
    p_main = doc.add_paragraph()
    p_main.paragraph_format.line_spacing = 1.12
    p_main.add_run("for consideration for publication as a Research Article in Cogent Business & Management (Section: Banking, Finance & Risk Management).\n\n")
    
    r_c = p_main.add_run("Aim, Scope & Major Empirical Contributions:\n")
    r_c.font.bold = True
    p_main.add_run("Predicting crude oil volatility under geopolitical uncertainty is vital for energy risk surveillance, portfolio allocation, and macroeconomic stabilization. This study delivers the first large-scale empirical out-of-sample benchmark (2016–2026, N = 2,473 clean trading days, 655-day test window) evaluating a 4-qubit Parameterized Quantum Circuit (PQC) kernel regression model (QSVR) against twelve classical econometric and machine learning benchmarks (HAR-RV, GARCH, EGARCH, GJR-GARCH, ElasticNet, SVR, Random Forest, XGBoost, LightGBM, LSTM):\n"
                   "• Loss-Dependent Forecasting Hierarchy: Linear specifications (HAR-RV, RMSE 0.6708; SVR-Linear, RMSE 0.6717) dominate point forecasts under RMSE, while tree ensembles excel under asymmetric QLIKE loss (XGBoost, QLIKE 0.1574). Diebold-Mariano tests with FDR adjustments (pFDR = 0.1712) confirm no statistical point superiority for QSVR over linear benchmarks.\n"
                   "• Controlled Quantum Kernel Representation: On identical 4-feature inputs, the quantum kernel (RMSE 0.7007) improves over Gaussian RBF (RMSE 0.7140), providing a rich non-linear representation in Hilbert-Schmidt operator space.\n"
                   "• Econometric Role of Geopolitical Risk: In dynamic multivariate HAC regressions (VIF < 3.0), lagged GPR is not an incremental daily point predictor (beta = 0.0008, p = 0.1544), functioning primarily as a regime-stratification and stress-testing variable.\n"
                   "• Risk Management & Portfolio Utility: Parametric Student-t GARCH models achieve near-nominal 95% VaR coverage (4.73%–4.89%). QSVR VaR exceedances satisfy temporal independence (Christoffersen p = 0.5904). Dynamic volatility targeting with QSVR achieves +8.91% net return vs -3.86% for buy-and-hold.\n\n")
    
    r_dec = p_main.add_run("Declarations: ")
    r_dec.font.bold = True
    p_main.add_run("The manuscript is original, has not been published, and is not under review elsewhere. All authors have approved submission with no conflicts of interest. Open-access repository: https://github.com/rsoorat/Quantum-Oil-GPR-Benchmark.\n\n")
    
    r_rev = p_main.add_run("Suggested Potential Reviewers: ")
    r_rev.font.bold = True
    p_main.add_run("(1) Prof. Matteo Iacoviello (Federal Reserve Board); (2) Prof. Fulvio Corsi (Univ. of Pisa); (3) Prof. Andrew J. Patton (Duke Univ.); (4) Prof. Maria Schuld (Xanadu / Univ. of KwaZulu-Natal).\n\n")
    
    p_main.add_run("Sincerely,\n\n")
    r_sig = p_main.add_run("Dr. Uvesh Husain (On behalf of all authors)\n")
    r_sig.font.bold = True
    p_main.add_run("Associate Professor, Economics and Business Studies Department, Mazoon College, Muscat, Sultanate of Oman\nEmail: u78.husain@gmail.com")
    
    doc.save("Cover_Letter.docx")
    print("Cover letter Word file generated: Cover_Letter.docx")

def main():
    print("=== Generating Journal Submission Cover Letter ===")
    generate_cover_letter_tex()
    generate_cover_letter_docx()

if __name__ == "__main__":
    main()
