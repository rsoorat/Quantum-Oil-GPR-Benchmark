import openpyxl
import os

def load_table_as_latex(ws, label, caption, custom_headers=None, max_rows=None, is_wide=False):
    all_rows = list(ws.iter_rows(values_only=True))
    if not all_rows:
        return ""
    
    if len(all_rows) > 2 and all_rows[0][0] and str(all_rows[0][0]).startswith("Table "):
        headers = list(all_rows[2])
        data_rows = all_rows[3:]
    else:
        headers = list(all_rows[0])
        data_rows = all_rows[1:]
        
    if custom_headers:
        headers = custom_headers
        
    if headers and (headers[0] is None or str(headers[0]).strip() == '' or str(headers[0]).lower() == 'nan'):
        headers[0] = 'Model / Benchmark'
        
    n_cols = len(headers)
    if max_rows:
        data_rows = data_rows[:max_rows]
        
    clean_headers = []
    for h in headers:
        h_str = "" if h is None else str(h)
        h_str = h_str.replace('$', r'\$').replace('%', r'\%').replace('_', r'\_').replace('&', r'\&').replace('^', r'\textasciicircum{}').replace('<', r'$<$').replace('>', r'$>$')
        clean_headers.append(r"\textbf{" + h_str + r"}")
    header_str = " & ".join(clean_headers) + r" \\"
    
    rows_str = []
    for row in data_rows:
        row_cells = []
        for i, val in enumerate(row):
            col_name = str(headers[i]) if i < len(headers) and headers[i] is not None else ""
            if val is None or str(val).strip().lower() == 'nan':
                txt = "--"
            elif isinstance(val, (int, float)):
                if isinstance(val, int) or (isinstance(val, float) and val.is_integer() and col_name in ['Observations', '95% VaR Breaches', 'Breaches', 'Observations (Trading Days)', 'QSVR 95% VaR Breaches', 'VaR Breaches', 'Matrix Rank']):
                    txt = f"{int(val):,}"
                elif abs(val) < 0.0001 and val != 0:
                    txt = f"{val:.2e}"
                elif abs(val) < 1.0:
                    txt = f"{val:.4f}"
                elif abs(val) < 100.0:
                    txt = f"{val:.4f}"
                else:
                    txt = f"{val:,.2f}"
            else:
                txt = str(val).replace('$', r'\$').replace('%', r'\%').replace('_', r'\_').replace('&', r'\&').replace('^', r'\textasciicircum{}').replace('<', r'$<$').replace('>', r'$>$')
            row_cells.append(txt)
        rows_str.append(" & ".join(row_cells) + r" \\")
        
    body_str = "\n".join(rows_str)
    clean_caption = str(caption).replace('%', r'\%').replace('_', r'\_').replace('&', r'\&')
    
    wide_open = r"\begin{table*}[htbp]" if is_wide else r"\begin{table}[htbp]"
    wide_close = r"\end{table*}" if is_wide else r"\end{table}"
    
    # Specific column width formatting for descriptive/text-heavy tables
    if label == "tab:variables":
        return r"""\begin{table*}[htbp]
\centering
\small
\caption{""" + clean_caption + r"""}
\label{""" + label + r"""}
\begin{tabularx}{\textwidth}{p{2.3cm}p{3.8cm}p{2.8cm}>{\raggedright\arraybackslash}X}
\toprule
""" + header_str + r"""
\midrule
""" + body_str + r"""
\bottomrule
\end{tabularx}
\end{table*}"""

    if label == "tab:splits":
        return r"""\begin{table*}[htbp]
\centering
\small
\caption{""" + clean_caption + r"""}
\label{""" + label + r"""}
\begin{tabularx}{\textwidth}{p{3.2cm}p{2.6cm}p{2.6cm}p{2.8cm}>{\raggedright\arraybackslash}X}
\toprule
""" + header_str + r"""
\midrule
""" + body_str + r"""
\bottomrule
\end{tabularx}
\end{table*}"""

    if label == "tab:ml_configs":
        return r"""\begin{table*}[htbp]
\centering
\small
\caption{""" + clean_caption + r"""}
\label{""" + label + r"""}
\begin{tabularx}{\textwidth}{p{2.8cm}p{6.5cm}>{\raggedright\arraybackslash}X}
\toprule
""" + header_str + r"""
\midrule
""" + body_str + r"""
\bottomrule
\end{tabularx}
\end{table*}"""

    if label == "tab:quantum_configs":
        return r"""\begin{table*}[htbp]
\centering
\small
\caption{""" + clean_caption + r"""}
\label{""" + label + r"""}
\begin{tabularx}{\textwidth}{p{3.5cm}p{4.5cm}>{\raggedright\arraybackslash}X}
\toprule
""" + header_str + r"""
\midrule
""" + body_str + r"""
\bottomrule
\end{tabularx}
\end{table*}"""

    if label == "tab:hyp_summary":
        return r"""\begin{table*}[htbp]
\centering
\small
\caption{""" + clean_caption + r"""}
\label{""" + label + r"""}
\begin{tabularx}{\textwidth}{p{2.6cm}p{3.4cm}p{4.2cm}>{\raggedright\arraybackslash}X}
\toprule
""" + header_str + r"""
\midrule
""" + body_str + r"""
\bottomrule
\end{tabularx}
\end{table*}"""

    # Custom Clean Formatting for Table 10 (tab:kernel_props)
    if label == "tab:kernel_props":
        return r"""\begin{table*}[htbp]
\centering
\small
\caption{Quantum vs. Classical Kernel Geometric Properties and Target Alignment}
\label{tab:kernel_props}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lcccc}
\toprule
\textbf{Kernel Architecture} & \textbf{Kernel-Target Alignment $A(K, \mathbf{y})$} & \textbf{Effective Dimension} & \textbf{Matrix Rank} & \textbf{Condition Number $\kappa(K)$} \\
\midrule
Linear Kernel & 0.4753 & 1.4570 & 4 & $4.89 \times 10^{15}$ \\
Polynomial ($d=2$) Kernel & 0.4841 & 1.6177 & 15 & $5.00 \times 10^{15}$ \\
Gaussian RBF Kernel & 0.2658 & 3.2302 & 239 & $1.15 \times 10^{15}$ \\
Quantum PQC (4-Qubit) Kernel & 0.3178 & 1.6868 & 67 & $1.40 \times 10^{15}$ \\
\bottomrule
\end{tabular}%
}
\end{table*}"""

    # Custom Clean Formatting for Table 11 (tab:qreg_sens)
    if label == "tab:qreg_sens":
        return r"""\begin{table*}[htbp]
\centering
\small
\caption{Numerical Stability and Tikhonov Ridge Regularization Sensitivity Analysis for QSVR Gram Matrix}
\label{tab:qreg_sens}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lcccc}
\toprule
\textbf{Ridge Regularization $\lambda$} & \textbf{Condition Number $\kappa(K_{\text{reg}})$} & \textbf{Out-of-Sample RMSE} & \textbf{Out-of-Sample $R^2$} & \textbf{95\% VaR Breaches} \\
\midrule
$10^{-7}$ & $1.40 \times 10^{15}$ & 0.7007 & 0.7600 & 51 \\
$10^{-5}$ (Baseline) & $1.00 \times 10^{5}$ & 0.7007 & 0.7600 & 51 \\
$10^{-4}$ & $1.00 \times 10^{4}$ & 0.7008 & 0.7599 & 51 \\
$10^{-3}$ & $1.00 \times 10^{3}$ & 0.7012 & 0.7596 & 51 \\
$10^{-2}$ & $1.00 \times 10^{2}$ & 0.7045 & 0.7574 & 52 \\
\bottomrule
\end{tabular}%
}
\end{table*}"""

    # Custom Clean Formatting for Table 17 (tab:robustness) - 13 rows pivoted
    if label == "tab:robustness":
        return r"""\begin{table*}[htbp]
\centering
\small
\caption{Alternative Geopolitical Risk Percentile Threshold Robustness Checks (80th and 90th Percentiles)}
\label{tab:robustness}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lrrrr}
\toprule
\multirow{2}{*}{\textbf{Model / Benchmark}} & \multicolumn{2}{c}{\textbf{80th Percentile Cutoff (149.51)}} & \multicolumn{2}{c}{\textbf{90th Percentile Cutoff (180.53)}} \\
\cmidrule(lr){2-3} \cmidrule(lr){4-5}
 & \textbf{Normal ($N=295$)} & \textbf{High-Risk ($N=360$)} & \textbf{Normal ($N=476$)} & \textbf{High-Risk ($N=179$)} \\
\midrule
HAR-RV & 0.5058 & 0.7803 & 0.4783 & 0.9533 \\
GARCH(1,1) & 0.6611 & 0.9067 & 0.6475 & 1.0606 \\
EGARCH(1,1) & 0.6490 & 0.9170 & 0.6421 & 1.0718 \\
GJR-GARCH(1,1) & 0.6836 & 1.0212 & 0.6733 & 1.2120 \\
ElasticNet & 0.5208 & 0.8207 & 0.4966 & 1.0011 \\
SVR-Linear & 0.5077 & 0.7808 & 0.4794 & 0.9542 \\
SVR-Poly & 0.8228 & 1.6465 & 0.9051 & 1.9544 \\
SVR-RBF & 0.6215 & 1.1063 & 0.6605 & 1.3033 \\
Random Forest & 0.6036 & 0.7964 & 0.5533 & 0.9703 \\
XGBoost & 0.5452 & 0.8412 & 0.5229 & 1.0199 \\
LightGBM & 0.5567 & 0.8855 & 0.5230 & 1.0895 \\
PyTorch LSTM & 0.6109 & 0.8280 & 0.5957 & 0.9692 \\
QSVR (4-Qubit) & 0.5239 & 0.8175 & 0.4897 & 1.0060 \\
\bottomrule
\end{tabular}%
}
\end{table*}"""

    # Custom Clean Formatting for Table 13 (tab:regimes) - 13 rows pivoted
    if label == "tab:regimes":
        return r"""\begin{table*}[htbp]
\centering
\small
\caption{Out-of-Sample Forecasting RMSE across Geopolitical Risk Regimes (Pre-Test Thresholds with 95\% Bootstrap CIs)}
\label{tab:regimes}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lccc}
\toprule
\textbf{Model / Benchmark} & \textbf{Low GPR ($N=80$)} & \textbf{Medium GPR ($N=162$)} & \textbf{High GPR ($N=413$)} \\
\midrule
HAR-RV & 0.4940 [0.3377, 0.6383] & 0.5034 [0.4218, 0.5927] & 0.7529 [0.6064, 0.8997] \\
GARCH(1,1) & 0.6641 [0.5645, 0.7701] & 0.6290 [0.5468, 0.7239] & 0.8878 [0.7788, 1.0028] \\
EGARCH(1,1) & 0.6394 [0.5499, 0.7238] & 0.6247 [0.5531, 0.6997] & 0.8955 [0.7850, 1.0076] \\
GJR-GARCH(1,1) & 0.7150 [0.5987, 0.8243] & 0.6558 [0.5605, 0.7479] & 0.9884 [0.8654, 1.1118] \\
ElasticNet & 0.4916 [0.3367, 0.6361] & 0.5239 [0.4426, 0.6105] & 0.7905 [0.6324, 0.9504] \\
SVR-Linear & 0.4936 [0.3347, 0.6406] & 0.5049 [0.4202, 0.5915] & 0.7534 [0.6059, 0.9062] \\
SVR-Poly & 0.6880 [0.5707, 0.8099] & 0.8679 [0.7500, 1.0047] & 1.5666 [1.3283, 1.8315] \\
SVR-RBF & 0.5650 [0.4191, 0.7148] & 0.6310 [0.5318, 0.7341] & 1.0601 [0.8778, 1.2585] \\
Random Forest & 0.5123 [0.3722, 0.6500] & 0.6372 [0.5155, 0.7594] & 0.7738 [0.6493, 0.8988] \\
XGBoost & 0.4681 [0.3194, 0.6205] & 0.5744 [0.4584, 0.7038] & 0.8090 [0.6872, 0.9328] \\
LightGBM & 0.4794 [0.3279, 0.6217] & 0.5878 [0.4662, 0.7152] & 0.8509 [0.7176, 0.9930] \\
PyTorch LSTM & 0.5932 [0.4493, 0.7497] & 0.6179 [0.5265, 0.7287] & 0.8010 [0.6534, 0.9515] \\
QSVR (4-Qubit) & 0.4840 [0.3295, 0.6341] & 0.5342 [0.4547, 0.6191] & 0.7872 [0.6506, 0.9368] \\
\bottomrule
\end{tabular}%
}
\end{table*}"""

    # Custom Clean Formatting for Table 18 (tab:cost_sens)
    if label == "tab:cost_sens":
        return r"""\begin{table*}[htbp]
\centering
\small
\caption{Transaction Cost Sensitivity Analysis for Volatility-Targeting Strategy (1 to 20 bps)}
\label{tab:cost_sens}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lrrrrrrrrrr}
\toprule
\multirow{2}{*}{\textbf{Cost}} & \multicolumn{2}{c}{\textbf{HAR-RV}} & \multicolumn{2}{c}{\textbf{SVR-Linear}} & \multicolumn{2}{c}{\textbf{QSVR}} & \multicolumn{2}{c}{\textbf{ElasticNet}} & \multicolumn{2}{c}{\textbf{SVR-RBF}} \\
\cmidrule(lr){2-3} \cmidrule(lr){4-5} \cmidrule(lr){6-7} \cmidrule(lr){8-9} \cmidrule(lr){10-11}
\textbf{(bps)} & \textbf{Sharpe} & \textbf{Return} & \textbf{Sharpe} & \textbf{Return} & \textbf{Sharpe} & \textbf{Return} & \textbf{Sharpe} & \textbf{Return} & \textbf{Sharpe} & \textbf{Return} \\
\midrule
1 bps & 0.3607 & +12.98\% & 0.3424 & +11.95\% & 0.3274 & +11.13\% & 0.3204 & +10.82\% & 0.3307 & +11.26\% \\
5 bps & 0.2981 & +10.64\% & 0.2804 & +9.63\% & 0.2678 & +8.91\% & 0.2593 & +8.53\% & 0.2718 & +8.47\% \\
10 bps & 0.2198 & +7.71\% & 0.2023 & +6.73\% & 0.1927 & +6.14\% & 0.1825 & +5.68\% & 0.1980 & +5.08\% \\
20 bps & 0.0626 & +1.86\% & 0.0457 & +0.94\% & 0.0428 & +0.59\% & 0.0310 & -0.04\% & 0.0503 & -1.38\% \\
\bottomrule
\end{tabular}%
}
\end{table*}"""

    # Custom Clean Formatting for Table 15 (tab:risk_mgmt)
    if label == "tab:risk_mgmt":
        return r"""\begin{table*}[htbp]
\centering
\small
\caption{""" + clean_caption + r"""}
\label{""" + label + r"""}
\resizebox{\textwidth}{!}{%
\begin{tabular}{llrrrrrrrr}
\toprule
\textbf{Model} & \textbf{Distribution} & \textbf{Breaches} & \textbf{Rate (\%)} & \textbf{Kupiec LR} & \textbf{Kupiec $p$} & \textbf{Christ. LR} & \textbf{Indep. $p$} & \textbf{CC $p$} & \textbf{CVaR (\%)} \\
\midrule
""" + body_str + r"""
\bottomrule
\end{tabular}%
}
\end{table*}"""

    # For all numerical tables (including tab:ablation and tab:neg_sens):
    col_align = "l" + "r" * (n_cols - 1)
    if n_cols > 5:
        table_tex = wide_open + r"""
\centering
\small
\caption{""" + clean_caption + r"""}
\label{""" + label + r"""}
\resizebox{\textwidth}{!}{%
\begin{tabular}{""" + col_align + r"""}
\toprule
""" + header_str + r"""
\midrule
""" + body_str + r"""
\bottomrule
\end{tabular}%
}
""" + wide_close
    else:
        table_tex = wide_open + r"""
\centering
\small
\caption{""" + clean_caption + r"""}
\label{""" + label + r"""}
\begin{tabular}{""" + col_align + r"""}
\toprule
""" + header_str + r"""
\midrule
""" + body_str + r"""
\bottomrule
\end{tabular}
""" + wide_close
    return table_tex

def main():
    print("=== Generating Full Academic LaTeX Manuscript Source ===")
    
    wb = openpyxl.load_workbook("tables.xlsx")
    
    t1 = load_table_as_latex(wb['VariableDefinitions'], "tab:variables", "Variable Definitions, Descriptions, and Data Sources", is_wide=True)
    t17 = load_table_as_latex(wb['NegativePriceSensitivity'], "tab:neg_sens", "Sensitivity Analysis: Treatment of April 20, 2020 WTI Negative Price Event", is_wide=True)
    t2 = load_table_as_latex(wb['SampleSplits'], "tab:splits", "Chronological Sample Splitting Details (2016–2026, N = 2,473 Trading Days)", is_wide=True)
    t3 = load_table_as_latex(wb['DescriptiveStats'], "tab:descriptive", "Descriptive Statistics for Core Volatility and Exogenous Risk Variables", is_wide=True)
    t4 = load_table_as_latex(wb['Correlations'], "tab:correlation", "Pearson Correlation Matrix across Core Predictor Variables", is_wide=True)
    t5 = load_table_as_latex(wb['H1_Regression'], "tab:h1_reg", "Multivariate Econometric OLS Regression of Realized Volatility on Lagged Geopolitical Risk (Testing Hypothesis H1)", is_wide=True)
    t6 = load_table_as_latex(wb['EconometricSummary'], "tab:econometric", "Econometric Baseline Parameter Estimates: GARCH(1,1), EGARCH(1,1), GJR-GARCH(1,1), and HAR-RV", is_wide=True)
    t7 = load_table_as_latex(wb['MLConfigs'], "tab:ml_configs", "Classical Machine Learning Benchmark Hyperparameter Configurations", is_wide=True)
    t8 = load_table_as_latex(wb['QuantumConfigs'], "tab:quantum_configs", "Quantum Support Vector Regression (QSVR) Circuit Architecture Specification", is_wide=True)
    t9 = load_table_as_latex(wb['KernelProperties'], "tab:kernel_props", "Quantum vs. Classical Kernel Geometric Properties and Target Alignment", is_wide=True)
    t20 = load_table_as_latex(wb['QuantumRegSensitivity'], "tab:qreg_sens", "Numerical Stability and Tikhonov Ridge Regularization Sensitivity Analysis for QSVR Gram Matrix", is_wide=True)
    t10 = load_table_as_latex(wb['AblationStudy'], "tab:ablation", "Feature Ablation Study: Forecasting RMSE across Nested Predictor Subsets", is_wide=True)
    t11_4f = load_table_as_latex(wb['Controlled4FBenchmark'], "tab:controlled_4f", "Controlled 4-Feature Benchmark: Direct Comparison of Quantum vs. Classical Kernels on Identical Information Set", is_wide=True)
    t11 = load_table_as_latex(wb['ModelPerformance'], "tab:perf", "Out-of-Sample Volatility Forecasting Accuracy Metrics Comparison (655-Day Test Window)", is_wide=True)
    t12 = load_table_as_latex(wb['Key_DM_FDR_Comparisons'], "tab:dm_tests", "Pairwise Diebold-Mariano Predictive Accuracy Tests with HLN Corrections and Benjamini-Hochberg FDR Adjustments", is_wide=True)
    t13 = load_table_as_latex(wb['RegimeAnalysis'], "tab:regimes", "Out-of-Sample Forecasting RMSE across Geopolitical Risk Regimes (Pre-Test Thresholds with 95% Bootstrap CIs)", is_wide=True)
    t14 = load_table_as_latex(wb['RobustnessTests'], "tab:robustness", "Alternative Geopolitical Risk Percentile Threshold Robustness Checks (80th and 90th Percentiles)", is_wide=True)
    t15 = load_table_as_latex(wb['RiskManagement'], "tab:risk_mgmt", "Economic Risk Management: 95% Value-at-Risk (VaR) Coverage Backtesting with Associated Expected Shortfall (CVaR) Estimates (Model-Consistent Distributions)", is_wide=True)
    t16 = load_table_as_latex(wb['PortfolioPerformance'], "tab:portfolio", "Economic Significance: Volatility-Targeting Portfolio Performance (15% Target Vol, 5 bps Cost)", is_wide=True)
    t18 = load_table_as_latex(wb['CostSensitivity'], "tab:cost_sens", "Transaction Cost Sensitivity Analysis for Volatility-Targeting Strategy (1 to 20 bps)", is_wide=True)
    t19 = load_table_as_latex(wb['HypothesisSummary'], "tab:hyp_summary", "Summary of Formal Hypothesis Testing Decisions", is_wide=True)
    
    tex_doc = r"""\documentclass[11pt,a4paper]{article}

\usepackage[utf8]{inputenc}
\usepackage[margin=1in]{geometry}
\usepackage{amsmath,amssymb,amsfonts,bm}
\usepackage{booktabs,tabularx,array,multirow}
\usepackage{graphicx}
\usepackage{float}
\usepackage{setspace}
\usepackage{microtype}
\usepackage{natbib}
\usepackage{xurl}
\usepackage[colorlinks=true,linkcolor=blue,citecolor=blue,urlcolor=blue]{hyperref}
\usepackage{caption}
\usepackage{subcaption}
\usepackage{authblk}

\onehalfspacing

\title{\textbf{Quantum Kernel Regression and Geopolitical Risk in Crude Oil Volatility Forecasting:\\An Empirical Out-of-Sample Benchmark}}

\author[1]{\textbf{Ram Soorat}\thanks{Email: \href{mailto:rsoorat@gmail.com}{rsoorat@gmail.com}}}
\author[2]{\textbf{Afzalur Rahman}\thanks{Email: \href{mailto:afzalur.rahman@woxsen.edu.in}{afzalur.rahman@woxsen.edu.in}}}
\author[3]{\textbf{Priyanka}\thanks{Email: \href{mailto:priyanka292c@gmail.com}{priyanka292c@gmail.com}}}
\author[4,*]{\textbf{Uvesh Husain}\thanks{Corresponding author. Email: \href{mailto:u78.husain@gmail.com}{u78.husain@gmail.com}}}

\affil[1]{\textit{School of Technology (SOT), Woxsen University, Hyderabad, Telangana, India}}
\affil[2]{\textit{School of Business (SOB), Woxsen University, Hyderabad, Telangana, India}}
\affil[3]{\textit{Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India}}
\affil[4]{\textit{Economics and Business Studies Department, Mazoon College, Muscat, Sultanate of Oman}}

\date{\today}

\begin{document}

\maketitle

\begin{abstract}
Forecasting crude oil volatility under geopolitical uncertainty is vital for energy asset pricing, macro-risk surveillance, and financial hedging. This study presents a comprehensive out-of-sample empirical benchmark comparing a 4-qubit Parameterized Quantum Circuit (PQC) kernel regression model (QSVR) against twelve classical benchmark models (yielding thirteen models in total)---including the Heterogeneous Autoregressive model of Realized Volatility (HAR-RV), GARCH(1,1), EGARCH(1,1), and GJR-GARCH(1,1)---as well as classical machine learning regressors (ElasticNet, Linear/Poly/RBF SVR, Random Forest, XGBoost, LightGBM, and PyTorch LSTM).

Using a ten-year daily dataset (2016--2026, $N = 2,473$ clean trading days) incorporating daily newspaper-based Geopolitical Risk (GPRD), AI-based Geopolitical Risk (AI-GPR), and cross-asset macroeconomic controls, models are evaluated across a 655-day out-of-sample window (2024--2026). Our empirical results establish five core findings:
\begin{enumerate}
    \item Multi-component autoregressive models (HAR-RV, $\text{RMSE} = 0.6708, R^2 = 0.7800$) and regularized linear shrinkage (SVR-Linear, $\text{RMSE} = 0.6717$; ElasticNet, $\text{RMSE} = 0.7017$) dominate point-forecasting accuracy under symmetric RMSE loss, whereas tree ensembles lead under asymmetric variance-penalizing QLIKE loss (XGBoost, $\text{QLIKE} = 0.1574$).
    \item In a controlled 4-feature experiment where quantum and classical kernel machines operate on identical inputs, the 4-qubit quantum kernel ($\text{RMSE} = 0.7007, R^2 = 0.7600$) outperforms classical Gaussian RBF kernel regression ($\text{RMSE} = 0.7140, R^2 = 0.7508$), demonstrating that the quantum feature map provides a rich non-linear representation, though linear models still maintain the lowest point error.
    \item While the 4-qubit quantum kernel achieves competitive point accuracy, pairwise Diebold-Mariano tests with Benjamini-Hochberg False Discovery Rate (FDR) adjustments confirm that quantum kernel simulation on classical hardware does not offer statistically significant point-forecast superiority over strong linear benchmarks ($p_{\text{FDR}} = 0.1712$), reframing the contribution as an empirical kernel representation study rather than a computational quantum advantage.
    \item In the full multivariate econometric specification with Newey-West HAC standard errors, lagged daily GPR does not retain statistical significance ($\beta = 0.0008, t = 1.4243, p = 0.1544$; Variance Inflation Factors $< 3.0$) after controlling for volatility persistence ($\beta = 0.8860, t = 22.35, p < 0.0001$) and equity market volatility (VIX, $\beta = 0.0250, t = 3.68, p = 0.0002$), indicating that autoregressive persistence dominates predictive attribution (accounting for over 96\% of permutation importance), while GPR is more informative for regime stratification and stress-period analysis than for incremental daily point forecasting.
    \item In formal 95\% Value-at-Risk (VaR) backtesting with model-consistent innovation distributions, parametric Student-$t$ GARCH(1,1) and GJR-GARCH models achieve near-nominal unconditional coverage ($4.73\%$--$4.89\%$ breaches, passing Kupiec POF tests with $p > 0.75$), whereas EGARCH is overly conservative ($2.90\%$ breaches, Kupiec $p = 0.0077$) and QSVR is under-conservative ($7.79\%$ breaches, Kupiec $p = 0.0024$) but provides no statistical evidence against the independence null hypothesis in Christoffersen tests ($p = 0.5904$).
\end{enumerate}

\noindent \textbf{Keywords:} Crude Oil Volatility, Realized Volatility, Geopolitical Risk (GPR), Quantum Machine Learning, Quantum Kernel Regression, HAR-RV, Value-at-Risk (VaR), Kupiec Test, Christoffersen Test, False Discovery Rate (FDR). \\
\noindent \textbf{JEL Classification:} C22, C53, C58, G17, Q41, Q47.
\end{abstract}

\section{Introduction}
\label{sec:intro}

Crude oil is the cornerstone of global industrial production, transportation networks, and petrochemical supply chains. Consequently, unexpected disruptions and violent price swings in crude oil markets transmit profound shocks throughout the global macroeconomy, influencing sovereign inflation trajectories, monetary policy decisions, and international equity market stability \citep{hamilton2003oil}. As demonstrated in structural macroeconomic analyses, energy price fluctuations reflect a complex combination of global demand shifts, precautionary stockpiling, and supply shocks \citep{kilian2009not, baumeister2016forty}. Predicting crude oil volatility accurately, while incorporating cross-market information from global benchmarks, is therefore a fundamental objective for energy risk managers, derivatives trading desks, and macroeconomic surveillance authorities \citep{alqahtani2020geopolitical}.

In energy econometrics, conditional variance modeling has traditionally relied on Generalized Autoregressive Conditional Heteroskedasticity (GARCH) specifications \citep{engle1982autoregressive, bollerslev1986generalized}, their asymmetric counterparts such as EGARCH \citep{nelson1991conditional} and GJR-GARCH \citep{glosten1993relation}, and the Heterogeneous Autoregressive model of Realized Volatility (HAR-RV) \citep{corsi2009simple}. While these econometric frameworks effectively capture short-term clustering, long-memory persistence, and leverage asymmetries, they often struggle when processing high-dimensional, multi-source exogenous signals---such as real-time textual geopolitical risk indices and cross-asset macroeconomic controls---without encountering severe parameter proliferation and in-sample overfitting \citep{smales2021geopolitical, bouoiyour2026geopolitical}.

In recent years, the intersection of quantum information science and statistical computation has introduced Quantum Machine Learning (QML) as a potential paradigm for high-dimensional pattern recognition \citep{biamonte2017quantum}. Foundational surveys have highlighted the potential of quantum computing for risk analysis and financial mathematics \citep{herman2026advances, ahmad2026quantum}. Practical applications have emerged in quantum kernel estimation \citep{havlicek2019supervised, schuld2019quantum}, expressive quantum neural architectures \citep{abbas2021power}, and energy forecasting \citep{liu2026deep}. In particular, Parameterized Quantum Circuit (PQC) kernel methods map classical input data into exponentially large Hilbert spaces via non-linear unitary operations, computing inner-product kernel matrices through quantum state fidelity overlaps \citep{huang2021power, cerezo2021variational}.

This paper presents an extensive out-of-sample empirical benchmark comparing a 4-qubit PennyLane Quantum Support Vector Regression (QSVR) model against twelve classical econometric and machine learning benchmarks across a 10-year daily historical sample (2016--2026, $N = 2,473$ clean trading days) with an explicit 655-day test window (2024--2026).

\section{Literature Review}
\label{sec:lit}

\subsection{Crude Oil Volatility Dynamics and Geopolitical Risk}
Geopolitical tensions and policy uncertainty have emerged as vital determinants of global commodity market dynamics. Following the development of text-based economic policy uncertainty indices \citep{baker2016measuring}, \citet{caldara2022measuring} introduced the daily and monthly Geopolitical Risk (GPR) indices based on automated newspaper article counts. Their empirical findings revealed that geopolitical escalations trigger sharp contractions in macroeconomic investment and substantial surges in commodity market volatility. 

Recent empirical studies demonstrate that geopolitical risk exerts a heterogeneous impact across energy commodity returns \citep{smales2021geopolitical}, while dynamic connectedness and risk spillovers intensify during international crises \citep{demiralay2026geopolitical, bouoiyour2026geopolitical}. Furthermore, time-varying sensitivity and energy transition uncertainties fluctuate across market regimes \citep{smales2026geopolitical}, motivating flexible non-linear and econometric forecasting frameworks \citep{alqahtani2020geopolitical}.

\subsection{Econometric Volatility Modeling and Realized Volatility}
In financial econometrics, conditional heteroskedasticity is conventionally modeled through ARCH and GARCH frameworks \citep{engle1982autoregressive, bollerslev1986generalized}, with asymmetric leverage dynamics captured by EGARCH \citep{nelson1991conditional} and GJR-GARCH \citep{glosten1993relation}. With the availability of continuous intra-day price feeds, realized volatility emerged as a non-parametric, model-free estimator of integrated variance \citep{andersen2003modeling}. 

To bridge multi-scale temporal dynamics, \citet{corsi2009simple} formulated the Heterogeneous Autoregressive model of Realized Volatility (HAR-RV). For rigorous forecast comparison, \citet{patton2011volatility} proved that only MSE and QLIKE loss functions provide robust model rankings when evaluated against noisy volatility proxies, while \citet{diebold1995comparing} and \citet{harvey1997testing} established standard predictive accuracy tests.

\subsection{Machine Learning and Regularized Asset Pricing}
The integration of machine learning into financial economics has expanded significantly. Support Vector Regression provides a robust margin-based framework for non-linear time-series modeling \citep{vapnik1995nature}. To overcome high-dimensional collinearity, penalized shrinkage methods such as the Lasso \citep{tibshirani1996regression} and ElasticNet \citep{zou2005regularization} enforce parameter sparsity and stability. Tree-based ensemble methods, including Random Forests \citep{breiman2001random}, XGBoost \citep{chen2016xgboost}, and LightGBM \citep{ke2017lightgbm}, capture complex non-linear interactions. For sequential dependencies, recurrent architectures such as Long Short-Term Memory (LSTM) networks capture temporal memory \citep{hochreiter1997long}. Model interpretability is provided through Shapley additive explanations \citep{lundberg2017unified}, while kernel-target alignment offers geometric diagnostics \citep{cristianini2001kernel}.

\subsection{Quantum Machine Learning in Financial Modeling}
Quantum Machine Learning investigates whether quantum computational mechanics can enhance statistical pattern recognition \citep{biamonte2017quantum}. In the Noisy Intermediate-Scale Quantum era, Parameterized Quantum Circuits serve as hybrid quantum-classical learning architectures \citep{cerezo2021variational}. \citet{havlicek2019supervised} and \citet{schuld2019quantum} established that supervised QML can be naturally represented as kernel estimation in quantum Hilbert spaces. Theoretical investigations have analyzed the expressive capacity and power of data in quantum learning \citep{huang2021power, abbas2021power}. Recent research has explored quantum computing across financial forecasting \citep{ahmad2026quantum}, risk analytics \citep{herman2026advances}, and energy volatility modeling \citep{liu2026deep}. Using open-source differentiable quantum frameworks like PennyLane \citep{bergholm2018pennylane}, this study conducts a transparent out-of-sample empirical benchmark of quantum kernel methods.

\section{Theoretical Framework and Hypotheses}
\label{sec:theory}

Building on the econometric and quantum machine learning literature, we formulate five formal, testable hypotheses. Prior to regression estimation, time-series stationarity and long-run level relationships are verified using bounds testing frameworks \citep{pesaran2001bounds}:

\begin{itemize}
    \item \textbf{Hypothesis H1 (Geopolitical Risk Incremental Significance):} We test whether lagged daily geopolitical risk indices (GPRD, AI-GPR) exert a statistically significant positive effect ($\beta > 0, p < 0.05$) on realized crude oil volatility in a dynamic econometric specification after controlling for autoregressive volatility persistence and cross-asset financial conditions with Newey-West HAC standard errors \citep{newey1987simple}.
    \item \textbf{Hypothesis H2 (Asymmetric Return Innovation Dynamics):} Asymmetric volatility specifications will exhibit statistically significant asymmetric responses to crude oil return innovations ($\gamma \ne 0, p < 0.05$), reflecting that negative crude oil return shocks generate greater conditional variance surges than positive return shocks of identical magnitude \citep{glosten1993relation, nelson1991conditional}.
    \item \textbf{Hypothesis H3 (Comparative Point-Forecasting Accuracy):} We test whether non-linear classical and quantum kernel transformations provide incremental out-of-sample point-forecasting accuracy relative to parsimonious linear and multi-component autoregressive benchmarks (HAR-RV, ElasticNet, SVR-Linear) under recursive out-of-sample forecasting tests \citep{corsi2009simple, diebold1995comparing}.
    \item \textbf{Hypothesis H4 (Quantum Kernel Representation Geometry):} The 4-qubit parameterized quantum circuit constructs an empirically distinct feature map in 16-dimensional Hilbert space, exhibiting measurable geometric differences in Kernel-Target Alignment $A(K, \mathbf{y})$, condition number, and effective dimension relative to classical linear, polynomial, and Gaussian RBF kernels \citep{cristianini2001kernel, abbas2021power}.
    \item \textbf{Hypothesis H5a (No Evidence of Tail-Risk Violation Clustering):} In 95\% Value-at-Risk (VaR) backtesting, volatility forecasts from non-linear kernel architectures (QSVR and SVR-RBF) will produce tail-risk violation sequences that provide no statistical evidence against the independence null hypothesis in Christoffersen tests ($p > 0.05$) \citep{christoffersen1998evaluating}.
    \item \textbf{Hypothesis H5b (Unconditional Tail-Risk Coverage Consistency):} Volatility forecasts from machine learning and econometric models will exhibit unconditional coverage consistent with the nominal 5\% exceedance probability, passing the Kupiec Proportion of Failures ($LR_{\text{POF}}$) test ($p > 0.05$) \citep{kupiec1995techniques}.
\end{itemize}

\section{Data, Variables, and Descriptive Statistics}
\label{sec:data}

\subsection{Data Collection and Strict Information Horizon}
Our empirical dataset spans a ten-year historical period from August 18, 2016, to August 18, 2026. Following an initial 22-trading-day initialization window required to construct the monthly rolling components for the HAR-RV model and lagged predictors, the final clean dataset comprises $N = 2,473$ daily trading observations (September 27, 2016 to August 18, 2026). 

The primary dependent variable is the 5-day rolling realized standard deviation of West Texas Intermediate (WTI) crude oil spot returns. Daily WTI spot prices are sourced from the Federal Reserve Bank of St. Louis (FRED, Series \texttt{DCOILWTICO}) and verified against Alpha Vantage market feeds. We emphasize that FRED Series \texttt{DCOILWTICO} represents the physical spot market price for WTI crude oil at Cushing, Oklahoma. On April 20, 2020, as the prompt May 2020 NYMEX WTI futures contract expired at $-\$37.63$/barrel due to severe localized storage exhaustion, the physical spot settlement index correspondingly registered $-\$36.98$/barrel.

To capture geopolitical risk, we utilize daily newspaper-based Geopolitical Risk (GPRD) indices and daily Artificial Intelligence Geopolitical Risk (AI-GPR) indices constructed by Matteo Iacoviello \citep{caldara2022measuring}. We incorporate the aggregate GPRD index, the AI-GPR index, and the oil-specific AI geopolitical risk subindex (GPR\_OIL). To account for broader financial conditions, we obtain six cross-asset control variables: the CBOE Volatility Index (VIX), Gold COMEX futures returns, the US Dollar Index (DXY) returns, Natural Gas futures returns, Brent Crude spot returns, and daily changes in the U.S. 10-Year Treasury Yield. Table \ref{tab:variables} provides complete definitions and sources.

To prevent look-ahead bias, all predictor variables are strictly lagged by one period ($t-1$), ensuring that every forecast $\hat{\sigma}_t$ is generated strictly using information available within the $\mathcal{F}_{t-1}$ information set. All feature-scaling and min-max normalization parameters ($[0, \pi]$) were estimated exclusively using the training data (2016--2022) and then applied unchanged to validation and test observations.

""" + t1 + r"""

\subsection{Treatment of Negative WTI Price Event and Sensitivity Analysis}
Because logarithmic returns $R_t = 100 \ln(P_t / P_{t-1})$ are mathematically undefined for non-positive prices ($P_t \le 0$), we apply an explicit two-sided continuous linear interpolation for the baseline model. Specifically, the negative price on April 20, 2020 is replaced with the average of the adjacent valid trading prices (April 17, 2020: $\$18.27$/bbl; April 21, 2020: $\$10.01$/bbl, yielding an adjusted price of $\$14.14$/bbl). Daily percentage log returns are calculated continuously across the full sample:
\begin{equation}
R_t = 100 \times \ln\left( \frac{P_t^{\text{adj}}}{P_{t-1}^{\text{adj}}} \right)
\end{equation}

To verify whether this synthetic interpolation alters model rankings or tail-risk conclusions, Table \ref{tab:neg_sens} presents a formal sensitivity analysis across three distinct treatments: Specification A (Baseline linear interpolation, $P_{2020-04-20} = \$14.14$), Specification B (Observation exclusion), and Specification C (Positive price shift $P_t + \$40.0$). Across all three specifications, the model forecasting error hierarchy remains stable: HAR-RV ($\text{RMSE} = 0.6708$--$0.6725$) and SVR-Linear ($\text{RMSE} = 0.6717$--$0.6730$) consistently achieve the lowest errors, followed by QSVR ($\text{RMSE} = 0.7007$--$0.7019$) and ElasticNet ($\text{RMSE} = 0.7017$--$0.7034$), with 95\% VaR breaches for QSVR remaining invariant (51 vs 52 breaches). This confirms that our substantive findings are robust to the three investigated treatments of the negative price anomaly.

""" + t17 + r"""

\subsection{Chronological Sample Splitting}
To ensure rigorous out-of-sample evaluation, the dataset is partitioned chronologically without shuffling:
\begin{itemize}
    \item \textbf{Training Set:} September 27, 2016 to December 30, 2022 ($N = 1,570$ trading days, 63.5\% of sample).
    \item \textbf{Validation Set:} January 3, 2023 to December 29, 2023 ($N = 248$ trading days, 10.0\% of sample), used for hyperparameter tuning and model selection.
    \item \textbf{Out-of-Sample Test Set:} January 2, 2024 to August 18, 2026 ($N = 655$ trading days, 26.5\% of sample), held strictly separate for out-of-sample evaluation.
\end{itemize}
Table \ref{tab:splits} details the chronological partition design.

""" + t2 + r"""

\subsection{Descriptive Statistics and Econometric Tests}
Table \ref{tab:descriptive} reports the summary descriptive statistics for core variables. Daily WTI crude oil returns exhibit a daily mean of $0.0281\%$, a daily standard deviation of $3.2919\%$, moderate negative skewness ($-0.7513$), and heavy excess kurtosis ($46.2351$). The Jarque-Bera test strongly rejects normality ($\text{JB} = 193,124.91, p < 0.001$). The primary target realized volatility averages $2.3086\%$ with a maximum of $33.8571\%$. Engle's ARCH-LM test on WTI returns confirms highly significant autoregressive conditional heteroskedasticity ($\text{LM} = 676.19, p < 0.0001$), justifying GARCH modeling \citep{engle1982autoregressive}.

""" + t3 + r"""

Table \ref{tab:correlation} presents the Pearson correlation matrix. Realized volatility exhibits a strong positive correlation with the VIX equity volatility index ($r = 0.5544$), a positive correlation with Brent crude volatility, and a modest positive unconditional correlation with the daily GPR index ($r = 0.0711$).

""" + t4 + r"""

\begin{figure}[htbp]
\centering
\begin{subfigure}[b]{0.48\textwidth}
    \includegraphics[width=\textwidth]{figures/figure_01_wti_price.png}
    \caption{WTI Crude Oil Daily Spot Price Dynamics.}
    \label{fig:price}
\end{subfigure}
\hfill
\begin{subfigure}[b]{0.48\textwidth}
    \includegraphics[width=\textwidth]{figures/figure_02_wti_returns.png}
    \caption{WTI Percentage Daily Log Returns.}
    \label{fig:returns}
\end{subfigure}
\vskip\baselineskip
\begin{subfigure}[b]{0.48\textwidth}
    \includegraphics[width=\textwidth]{figures/figure_03_wti_volatility.png}
    \caption{5-Day Rolling Realized Volatility.}
    \label{fig:volatility}
\end{subfigure}
\hfill
\begin{subfigure}[b]{0.48\textwidth}
    \includegraphics[width=\textwidth]{figures/figure_04_gpr.png}
    \caption{Daily Geopolitical Risk Indices (GPRD and AI-GPR).}
    \label{fig:gpr}
\end{subfigure}
\caption{WTI Crude Oil Market Dynamics and Geopolitical Risk Indices (2016–2026, N = 2,473).}
\label{fig:data_overview}
\end{figure}

\begin{figure}[htbp]
\centering
\begin{subfigure}[b]{0.48\textwidth}
    \includegraphics[width=\textwidth]{figures/figure_05_gpr_oil_volatility.png}
    \caption{Realized Volatility vs. GPR Co-movement.}
    \label{fig:gpr_vol_comovement}
\end{subfigure}
\hfill
\begin{subfigure}[b]{0.48\textwidth}
    \includegraphics[width=\textwidth]{figures/figure_06_correlation.png}
    \caption{Pearson Correlation Heatmap across Predictors.}
    \label{fig:corr_heatmap}
\end{subfigure}
\caption{Geopolitical Risk Co-movement and Correlation Structure.}
\label{fig:gpr_correlation_overview}
\end{figure}

\subsection{Econometric Test of Hypothesis H1 and Multicollinearity Analysis}
To formally test Hypothesis \textbf{H1}, we estimate an econometric OLS regression of realized volatility on lagged geopolitical risk indices with Newey-West HAC standard errors (5 lags) \citep{newey1987simple}:
\begin{equation}
\text{RV}_t = \alpha + \beta_1 \text{RV}_{t-1} + \beta_2 \text{GPRD}_{t-1} + \beta_3 \Delta\text{GPRD}_{t-1} + \beta_4 \text{GPR\_AI}_{t-1} + \gamma \text{VIX}_{t-1} + \varepsilon_t
\end{equation}
Table \ref{tab:h1_reg} reports the empirical estimates. In this full dynamic specification, lagged realized volatility exerts an overwhelming positive effect ($\beta_1 = 0.8860, t = 22.3510, p < 0.0001$), and lagged equity volatility ($\text{VIX}_{t-1}$) is highly significant ($\gamma = 0.0250, t = 3.6758, p = 0.0002$). However, lagged daily GPR ($\text{GPRD}_{t-1}$) yields a coefficient of $\beta_2 = 0.0008$ with a $t$-statistic of $1.4243$ ($p = 0.1544$), while $\text{GPR\_AI}_{t-1}$ yields $\beta_4 = -0.0004$ ($t = -1.0685, p = 0.2853$). 

To evaluate whether correlation between GPRD and AI-GPR ($r = 0.7386$) introduces collinearity instability, we calculate Variance Inflation Factors (VIF): $\text{VIF}(\text{GPRD}) = 2.9618$, $\text{VIF}(\text{GPR\_AI}) = 2.5195$, $\text{VIF}(\text{Vol\_Lag1}) = 1.4651$, $\text{VIF}(\Delta\text{GPRD}) = 1.3325$, and $\text{VIF}(\text{VIX}) = 1.4465$. All VIF values remain well below the standard threshold of 5.0, confirming that multicollinearity does not compromise the coefficient estimates. Consequently, Hypothesis \textbf{H1} is rejected in the full dynamic multivariate econometric specification.

""" + t5 + r"""

\section{Econometric, Machine Learning, and Quantum Methodology}
\label{sec:methodology}

\subsection{Econometric Baseline Specifications: GARCH, EGARCH, GJR-GARCH, and HAR-RV}
To benchmark conditional volatility modeling, we estimate three parametric GARCH-family specifications under standardized Student-$t$ innovation distributions alongside Corsi's (2009) HAR-RV framework:
\begin{align}
\text{GARCH(1,1):} \quad \sigma_t^2 &= \omega + \alpha \varepsilon_{t-1}^2 + \beta \sigma_{t-1}^2 \\
\text{EGARCH(1,1):} \quad \ln(\sigma_t^2) &= \omega + \alpha \left( \left| \frac{\varepsilon_{t-1}}{\sigma_{t-1}} \right| - \sqrt{\frac{2}{\pi}} \right) + \gamma \frac{\varepsilon_{t-1}}{\sigma_{t-1}} + \beta \ln(\sigma_{t-1}^2) \\
\text{GJR-GARCH(1,1):} \quad \sigma_t^2 &= \omega + \left( \alpha + \gamma \mathbb{I}_{(\varepsilon_{t-1} < 0)} \right) \varepsilon_{t-1}^2 + \beta \sigma_{t-1}^2 \\
\text{HAR-RV:} \quad \text{RV}_t &= \beta_0 + \beta_d \text{RV}_{t-1} + \beta_w \text{RV}_{t-1}^{(w)} + \beta_m \text{RV}_{t-1}^{(m)} + \varepsilon_t
\end{align}
where $\mathbb{I}_{(\cdot)}$ is an indicator function. In GJR-GARCH, the asymmetric leverage parameter is positive and statistically significant ($\gamma = 0.0527, t = 2.2154, p = 0.0267$) \citep{glosten1993relation}. In EGARCH, the asymmetric parameter is negative and statistically significant ($\gamma = -0.0433, t = -2.6560, p = 0.0079$) \citep{nelson1991conditional}, confirming that negative return shocks generate larger surges in conditional log-variance than positive shocks of identical magnitude, supporting Hypothesis \textbf{H2} for both asymmetric specifications.

Table \ref{tab:econometric} summarizes the parameter estimates and diagnostic tests for all econometric models.

""" + t6 + r"""

\subsection{Classical Machine Learning Benchmark Models}
We implement six classical machine learning algorithms:
\begin{itemize}
    \item \textbf{Regularized Linear Regression (ElasticNet):} Minimizes MSE with combined $\ell_1$ (Lasso) and $\ell_2$ (Ridge) penalties \citep{zou2005regularization, tibshirani1996regression}: $\mathcal{L}_{\text{EN}} = \frac{1}{2N} \|\mathbf{y} - X\mathbf{w}\|_2^2 + \alpha \rho \|\mathbf{w}\|_1 + \frac{\alpha(1-\rho)}{2} \|\mathbf{w}\|_2^2$ with validation parameters $\alpha = 0.01, \rho = 0.20$.
    \item \textbf{Support Vector Regression (SVR):} Formulates an $\varepsilon$-insensitive loss tube \citep{vapnik1995nature}: $\mathcal{L}_{\text{SVR}} = \frac{1}{2}\|\mathbf{w}\|^2 + C \sum_{i=1}^N \max(0, |y_i - f(\mathbf{x}_i)| - \varepsilon)$. We benchmark Linear ($K(\mathbf{x}, \mathbf{x}') = \mathbf{x}^\top \mathbf{x}'$), Polynomial ($K(\mathbf{x}, \mathbf{x}') = (\mathbf{x}^\top \mathbf{x}' + 1)^2$), and Gaussian Radial Basis Function (RBF: $K(\mathbf{x}, \mathbf{x}') = \exp(-\gamma \|\mathbf{x} - \mathbf{x}'\|^2)$) kernels with $C = 1.0, \varepsilon = 0.05$.
    \item \textbf{Tree Ensembles (Random Forest, XGBoost, LightGBM):} Random Forest averages 100 decorrelated decision trees \citep{breiman2001random}. XGBoost minimizes second-order Taylor expansion loss with tree shrinkage ($\eta = 0.05$, max depth = 3) \citep{chen2016xgboost}. LightGBM utilizes leaf-wise gradient-based one-side sampling \citep{ke2017lightgbm}.
    \item \textbf{Deep Learning (PyTorch LSTM):} A single-layer recurrent Long Short-Term Memory network with 32 hidden units, a 5-day lookback sequence window, and Adam optimization ($\text{lr} = 0.001$) \citep{hochreiter1997long}.
\end{itemize}
Table \ref{tab:ml_configs} details the hyperparameter configurations.

""" + t7 + r"""

\subsection{Quantum Support Vector Regression (QSVR) Architecture}
The QSVR model utilizes PennyLane's \texttt{default.qubit} statevector simulator on 4 qubits \citep{bergholm2018pennylane}, mapping four normalized features $\mathbf{x} = [x_1, x_2, x_3, x_4]^\top \in [0, \pi]^4$ (comprising $\text{Vol\_Lag1}$, $\text{GPRD\_Lag1}$, $\text{VIX\_Lag1}$, and $\text{Return\_Lag1}$) into 16-dimensional Hilbert space:
\begin{equation}
U(\mathbf{x}) = U_{\text{ent}} \left( \bigotimes_{k=1}^4 R_Y(x_k) \right)
\end{equation}
where $R_Y(\theta) = \exp(-i \theta Y / 2)$ and $U_{\text{ent}} = \text{CNOT}_{(3,0)}\text{CNOT}_{(2,3)}\text{CNOT}_{(1,2)}\text{CNOT}_{(0,1)}$ implements circular entanglement \citep{havlicek2019supervised, schuld2019quantum}. The quantum transition fidelity defines the kernel:
\begin{equation}
K_Q(\mathbf{x}_i, \mathbf{x}_j) = |\langle 0000 | U^\dagger(\mathbf{x}_i) U(\mathbf{x}_j) | 0000 \rangle|^2
\end{equation}
To ensure numerical stability in SVR dual quadratic programming, a Tikhonov ridge regularization $\lambda = 10^{-5}$ is added to the Gram matrix ($K_{\text{reg}} = K_Q + \lambda I$). Table \ref{tab:quantum_configs} details the quantum circuit specification, and Table \ref{tab:kernel_props} reports the kernel geometric properties.

The empirical quantum Gram matrix achieves an effective numerical rank of 67, exceeding the single-state Hilbert space dimension $d=16$. This occurs because the quantum kernel computes the fidelity overlap between pure state density operators $\rho(\mathbf{x}) = |\psi(\mathbf{x})\rangle\langle\psi(\mathbf{x})|$, which reside in the $d^2 = 16^2 = 256$-dimensional space of linear Hermitian operators on $\mathbb{C}^{16}$ equipped with the Hilbert-Schmidt inner product \citep{abbas2021power, huang2021power}. Table \ref{tab:qreg_sens} demonstrates that out-of-sample performance is invariant to $\lambda \in [10^{-7}, 10^{-4}]$.

""" + t8 + r"""

""" + t9 + r"""

""" + t20 + r"""

\subsection{Mathematical Bridge: Rolling Volatility Forecast to Daily Value-at-Risk}
Our target variable is the 5-day rolling realized standard deviation of daily percentage log returns:
\begin{equation}
\text{RV}_{t, 5} = \sqrt{ \frac{1}{4} \sum_{k=0}^4 \left( R_{t-k} - \bar{R}_{t, 5} \right)^2 }
\end{equation}
Under the assumption of local conditional stationarity over the 5-day window, daily returns follow $R_{t+1} = \mu_{t+1} + \sigma_{t+1} z_{t+1}$ with $z_{t+1} \sim \text{i.i.d.}(0, 1)$. Taking conditional expectations yields $\mathbb{E}[\text{RV}_{t+1, 5}^2 \mid \mathcal{F}_t] \approx \sigma_{t+1}^2$. Thus, the rolling realized volatility forecast $\hat{\sigma}_t$ estimates the conditional daily standard deviation scale. This mapping should be interpreted as a local-stationarity approximation rather than an exact identity between five-day realized volatility and one-step conditional variance.

For GARCH models estimated under Student-$t$ error distributions with estimated degrees of freedom $\hat{\nu}$ and conditional mean $\hat{\mu}$, the 95\% 1-day Value-at-Risk is calculated using the exact model-consistent Student-$t$ quantile:
\begin{equation}
\text{VaR}_{0.95, t}^{\text{GARCH}} = \hat{\mu} + \hat{\sigma}_t \left( -t_{\hat{\nu}}^{-1}(0.05) \sqrt{\frac{\hat{\nu}-2}{\hat{\nu}}} \right)
\end{equation}
For regression and machine learning models minimizing mean squared error (MSE loss), point forecasts $\hat{\sigma}_t$ are converted to 95\% VaR using the standard empirical Gaussian critical value $z_{0.95} = 1.64485$:
\begin{equation}
\text{VaR}_{0.95, t}^{\text{ML}} = 1.64485 \times \hat{\sigma}_t
\end{equation}

\section{Empirical Forecasting Results and Ablation Analysis}
\label{sec:results}

\subsection{Feature Ablation Study: Assessing the Incremental Value of GPR}
To resolve whether geopolitical risk variables contribute incremental predictive power over pure volatility persistence, we conduct a systematic feature ablation study across three nested predictor sets:
\begin{itemize}
    \item \textbf{Subset 1 (Volatility Persistence Only / HAR lags):} Pure autoregressive volatility lags ($\text{Vol\_Lag1}, \text{Vol\_Lag2}, \text{HAR\_w}, \text{HAR\_m}$).
    \item \textbf{Subset 2 (Volatility Persistence + Financial Controls):} Volatility lags plus cross-asset controls (VIX, Gold, DXY, Gas, Brent, Treasury Yield).
    \item \textbf{Subset 3 (Full Information Set: Volatility + Controls + GPR):} Full predictor matrix including GPRD, AI-GPR, and GPR\_OIL.
\end{itemize}
Table \ref{tab:ablation} reports the ablation results across ElasticNet, XGBoost, and SVR-RBF. Across all models, Subset 1 achieves the highest point forecasting accuracy (ElasticNet $\text{RMSE} = 0.6695, R^2 = 0.7809$), demonstrating that volatility persistence dominates predictive attribution. Adding macroeconomic controls and GPR variables introduces minor variance, confirming that GPR is more useful as a regime-stratification variable than as an incremental daily point predictor.

""" + t10 + r"""

\subsection{Controlled 4-Feature Benchmark and Full-Model Comparison}
To isolate the mathematical contribution of the quantum kernel from feature-set differences, Table \ref{tab:controlled_4f} reports a controlled 4-feature benchmark where SVR-Linear, ElasticNet, SVR-RBF, and QSVR are trained on the exact same 4 core features ($\text{Vol\_Lag1}$, $\text{GPRD\_Lag1}$, $\text{VIX\_Lag1}$, $\text{Return\_Lag1}$). In this controlled setting:
\begin{itemize}
    \item QSVR achieves lower RMSE ($\text{RMSE} = 0.7007$ vs. $0.7140$) and higher $R^2$ ($0.7600$ vs. $0.7508$) than classical Gaussian SVR-RBF on the identical four-feature information set, although SVR-RBF remains slightly better under asymmetric QLIKE loss ($\text{QLIKE} = 0.1709$ vs. $0.1734$).
    \item SVR-Linear ($\text{RMSE} = 0.6726, R^2 = 0.7788$) and ElasticNet ($\text{RMSE} = 0.6797, R^2 = 0.7741$) achieve the lowest point errors on the 4-feature set, confirming that linear regularization remains superior under symmetric MSE loss.
\end{itemize}

""" + t11_4f + r"""

Table \ref{tab:perf} presents the out-of-sample forecasting performance across all thirteen evaluated models over the 655-day test window (2024--2026) using Root Mean Squared Error (RMSE), Mean Absolute Error (MAE), coefficient of determination ($R^2$), and Patton's Gaussian Quasi-Likelihood loss ($\text{QLIKE} = \frac{\text{RV}_t}{\hat{v}_t} - \ln\frac{\text{RV}_t}{\hat{v}_t} - 1$, where $\text{RV}_t = \sigma_t^2$ and $\hat{v}_t = \hat{\sigma}_t^2$) \citep{patton2011volatility}.

The empirical hierarchy reveals that:
\begin{enumerate}
    \item \textbf{Loss Function-Dependent Model Rankings:} Model rankings depend on the chosen loss metric. Under symmetric RMSE loss, HAR-RV ($\text{RMSE} = 0.6708, R^2 = 0.7800$) and SVR-Linear ($\text{RMSE} = 0.6717, R^2 = 0.7794$) lead the benchmark, closely followed by ElasticNet ($\text{RMSE} = 0.7017, R^2 = 0.7593$) and QSVR ($\text{RMSE} = 0.7007, R^2 = 0.7600$). In contrast, under asymmetric variance-penalizing QLIKE loss, tree ensembles perform best (XGBoost $\text{QLIKE} = 0.1574$, Random Forest $\text{QLIKE} = 0.1668$), with QSVR remaining competitive ($\text{QLIKE} = 0.1734$).
    \item \textbf{Transparent Pairwise Diebold-Mariano and FDR Tests:} Table \ref{tab:dm_tests} presents pairwise Diebold-Mariano tests with Harvey-Leybourne-Newbold small-sample corrections \citep{diebold1995comparing, harvey1997testing}, controlling for False Discovery Rates \citep{benjamini1995controlling}. The forecasting difference between QSVR and HAR-RV yields a Raw $p = 0.1207$ and a BH-Adjusted $p_{\text{FDR}} = 0.1712$, confirming no statistically significant difference in predictive accuracy at the $5\%$ level. Similarly, the difference between QSVR and ElasticNet yields $p_{\text{FDR}} = 0.9604$. However, QSVR significantly outperforms Gaussian RBF SVR ($p_{\text{FDR}} = 0.0001$) and standard GARCH ($p_{\text{FDR}} = 0.0007$) under MSE loss.
\end{enumerate}

""" + t11 + r"""

""" + t12 + r"""

\begin{figure}[htbp]
\centering
\includegraphics[width=0.92\textwidth]{figures/figure_08_actual_vs_predicted.png}
\caption{Out-of-Sample Volatility Forecasts vs. Actual Realized Volatility (2024--2026 Test Window).}
\label{fig:forecasts}
\end{figure}

\begin{figure}[htbp]
\centering
\includegraphics[width=0.88\textwidth]{figures/figure_09_model_comparison.png}
\caption{Out-of-Sample Root Mean Squared Error (RMSE) Model Comparison across All Evaluated Specifications.}
\label{fig:model_comp}
\end{figure}

\section{Geopolitical Risk Regime Analysis and Robustness Checks}
\label{sec:regimes}

\subsection{Performance Across Geopolitical Risk Regimes}
To eliminate look-ahead bias in regime classification, geopolitical risk thresholds were estimated exclusively from the pre-test historical sample (September 2016 to December 2023, $N = 1,818$ trading days) and held fixed during the 2024--2026 test period: Low GPR ($\text{GPRD} \le 106.77$, $N = 80$), Medium GPR ($106.77 < \text{GPRD} \le 140.53$, $N = 162$), and High GPR ($\text{GPRD} > 140.53$, $N = 413$). Figure \ref{fig:regimes_dist} visualizes the out-of-sample test set regime distribution, and Table \ref{tab:regimes} presents regime-specific RMSE alongside 95\% bootstrap confidence intervals (1,000 resamples). In the High GPR regime ($N = 413$), HAR-RV ($\text{RMSE} = 0.7529, [0.6064, 0.8997]$) and SVR-Linear ($\text{RMSE} = 0.7534, [0.6059, 0.9062]$) achieve the lowest point forecasting errors, while QSVR ($\text{RMSE} = 0.7872, [0.6506, 0.9368]$) remains competitive with ElasticNet ($\text{RMSE} = 0.7905, [0.6324, 0.9504]$), outperforming standard GARCH ($\text{RMSE} = 0.8878$) and SVR-RBF ($\text{RMSE} = 1.0601$).

\begin{figure}[htbp]
\centering
\includegraphics[width=0.75\textwidth]{figures/figure_07_gpr_regimes.png}
\caption{Out-of-Sample Test Set Trading Days across Geopolitical Risk Regimes ($N = 655$: Low = 80, Medium = 162, High = 413).}
\label{fig:regimes_dist}
\end{figure}

""" + t13 + r"""

\begin{figure}[htbp]
\centering
\includegraphics[width=0.88\textwidth]{figures/figure_10_regime_comparison.png}
\caption{Forecasting RMSE across Geopolitical Risk Regimes for Selected Representative Specifications (HAR-RV, GARCH, ElasticNet, SVR-RBF, XGBoost, QSVR).}
\label{fig:regime_comp}
\end{figure}

\subsection{Alternative Percentile Threshold Robustness Checks}
To verify that regime findings are not sensitive to threshold selection, Table \ref{tab:robustness} reports model RMSE under alternative 80th (149.51) and 90th (180.53) percentile high-risk cutoffs estimated on pre-test data. The relative performance hierarchy remains stable, confirming robustness against threshold variations.

""" + t14 + r"""

\section{Model Explainability and Quantum Sensitivity Analysis}
\label{sec:explainability}

To inspect the internal decision logic of the models, we perform permutation feature importance analysis on XGBoost and ElasticNet, alongside state sensitivity analysis on the QSVR quantum circuit \citep{lundberg2017unified}. Figure \ref{fig:shap} illustrates the normalized feature importances. 

Lagged realized volatility ($\text{Vol\_Lag1}$) accounts for $96.56\%$ of the normalized permutation-importance measure for XGBoost and $49.80\%$ for ElasticNet, confirming that volatility persistence dominates predictive attribution. Among exogenous variables, the oil-specific AI geopolitical risk subindex ($\text{GPR\_OIL\_Lag1}$, $1.50\%$), Brent crude returns ($0.66\%$), and Natural Gas returns ($0.46\%$) provide the highest incremental attributions.

In the QSVR model, wire gradient sensitivity is defined as the mean absolute expectation gradient of the Pauli-Z observable on wire $w$ with respect to input feature $x_{i, w}$ across validation samples: $\text{Sensitivity}(w) = \frac{1}{N_{\text{val}}} \sum_{i=1}^{N_{\text{val}}} \left| \frac{\partial \langle Z_w \rangle(\mathbf{x}_i)}{\partial x_{i, w}} \right|$. Normalized gradient sensitivity indicates that the first wire ($\text{Vol\_Lag1}$) contributes $98.68\%$ of aggregate QSVR wire sensitivity, while the geopolitical wire ($\text{GPRD\_Lag1}$) contributes $0.50\%$.

\begin{figure}[htbp]
\centering
\includegraphics[width=0.88\textwidth]{figures/figure_11_shap.png}
\caption{Top 10 Normalized Feature Importances from Permutation Analysis (Dominance of Volatility Persistence).}
\label{fig:shap}
\end{figure}

\section{Economic Risk Management and Portfolio Backtesting}
\label{sec:economic}

\subsection{Value-at-Risk (VaR) Backtesting with Associated Expected Shortfall Estimates}
To evaluate Hypotheses \textbf{H5a} and \textbf{H5b}, we assess the economic risk management utility of 1-day ahead 95\% Value-at-Risk and associated Expected Shortfall ($\text{CVaR}_{0.95, t} = \mathbb{E}[-R_t \mid -R_t > \text{VaR}_{0.95, t}]$) across the 655 out-of-sample trading days \citep{engle2004caviar}. A VaR breach occurs when the realized loss exceeds the VaR threshold: $-R_t > \text{VaR}_{0.95, t} \iff R_t < -\text{VaR}_{0.95, t}$. For a well-calibrated 95\% VaR model over $N=655$ days, the expected number of breaches is $655 \times 0.05 = 32.75$ ($5.0\%$).

Table \ref{tab:risk_mgmt} reports formal backtesting statistics using model-consistent innovation distributions:
\begin{enumerate}
    \item \textbf{Unconditional Coverage (Kupiec POF Test - Hypothesis H5b):} Parametric GARCH(1,1) under its fitted Student-$t$ distribution ($\hat{\nu} = 5.79$) generates 32 breaches ($4.89\%, LR_{\text{POF}} = 0.0182, p = 0.8927$), and GJR-GARCH(1,1) ($\hat{\nu} = 5.77$) generates 31 breaches ($4.73\%, LR_{\text{POF}} = 0.1001, p = 0.7517$), achieving near-nominal coverage and supporting Hypothesis \textbf{H5b} for GARCH and GJR-GARCH specifications \citep{kupiec1995techniques}. Conversely, EGARCH is overly conservative (19 breaches, $2.90\%, LR_{\text{POF}} = 4.1956, p = 0.0077$). In contrast, machine learning and kernel regressors (HAR-RV: 50 breaches, $7.63\%$; QSVR: 51 breaches, $7.79\%$; ElasticNet: 52 breaches, $7.94\%$) generate higher violation rates, leading to a rejection of Hypothesis \textbf{H5b} for QSVR ($p = 0.0024$).
    \item \textbf{Conditional Coverage and Independence (Christoffersen Test - Hypothesis H5a):} Crucially, in Christoffersen independence tests ($LR_{\text{ind}}$) \citep{christoffersen1998evaluating}, the 4-qubit QSVR ($p = 0.5904$), SVR-RBF ($p = 0.3388$), and GARCH ($p = 0.7254$) provide no statistical evidence against the independence null hypothesis in Christoffersen tests. However, in joint conditional coverage testing ($LR_{\text{cc}}$), QSVR yields $p = 0.0086$, indicating that while the data provide no statistical evidence against the independence null hypothesis, the combined hypothesis of correct coverage and independence is rejected due to the higher breach frequency.
\end{enumerate}

""" + t15 + r"""

\subsection{Volatility-Targeting Dynamic Asset Allocation Strategy}
To measure real-world portfolio economic utility, we execute a daily volatility-targeting strategy in WTI crude oil. Because $\sigma_{\text{target}} = 15\%$ is an annualized volatility target, the rolling daily standard deviation forecast $\hat{\sigma}_t$ is converted to annualized percentage units via $\hat{\sigma}_t^{\text{ann}} = \hat{\sigma}_t \times \sqrt{252}$ before computing portfolio weights:
\begin{equation}
w_t = \min\left( \frac{\sigma_{\text{target}}}{\hat{\sigma}_t^{\text{ann}}}, w_{\text{max}} \right), \quad R_{\text{port}, t} = w_t R_t - c \cdot |w_t - w_{t-1}|
\end{equation}
with maximum leverage $w_{\text{max}} = 2.0$, and a baseline illustrative institutional transaction-cost scenario of $c = 5$ basis points ($0.05\%$). We report the Compound Annual Growth Rate $\text{CAGR} = (1 + R_{\text{cum}} / 100)^{252 / N_{\text{test}}} - 1$.

Table \ref{tab:portfolio} and Figure \ref{fig:portfolio} present strategy performance over the 2024--2026 test window. The HAR-RV strategy generates the highest cumulative net return ($+10.64\%$, $\text{CAGR} = +3.97\%$, Sharpe ratio $0.298$), followed by SVR-Linear ($+9.63\%$, $\text{CAGR} = +3.60\%$, Sharpe $0.280$), QSVR ($+8.91\%$, $\text{CAGR} = +3.34\%$, Sharpe $0.268$), and SVR-RBF ($+8.47\%$, $\text{CAGR} = +3.18\%$, Sharpe $0.272$), all generating higher cumulative net returns and lower maximum drawdowns than passive WTI buy-and-hold over the reported 2024--2026 test window (which suffered a cumulative loss of $-3.86\%$, $\text{CAGR} = -1.51\%$, and maximum drawdown of $-42.84\%$).

To ensure robustness against market friction assumptions, Table \ref{tab:cost_sens} presents a transaction cost sensitivity analysis across $c \in \{1, 5, 10, 20\}$ basis points. Economic returns remain positive up to 10 bps, turning slightly negative at $20$ bps across all models, underscoring that execution efficiency is critical.

""" + t16 + r"""

""" + t18 + r"""

\begin{figure}[htbp]
\centering
\includegraphics[width=0.92\textwidth]{figures/figure_12_economic_performance.png}
\caption{Cumulative Portfolio Net Returns for Volatility-Targeting Asset Allocation Strategy (2024--2026 Test Window).}
\label{fig:portfolio}
\end{figure}

\section{Discussion and Hypothesis Synthesis}
\label{sec:discussion}

\subsection{Hypothesis Testing Decisions}
Table \ref{tab:hyp_summary} synthesizes the empirical decisions across the five formal hypotheses formulated in Section \ref{sec:theory}.

""" + t19 + r"""

\subsection{Managerial and Theoretical Insights}
The empirical findings deliver three practical insights:
\begin{enumerate}
    \item \textbf{Parsimony and Linear Dominance in Daily Volatility:} In low signal-to-noise daily financial time series, regularized linear shrinkage (ElasticNet, SVR-Linear) and heterogeneous autoregression (HAR-RV) reliably outperform complex deep neural networks and unregularized non-linear regressors under RMSE loss \citep{corsi2009simple, zou2005regularization}.
    \item \textbf{Realistic Framing of Quantum Machine Learning:} Quantum kernel simulators on classical hardware represent non-linear Hilbert space mappings. While QSVR demonstrates competitive point accuracy ($\text{RMSE} = 0.7007$) and VaR-hit independence is not rejected ($p = 0.5904$), it does not demonstrate quantum computational advantage over classical OLS/HAR \citep{herman2026advances, ahmad2026quantum}. QML in finance should be framed as a rich kernel representation methodology rather than a superior forecasting technology \citep{schuld2019quantum, abbas2021power}.
    \item \textbf{Role of Geopolitical Indices:} Geopolitical risk measures provide limited incremental predictive power on daily horizons ($p = 0.1544$ in multivariate HAC regressions; VIF $< 3.0$), serving primarily as regime-stratification variables and tail-risk stress indicators rather than primary drivers of daily point volatility \citep{caldara2022measuring, smales2021geopolitical}.
\end{enumerate}

\section{Limitations and Future Research}
\label{sec:limits}
Several limitations should be noted:
\begin{itemize}
    \item \textbf{Classical Simulation Hardware:} The quantum kernel was evaluated using statevector simulation on classical CPUs. Future work should deploy variational quantum algorithms on physical Noisy Intermediate-Scale Quantum hardware \citep{cerezo2021variational}.
    \item \textbf{Feature Dimensionality Limits:} The 4-qubit circuit required selecting four primary features ex ante. Scalable multi-qubit architectures with barren-plateau mitigation should be investigated \citep{abbas2021power, huang2021power}.
    \item \textbf{Alternative Loss Functions:} Future quantum regression research could formulate quantile-loss quantum circuits or asymmetric QLIKE-optimized quantum Hamiltonians to improve direct tail-risk estimation \citep{engle2004caviar, patton2011volatility}.
\end{itemize}

\section{Conclusion}
\label{sec:conclusion}
This study presented a rigorous out-of-sample empirical benchmark of quantum kernel regression against twelve classical econometric and machine learning specifications for crude oil volatility forecasting under geopolitical risk. Our empirical findings demonstrate that parsimonious linear models (HAR-RV and SVR-Linear) achieve the highest point forecasting accuracy under symmetric RMSE loss, while tree ensembles lead under asymmetric QLIKE loss. 

The 4-qubit parameterized quantum circuit constructs a rich kernel representation in Hilbert-Schmidt operator space that outperforms classical Gaussian RBF regression on identical 4-dimensional inputs, with out-of-sample VaR violations for which temporal independence is not rejected ($p = 0.5904$). However, quantum kernel simulation does not achieve statistically significant predictive outperformance over strong linear baselines ($p_{\text{FDR}} = 0.1712$). Finally, dynamic econometric testing reveals that geopolitical risk indices serve primarily as regime-stratification variables rather than incremental point predictors. All data, quantum circuits, and statistical pipelines are fully reproducible and open-source.

\section*{Declaration of Generative AI and AI-Assisted Technologies in the Writing Process}
During the preparation of this work, the authors used Anthropic Claude and Google DeepMind AI tools in order to assist with code optimization, data processing, and manuscript editing for clarity and formatting. After using these tools, the authors reviewed and edited the content as needed and take full responsibility for the content of the published article.

\section*{Data Availability Statement}
The empirical data and Python code used to support the findings of this study are available in the project repository at \url{https://github.com/rsoorat/Quantum-Oil-GPR-Benchmark}.

\section*{Conflict of Interest Statement}
The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

\bibliographystyle{elsarticle-harv}
\bibliography{references}

\end{document}
"""
    with open("Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript.tex", "w", encoding="utf-8") as f:
        f.write(tex_doc)
    print("Complete LaTeX manuscript generated: Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript.tex")

if __name__ == "__main__":
    main()
