import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
import openpyxl
import os

def set_cell_background(cell, fill_hex):
    tcPr = cell._element.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), fill_hex)
    tcPr.append(shd)

def set_cell_margins(cell, top=100, bottom=100, left=140, right=140):
    tcPr = cell._element.get_or_add_tcPr()
    tcMar = OxmlElement('w:tcMar')
    for m, val in [('top', top), ('bottom', bottom), ('left', left), ('right', right)]:
        node = OxmlElement(f'w:{m}')
        node.set(qn('w:w'), str(val))
        node.set(qn('w:type'), 'dxa')
        tcMar.append(node)
    tcPr.append(tcMar)

def add_styled_excel_table(doc, wb, sheet_name, caption):
    if sheet_name not in wb.sheetnames:
        return
    ws = wb[sheet_name]
    all_rows = list(ws.iter_rows(values_only=True))
    if not all_rows:
        return
        
    if len(all_rows) > 2 and all_rows[0][0] and str(all_rows[0][0]).startswith("Table "):
        headers = list(all_rows[2])
        data_rows = all_rows[3:]
    else:
        headers = list(all_rows[0])
        data_rows = all_rows[1:]
        
    if headers and (headers[0] is None or str(headers[0]).strip() == '' or str(headers[0]).lower() == 'nan'):
        headers[0] = 'Model / Variable'
        
    p_cap = doc.add_paragraph()
    p_cap.paragraph_format.space_before = Pt(12)
    p_cap.paragraph_format.space_after = Pt(4)
    p_cap.paragraph_format.keep_with_next = True
    run_cap = p_cap.add_run(caption)
    run_cap.font.name = 'Calibri'
    run_cap.font.size = Pt(11)
    run_cap.font.bold = True
    run_cap.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D)
    
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    
    hdr_cells = table.rows[0].cells
    for i, h in enumerate(headers):
        h_str = "" if h is None else str(h)
        cell = hdr_cells[i]
        cell.text = h_str
        set_cell_background(cell, '1F497D')
        set_cell_margins(cell, top=120, bottom=120, left=140, right=140)
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for r in p.runs:
            r.font.name = 'Calibri'
            r.font.size = Pt(9.5)
            r.font.bold = True
            r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
            
    for row_idx, row_vals in enumerate(data_rows):
        row_cells = table.add_row().cells
        is_even = (row_idx % 2 == 0)
        bg_color = 'F2F5F8' if is_even else 'FFFFFF'
        
        for col_idx, val in enumerate(row_vals):
            cell = row_cells[col_idx]
            set_cell_background(cell, bg_color)
            set_cell_margins(cell, top=80, bottom=80, left=120, right=120)
            
            p = cell.paragraphs[0]
            col_name = str(headers[col_idx]) if col_idx < len(headers) and headers[col_idx] is not None else ""
            
            if val is None or str(val).strip().lower() == 'nan':
                txt = "--"
                align = WD_ALIGN_PARAGRAPH.CENTER
            elif isinstance(val, (int, float)):
                if isinstance(val, int) or (isinstance(val, float) and val.is_integer() and col_name in ['Observations', '95% VaR Breaches', 'Breaches', 'Observations (Trading Days)', 'QSVR 95% VaR Breaches', 'VaR Breaches', 'Matrix Rank']):
                    txt = f"{int(val):,}"
                    align = WD_ALIGN_PARAGRAPH.RIGHT
                elif abs(val) < 0.0001 and val != 0:
                    txt = f"{val:.2e}"
                    align = WD_ALIGN_PARAGRAPH.RIGHT
                elif abs(val) < 1.0:
                    txt = f"{val:.4f}"
                    align = WD_ALIGN_PARAGRAPH.RIGHT
                elif abs(val) < 100.0:
                    txt = f"{val:.4f}"
                    align = WD_ALIGN_PARAGRAPH.RIGHT
                else:
                    txt = f"{val:,.2f}"
                    align = WD_ALIGN_PARAGRAPH.RIGHT
            else:
                txt = str(val)
                align = WD_ALIGN_PARAGRAPH.LEFT
                
            cell.text = txt
            p = cell.paragraphs[0]
            p.alignment = align
            for r in p.runs:
                r.font.name = 'Calibri'
                r.font.size = Pt(9.5)
                
    p_sp = doc.add_paragraph()
    p_sp.paragraph_format.space_before = Pt(0)
    p_sp.paragraph_format.space_after = Pt(6)

def add_figure_to_docx(doc, image_path, caption, width_inches=6.0):
    if not os.path.exists(image_path):
        return
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(10)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.keep_with_next = True
    run = p.add_run()
    run.add_picture(image_path, width=Inches(width_inches))
    
    p_cap = doc.add_paragraph()
    p_cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_cap.paragraph_format.space_before = Pt(2)
    p_cap.paragraph_format.space_after = Pt(12)
    run_cap = p_cap.add_run(caption)
    run_cap.font.name = 'Calibri'
    run_cap.font.size = Pt(9.5)
    run_cap.font.italic = True
    run_cap.font.color.rgb = RGBColor(0x33, 0x33, 0x33)

def add_heading_1(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(16)
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.keep_with_next = True
    run = p.add_run(text)
    run.font.name = 'Calibri'
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D)

def add_heading_2(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.keep_with_next = True
    run = p.add_run(text)
    run.font.name = 'Calibri'
    run.font.size = Pt(12)
    run.font.bold = True
    run.font.color.rgb = RGBColor(0x2E, 0x75, 0xB6)

def add_body_p(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.line_spacing = 1.15
    run = p.add_run(text)
    run.font.name = 'Calibri'
    run.font.size = Pt(11)

def main():
    print("=== Generating Full Academic Word Document (.docx) ===")
    
    doc = docx.Document()
    
    for section in doc.sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)
        
    wb = openpyxl.load_workbook("tables.xlsx")
    
    # Title Block
    p_title = doc.add_paragraph()
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_title.paragraph_format.space_before = Pt(18)
    p_title.paragraph_format.space_after = Pt(12)
    t_run = p_title.add_run("Quantum Kernel Regression and Geopolitical Risk in Crude Oil Volatility Forecasting:\nAn Empirical Out-of-Sample Benchmark")
    t_run.font.name = 'Calibri'
    t_run.font.size = Pt(17)
    t_run.font.bold = True
    t_run.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D)
    
    # Authors
    p_auth = doc.add_paragraph()
    p_auth.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_auth.paragraph_format.space_after = Pt(14)
    
    r1 = p_auth.add_run("Ram Soorat\n")
    r1.font.bold = True
    r1.font.size = Pt(11)
    p_auth.add_run("School of Technology (SOT), Woxsen University, Hyderabad, Telangana, India\nEmail: rsoorat@gmail.com\n\n").font.size = Pt(9.5)
    
    r2 = p_auth.add_run("Afzalur Rahman\n")
    r2.font.bold = True
    r2.font.size = Pt(11)
    p_auth.add_run("School of Business (SOB), Woxsen University, Hyderabad, Telangana, India\nEmail: afzalur.rahman@woxsen.edu.in\n\n").font.size = Pt(9.5)
    
    r3 = p_auth.add_run("Priyanka\n")
    r3.font.bold = True
    r3.font.size = Pt(11)
    p_auth.add_run("Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India\nEmail: priyanka292c@gmail.com\n\n").font.size = Pt(9.5)
    
    r4 = p_auth.add_run("Dr. Uvesh Husain (Corresponding Author)\n")
    r4.font.bold = True
    r4.font.size = Pt(11)
    p_auth.add_run("Associate Professor, Economics and Business Studies Department, Mazoon College, Muscat, Sultanate of Oman\nEmail: u78.husain@gmail.com\n").font.size = Pt(9.5)
    
    doc.add_page_break()
    
    # Abstract
    add_heading_1(doc, "Abstract")
    add_body_p(doc, "Forecasting crude oil volatility under geopolitical uncertainty is vital for energy asset pricing, macro-risk surveillance, and financial hedging. This study presents a comprehensive out-of-sample empirical benchmark comparing a 4-qubit Parameterized Quantum Circuit (PQC) kernel regression model (QSVR) against twelve classical benchmark models (yielding thirteen models in total)---including the Heterogeneous Autoregressive model of Realized Volatility (HAR-RV), GARCH(1,1), EGARCH(1,1), and GJR-GARCH(1,1)---as well as classical machine learning regressors (ElasticNet, Linear/Poly/RBF SVR, Random Forest, XGBoost, LightGBM, and PyTorch LSTM).")
    add_body_p(doc, "Using a ten-year daily dataset (2016--2026, N = 2,473 clean trading days) incorporating daily newspaper-based Geopolitical Risk (GPRD), AI-based Geopolitical Risk (AI-GPR), and cross-asset macroeconomic controls, models are evaluated across a 655-day out-of-sample window (2024--2026). Our empirical results establish five core findings:")
    add_body_p(doc, "(1) Multi-component autoregressive models (HAR-RV, RMSE = 0.6708, R2 = 0.7800) and regularized linear shrinkage (SVR-Linear, RMSE = 0.6717; ElasticNet, RMSE = 0.7017) dominate point-forecasting accuracy under symmetric RMSE loss, whereas tree ensembles lead under asymmetric variance-penalizing QLIKE loss (XGBoost, QLIKE = 0.1574).")
    add_body_p(doc, "(2) In a controlled 4-feature experiment where quantum and classical kernel machines operate on identical inputs, the 4-qubit quantum kernel (RMSE = 0.7007, R2 = 0.7600) outperforms classical Gaussian RBF kernel regression (RMSE = 0.7140, R2 = 0.7508), demonstrating that the quantum feature map provides a rich non-linear representation, though linear models still maintain the lowest point error.")
    add_body_p(doc, "(3) While the 4-qubit quantum kernel achieves competitive point accuracy, pairwise Diebold-Mariano tests with Benjamini-Hochberg False Discovery Rate (FDR) adjustments confirm that quantum kernel simulation on classical hardware does not offer statistically significant point-forecast superiority over strong linear benchmarks (pFDR = 0.1712), reframing the contribution as an empirical kernel representation study rather than a computational quantum advantage.")
    add_body_p(doc, "(4) In the full multivariate econometric specification with Newey-West HAC standard errors, lagged daily GPR does not retain statistical significance (beta = 0.0008, t = 1.4243, p = 0.1544; Variance Inflation Factors < 3.0) after controlling for volatility persistence (beta = 0.8860, t = 22.35, p < 0.0001) and equity market volatility (VIX, beta = 0.0250, t = 3.68, p = 0.0002), indicating that autoregressive persistence dominates predictive attribution (accounting for over 96% of permutation importance), while GPR is more useful as a regime-stratification variable than as an incremental daily point predictor.")
    add_body_p(doc, "(5) In formal 95% Value-at-Risk (VaR) backtesting with model-consistent innovation distributions, parametric Student-t GARCH(1,1) and GJR-GARCH models achieve near-nominal unconditional coverage (4.73%--4.89% breaches, passing Kupiec POF tests with p > 0.75), whereas EGARCH is overly conservative (2.90% breaches, Kupiec p = 0.0077) and QSVR is under-conservative (7.79% breaches, Kupiec p = 0.0024) but provides no statistical evidence against the independence null hypothesis (Christoffersen p = 0.5904).")
    
    p_kw = doc.add_paragraph()
    p_kw.paragraph_format.space_before = Pt(8)
    p_kw.paragraph_format.space_after = Pt(4)
    r_kwh = p_kw.add_run("Keywords: ")
    r_kwh.bold = True
    p_kw.add_run("Crude Oil Volatility, Realized Volatility, Geopolitical Risk (GPR), Quantum Machine Learning, Quantum Kernel Regression, HAR-RV, Value-at-Risk (VaR), Kupiec Test, Christoffersen Test, False Discovery Rate (FDR).")
    
    p_jel = doc.add_paragraph()
    p_jel.paragraph_format.space_before = Pt(0)
    p_jel.paragraph_format.space_after = Pt(12)
    r_jelh = p_jel.add_run("JEL Classification: ")
    r_jelh.bold = True
    p_jel.add_run("C22, C53, C58, G17, Q41, Q47.")
    
    doc.add_page_break()
    
    # 1. Introduction
    add_heading_1(doc, "1. Introduction")
    add_body_p(doc, "Crude oil is the foundation of global industrial production, transport networks, and petrochemical supply chains. Consequently, sudden fluctuations in crude oil prices transmit profound shocks throughout the global macroeconomy, influencing sovereign inflation trajectories, central bank monetary stances, and equity market stability (Hamilton, 2003; Kilian, 2009; Baumeister & Kilian, 2016). Predicting WTI crude oil volatility, while accounting for information from Brent and other cross-asset markets, is therefore a central objective for energy hedge funds, commodity risk officers, and clearinghouse margin architects (Alqahtani et al., 2020; Demiralay & Kilincarslan, 2021).")
    add_body_p(doc, "In financial econometrics, the conventional toolkit for modeling conditional volatility relies on Generalized Autoregressive Conditional Heteroskedasticity (GARCH) frameworks (Engle, 1982; Bollerslev, 1986), their asymmetric extensions such as EGARCH (Nelson, 1991) and GJR-GARCH (Glosten et al., 1993), and the Heterogeneous Autoregressive model of Realized Volatility (HAR-RV) (Corsi, 2009). While these parametric specifications effectively capture volatility clustering, mean-reversion, and leverage asymmetries, they often struggle to incorporate high-dimensional, multi-source exogenous signals---such as real-time textual geopolitical risk indices and cross-asset macroeconomic controls---without encountering parameter proliferation and overfitting (Smales, 2021; Liu et al., 2021).")
    add_body_p(doc, "In recent years, the intersection of quantum information theory and machine learning has introduced Quantum Machine Learning (QML) as a potential framework for processing complex, correlated data structures (Biamonte et al., 2017). Recent surveys emphasize the potential of quantum computing for risk analysis and financial modeling (Woerner & Egger, 2019; Orús et al., 2019; Herman et al., 2023), with applications in derivative pricing (Martin et al., 2021) and expressive quantum neural architectures (Abbas et al., 2021; Cerezo et al., 2021). In particular, Parameterized Quantum Circuit (PQC) kernel methods map classical input vectors into high-dimensional quantum Hilbert spaces via non-linear unitary transformations, computing inner-product kernel matrices based on quantum state fidelity overlaps (Havlíček et al., 2019; Schuld & Killoran, 2019; Huang et al., 2021).")
    add_body_p(doc, "This study presents a rigorous, transparent out-of-sample empirical benchmark comparing a 4-qubit PennyLane QSVR model against twelve classical benchmark models (yielding thirteen models in total) across a 10-year daily historical sample (2016--2026, N = 2,473 clean trading days) with an explicit 655-day test window (2024--2026).")
    
    # 2. Literature Review
    add_heading_1(doc, "2. Literature Review")
    add_body_p(doc, "Financial econometricians have traditionally modeled conditional variance through ARCH and GARCH frameworks (Engle, 1982; Bollerslev, 1986; Baillie et al., 1996). In realized volatility modeling, Corsi (2009) established the HAR-RV framework, which captures daily, weekly, and monthly volatility components. In geopolitical risk literature, Caldara and Iacoviello (2022) created the daily newspaper-based GPR index, demonstrating that geopolitical escalations drive macroeconomic contractions and commodity market turbulence (Smales, 2021; Sharif et al., 2020; Bouoiyour & Selmi, 2019). In quantum computing, Havlíček et al. (2019) and Schuld and Killoran (2019) introduced quantum feature maps, laying the mathematical foundation for quantum kernel estimation in financial modeling (Ahmad et al., 2024; Herman et al., 2023).")
    
    # 3. Theoretical Framework
    add_heading_1(doc, "3. Theoretical Framework and Hypotheses")
    add_body_p(doc, "We formulate five formal hypotheses:")
    add_body_p(doc, "H1 (Geopolitical Risk Incremental Significance): We test whether lagged daily geopolitical risk indices (GPRD, AI-GPR) exert a statistically significant positive effect (beta > 0, p < 0.05) on realized crude oil volatility in a dynamic econometric specification after controlling for persistence with Newey-West HAC standard errors.")
    add_body_p(doc, "H2 (Asymmetric Return Innovation Dynamics): Asymmetric volatility specifications will exhibit statistically significant asymmetric responses to crude oil return innovations (gamma != 0, p < 0.05).")
    add_body_p(doc, "H3 (Comparative Point-Forecasting Accuracy): We test whether non-linear classical and quantum kernel transformations provide incremental out-of-sample point-forecasting accuracy relative to parsimonious linear and multi-component autoregressive benchmarks (HAR-RV, ElasticNet, SVR-Linear).")
    add_body_p(doc, "H4 (Quantum Kernel Representation Geometry): The 4-qubit parameterized quantum circuit constructs an empirically distinct feature map in 16-dimensional Hilbert space, exhibiting measurable geometric differences in Kernel-Target Alignment and effective dimension relative to classical linear, polynomial, and RBF kernels.")
    add_body_p(doc, "H5a (No Evidence of Tail-Risk Violation Clustering): In 95% Value-at-Risk (VaR) backtesting, volatility forecasts from non-linear kernel architectures (QSVR, SVR-RBF) will produce tail-risk violation sequences that provide no statistical evidence against the independence null hypothesis in Christoffersen tests (p > 0.05).")
    add_body_p(doc, "H5b (Unconditional Tail-Risk Coverage Consistency): Volatility forecasts will exhibit unconditional coverage consistent with the nominal 5% exceedance probability, passing the Kupiec POF test (p > 0.05).")
    
    # 4. Data and Variables
    add_heading_1(doc, "4. Data, Variables, and Descriptive Statistics")
    add_body_p(doc, "Our empirical dataset covers a ten-year historical span from August 18, 2016, to August 18, 2026. Following an initial 22-trading-day initialization window required to construct the monthly rolling components for HAR-RV and lagged predictors, the final clean dataset comprises N = 2,473 daily trading observations (September 27, 2016 to August 18, 2026).")
    add_body_p(doc, "The primary dependent variable is the 5-day rolling realized standard deviation of WTI crude oil spot returns from FRED (Series DCOILWTICO) and Alpha Vantage. On April 20, 2020, WTI crude oil settled at -$37.63/bbl on NYMEX prompt futures and -$36.98/bbl on spot index. To prevent undefined logarithmic returns, the negative price is interpolated using adjacent valid trading prices ($18.27 on April 17 and $10.01 on April 21 -> $14.14). Table 17 confirms that findings are invariant across three treatments.")
    add_body_p(doc, "All feature-scaling and min-max normalization parameters were estimated exclusively using the training data (2016--2022) and then applied unchanged to validation and test observations.")
    add_body_p(doc, "In the H1 regression, Variance Inflation Factors (VIF) are: GPRD = 2.96, AI-GPR = 2.52, Vol_Lag1 = 1.47, VIX = 1.45, confirming that multicollinearity does not compromise the coefficient estimates.")
    
    add_styled_excel_table(doc, wb, 'VariableDefinitions', "Table 1: Variable Definitions and Empirical Data Sources")
    add_styled_excel_table(doc, wb, 'NegativePriceSensitivity', "Table 17: Sensitivity Analysis: Treatment of April 20, 2020 WTI Negative Price Event")
    add_styled_excel_table(doc, wb, 'SampleSplits', "Table 2: Chronological Sample Splitting and Partition Details (N = 2,473 Trading Days)")
    add_styled_excel_table(doc, wb, 'DescriptiveStats', "Table 3: Descriptive Statistics for Core Variables (2016–2026)")
    add_styled_excel_table(doc, wb, 'Correlations', "Table 4: Pearson Correlation Matrix")
    add_styled_excel_table(doc, wb, 'H1_Regression', "Table 5: Econometric Regression of Realized Volatility on Lagged GPR (Testing H1)")
    
    add_figure_to_docx(doc, "figures/figure_01_wti_price.png", "Figure 1: WTI Crude Oil Daily Spot Price Dynamics (2016–2026, N = 2,473).")
    add_figure_to_docx(doc, "figures/figure_02_wti_returns.png", "Figure 2: WTI Crude Oil Daily Percentage Log Returns.")
    add_figure_to_docx(doc, "figures/figure_03_wti_volatility.png", "Figure 3: WTI Crude Oil 5-Day Rolling Realized Volatility.")
    add_figure_to_docx(doc, "figures/figure_04_gpr.png", "Figure 4: Daily Geopolitical Risk Indices (GPRD and AI-GPR).")
    add_figure_to_docx(doc, "figures/figure_05_gpr_oil_volatility.png", "Figure 5: Co-movement: Realized Volatility vs. Geopolitical Risk Index.")
    add_figure_to_docx(doc, "figures/figure_06_correlation.png", "Figure 6: Pearson Correlation Heatmap across Predictors.")
    
    # 5. Methodology
    add_heading_1(doc, "5. Econometric, Machine Learning, and Quantum Methodology")
    add_body_p(doc, "We benchmark four econometric specifications (GARCH, EGARCH, GJR-GARCH, HAR-RV), six classical ML algorithms (ElasticNet, Linear/Poly/RBF SVR, Random Forest, XGBoost, LightGBM), deep learning PyTorch LSTM, and the 4-qubit PennyLane QSVR model.")
    add_body_p(doc, "In GJR-GARCH, the asymmetric leverage parameter is positive and statistically significant (gamma = 0.0527, t = 2.2154, p = 0.0267). In EGARCH, the asymmetric leverage parameter is negative and statistically significant (gamma = -0.0433, t = -2.6560, p = 0.0079), confirming that negative return shocks generate larger surges in conditional log-variance than positive shocks of identical magnitude, supporting Hypothesis H2 for both asymmetric specifications.")
    add_body_p(doc, "All machine learning hyperparameters were optimized strictly on the 248-day validation partition (2023). For QSVR, validation grid search over C in {0.1, 1.0, 10.0} and epsilon in {0.01, 0.05, 0.1} confirmed C=1.0, epsilon=0.05 with Tikhonov ridge lambda = 1e-5. Four features were selected ex ante based on the hypothesized economic roles of volatility persistence, geopolitical risk, equity-market uncertainty, and return momentum; no test-period information was used in feature selection.")
    add_body_p(doc, "Quantum Kernel Rank: The empirical quantum Gram matrix achieves a numerical rank of 67, exceeding the single-state Hilbert space dimension d=16. This occurs because the quantum kernel computes the fidelity overlap between pure state density operators in the d^2 = 256 dimensional operator space.")
    add_body_p(doc, "Mathematical Bridge: Under local conditional stationarity over the 5-day rolling window, the rolling realized volatility forecast acts as an estimator of the daily conditional standard deviation scale. For Student-t GARCH models, VaR is computed using exact model-consistent Student-t quantiles; for MSE regression models, standard Gaussian quantiles are used.")
    
    add_styled_excel_table(doc, wb, 'EconometricSummary', "Table 6: GARCH, EGARCH, GJR-GARCH, and HAR-RV Parameter Estimates")
    add_styled_excel_table(doc, wb, 'MLConfigs', "Table 7: Machine Learning Benchmark Hyperparameter Configurations")
    add_styled_excel_table(doc, wb, 'QuantumConfigs', "Table 8: Quantum Support Vector Regression Architecture Specification")
    add_styled_excel_table(doc, wb, 'KernelProperties', "Table 9: Quantum vs. Classical Kernel Properties & Target Alignment")
    add_styled_excel_table(doc, wb, 'QuantumRegSensitivity', "Table 20: Numerical Stability and Tikhonov Ridge Regularization Sensitivity Analysis for QSVR Gram Matrix")
    
    # 6. Empirical Results
    add_heading_1(doc, "6. Empirical Forecasting Results and Ablation Analysis")
    add_body_p(doc, "Table 10 reports the feature ablation study across three predictor subsets. Volatility persistence (Subset 1) accounts for the vast majority of point accuracy. Table 11_4F reports the controlled 4-feature experiment, where QSVR (RMSE = 0.7007, R2 = 0.7600) achieves lower RMSE than classical Gaussian SVR-RBF (RMSE = 0.7140, R2 = 0.7508) on identical 4-dimensional inputs, although SVR-RBF remains slightly better under asymmetric QLIKE loss (0.1709 vs. 0.1734), while linear models maintain the lowest point errors.")
    add_body_p(doc, "Table 11 and Table 12 report out-of-sample performance metrics and Diebold-Mariano tests across the 655-day test set. HAR-RV (RMSE = 0.6708, R2 = 0.7800) and SVR-Linear (RMSE = 0.6717) achieve the best point forecasts under symmetric RMSE loss, while tree ensembles lead under asymmetric QLIKE loss. QSVR achieves competitive accuracy (RMSE = 0.7007, R2 = 0.7600, QLIKE = 0.1734), matching ElasticNet (pFDR = 0.9604) and HAR-RV (pFDR = 0.1712) without statistically significant point differences.")
    
    add_styled_excel_table(doc, wb, 'AblationStudy', "Table 10: Feature Ablation Study across Predictor Subsets")
    add_styled_excel_table(doc, wb, 'Controlled4FBenchmark', "Table 11_4F: Controlled 4-Feature Benchmark: Direct Comparison of Quantum vs. Classical Kernels on Identical Information Set")
    add_styled_excel_table(doc, wb, 'ModelPerformance', "Table 11: Out-of-Sample Volatility Forecasting Accuracy Metrics Comparison")
    add_styled_excel_table(doc, wb, 'Key_DM_FDR_Comparisons', "Table 12: Pairwise Diebold-Mariano Predictive Accuracy Tests with HLN Corrections and Benjamini-Hochberg FDR Adjustments")
    
    add_figure_to_docx(doc, "figures/figure_08_actual_vs_predicted.png", "Figure 8: Out-of-Sample Volatility Forecasts vs. Actual Realized Volatility.")
    add_figure_to_docx(doc, "figures/figure_09_model_comparison.png", "Figure 9: Out-of-Sample Root Mean Squared Error (RMSE) Model Comparison.")
    
    # 7. Regime & Robustness
    add_heading_1(doc, "7. Geopolitical Risk Regime Analysis and Robustness Checks")
    add_body_p(doc, "Regime thresholds were estimated strictly on the pre-test sample (2016--2023, N = 1,818: Median = 106.77, 75th percentile = 140.53) and held fixed out-of-sample. Table 13 and Table 14 evaluate performance across Low (N=80), Medium (N=162), and High GPR (N=413) regimes, with 95% bootstrap confidence intervals. HAR-RV (RMSE = 0.7529) and SVR-Linear (RMSE = 0.7534) remain strongest in the high-GPR regime, while QSVR (RMSE = 0.7872) remains competitive.")
    
    add_styled_excel_table(doc, wb, 'RegimeAnalysis', "Table 13: Out-of-Sample Forecasting RMSE across Geopolitical Risk Regimes (Pre-Test Thresholds with 95% Bootstrap CIs)")
    add_styled_excel_table(doc, wb, 'RobustnessTests', "Table 14: Alternative Geopolitical Risk Percentile Threshold Robustness Checks")
    
    add_figure_to_docx(doc, "figures/figure_07_gpr_regimes.png", "Figure 7: Out-of-Sample Test Set Trading Days across Geopolitical Risk Regimes (N = 655: Low = 80, Medium = 162, High = 413).")
    add_figure_to_docx(doc, "figures/figure_10_regime_comparison.png", "Figure 10: Forecasting RMSE across Geopolitical Risk Regimes for Selected Specifications.")
    
    # 8. Explainability
    add_heading_1(doc, "8. Model Explainability and Quantum Sensitivity")
    add_body_p(doc, "Permutation importance analysis confirms that lagged realized volatility accounts for 96.56% of the normalized permutation-importance measure for XGBoost, while GPR_OIL (1.50%), Brent returns (0.66%), and Gas returns (0.46%) provide the highest incremental attributions. In the QSVR model, wire gradient sensitivity indicates that the first wire (Vol_Lag1) contributes 98.68% of the aggregate QSVR wire sensitivity.")
    
    add_figure_to_docx(doc, "figures/figure_11_shap.png", "Figure 11: Top 10 Feature Importances from Permutation Analysis.")
    
    # 9. Risk Management & Portfolio
    add_heading_1(doc, "9. Economic Risk Management and Portfolio Backtesting")
    add_body_p(doc, "Table 15 reports 95% Value-at-Risk backtesting results with associated Expected Shortfall (CVaR) estimates using model-consistent innovation distributions. Parametric Student-t GARCH(1,1) and GJR-GARCH models achieve near-nominal 5% coverage (GARCH: 32 breaches, 4.89%, Kupiec p = 0.8927; GJR: 31 breaches, 4.73%, Kupiec p = 0.7517, supporting H5b), whereas EGARCH is overly conservative (19 breaches, 2.90%, Kupiec p = 0.0077). QSVR and SVR-RBF fail to reject the null hypothesis of independent VaR-hit occurrences (Christoffersen p = 0.5904, consistent with H5a), despite higher unconditional breach rates (7.79%, rejecting H5b for ML models).")
    add_body_p(doc, "Table 16 and Table 18 report volatility-targeting portfolio backtest results with Compound Annual Growth Rates (CAGR) and transaction cost sensitivity. HAR-RV (+10.64%, CAGR = 3.97%, Sharpe 0.298), SVR-Linear (+9.63%, CAGR = 3.60%), and QSVR (+8.91%, CAGR = 3.34%, Sharpe 0.268) generated higher cumulative net returns and lower maximum drawdowns than passive buy-and-hold over the reported 2024--2026 test window (which suffered a loss of -3.86%, CAGR = -1.51%, and max drawdown of -42.84%) across cost levels from 1 to 10 bps, turning slightly negative at 20 bps.")
    
    add_styled_excel_table(doc, wb, 'RiskManagement', "Table 15: Economic Risk Management: 95% Value-at-Risk (VaR) Coverage Backtesting with Associated Expected Shortfall (CVaR) Estimates (Model-Consistent Distributions)")
    add_styled_excel_table(doc, wb, 'PortfolioPerformance', "Table 16: Economic Significance: Volatility-Targeting Portfolio Performance (5 bps Cost)")
    add_styled_excel_table(doc, wb, 'CostSensitivity', "Table 18: Transaction Cost Sensitivity Analysis (1 to 20 bps)")
    
    add_figure_to_docx(doc, "figures/figure_12_economic_performance.png", "Figure 12: Cumulative Portfolio Returns for Volatility-Targeting Strategy.")
    
    # 10. Discussion & Hypothesis Decisions
    add_heading_1(doc, "10. Discussion, Hypothesis Decisions, and Conclusion")
    add_body_p(doc, "Table 19 summarizes the empirical decisions across the five formal hypotheses.")
    add_styled_excel_table(doc, wb, 'HypothesisSummary', "Table 19: Summary of Formal Hypothesis Testing Decisions")
    add_body_p(doc, "Our findings demonstrate that HAR-RV and linear shrinkage baselines dominate daily volatility point forecasting under RMSE, while 4-qubit Quantum SVR provides a competitive non-linear kernel representation with VaR-hit sequences for which independence is not rejected (Christoffersen p = 0.5904), although unconditional 95% VaR coverage is rejected, consistent with the use of symmetric MSE-based training rather than tail-focused loss functions. We emphasize the distinction between quantum kernel simulation on classical hardware and genuine quantum computational advantage. Geopolitical risk measures serve primarily as regime-stratification variables and tail-risk stress indicators rather than primary drivers of daily point volatility.")
    
    # Declarations
    doc.add_page_break()
    add_heading_1(doc, "Declaration of Generative AI and AI-Assisted Technologies")
    add_body_p(doc, "During the preparation of this work, the authors used Anthropic Claude and Google DeepMind AI tools in order to assist with code optimization, data processing, and manuscript editing for clarity and formatting. After using these tools, the authors reviewed and edited the content as needed and take full responsibility for the content of the published article.")
    
    add_heading_1(doc, "Data Availability Statement")
    add_body_p(doc, "The empirical data and Python code used to support the findings of this study are available in the project repository at https://github.com/rsoorat/Quantum-Oil-GPR-Benchmark.")
    
    add_heading_1(doc, "Conflict of Interest Statement")
    add_body_p(doc, "The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.")
    
    # References
    doc.add_page_break()
    add_heading_1(doc, "References")
    
    with open("references.bib", "r", encoding="utf-8") as f:
        bib_content = f.read()
    import re
    entries = re.split(r'@\w+\s*\{', bib_content)[1:]
    refs = []
    for entry in entries:
        fields = {}
        for match in re.finditer(r'(\w+)\s*=\s*[\{](.*?)[}]', entry, re.DOTALL):
            fields[match.group(1).lower()] = match.group(2).strip().replace('\n', ' ')
        author = fields.get('author', '')
        year = fields.get('year', '')
        title = fields.get('title', '').replace('{', '').replace('}', '')
        journal = fields.get('journal', fields.get('booktitle', fields.get('publisher', '')))
        volume = fields.get('volume', '')
        pages = fields.get('pages', '').replace('--', '-')
        doi = fields.get('doi', '')
        howpublished = fields.get('howpublished', '')
        author_list = [a.strip() for a in author.split(' and ')]
        clean_authors = []
        for a in author_list:
            if ',' in a:
                parts = a.split(',')
                last = parts[0].strip()
                first = parts[1].strip()
                inits = '.'.join([p[0] for p in first.split() if p]) + '.'
                clean_authors.append(f'{last}, {inits}')
            else:
                parts = a.split()
                if len(parts) > 1:
                    last = parts[-1]
                    first = ' '.join(parts[:-1])
                    inits = '.'.join([p[0] for p in first.split() if p]) + '.'
                    clean_authors.append(f'{last}, {inits}')
                else:
                    clean_authors.append(a)
        if len(clean_authors) > 2:
            auth_str = ', '.join(clean_authors)
        elif len(clean_authors) == 2:
            auth_str = f'{clean_authors[0]}, {clean_authors[1]}'
        elif clean_authors:
            auth_str = clean_authors[0]
        else:
            auth_str = ''
        ref_line = f'{auth_str}, {year}. {title}.'
        if journal:
            ref_line += f' {journal}'
            if volume:
                ref_line += f' {volume}'
            if pages:
                ref_line += f', {pages}.'
            else:
                ref_line += '.'
        elif howpublished:
            ref_line += f' {howpublished}.'
        if doi:
            ref_line += f' https://doi.org/{doi}'
        refs.append(ref_line)
    refs.sort()
    
    for ref_str in refs:
        p_ref = doc.add_paragraph()
        p_ref.paragraph_format.space_before = Pt(0)
        p_ref.paragraph_format.space_after = Pt(4)
        p_ref.paragraph_format.left_indent = Inches(0.5)
        p_ref.paragraph_format.first_line_indent = Inches(-0.5)
        run_ref = p_ref.add_run(ref_str)
        run_ref.font.name = 'Calibri'
        run_ref.font.size = Pt(10)
        
    doc.save("Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript.docx")
    print("Full Word manuscript generated successfully: Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript.docx")

if __name__ == "__main__":
    main()
