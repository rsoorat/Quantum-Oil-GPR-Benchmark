# Quantum Kernel Regression and Geopolitical Risk in Crude Oil Volatility Forecasting: An Empirical Out-of-Sample Benchmark

[![Python 3.11](https://img.shields.io/badge/python-3.11-blue.svg)](https://www.python.org/downloads/release/python-3110/)
[![PennyLane 0.45.1](https://img.shields.io/badge/PennyLane-0.45.1-brightgreen.svg)](https://pennylane.ai/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

This repository contains the complete empirical replication package, dataset pipelines, PennyLane quantum circuit implementations, econometric specifications, and machine learning models for the research paper:

> **"Quantum Kernel Regression and Geopolitical Risk in Crude Oil Volatility Forecasting: An Empirical Out-of-Sample Benchmark"**  
> *Target Journal:* **Cogent Business & Management** (Taylor & Francis Group / Cogent OA, ISSN: 2331-1975)  
> *Authors:* **Ram Soorat**, **Afzalur Rahman**, **Priyanka**, and **Dr. Uvesh Husain** *(Corresponding Author)*

---

## 📁 Repository Structure

* `code/`: Complete, automated Python modeling and compilation pipeline:
  1. `01_data_download.py`: Ingestion of FRED WTI spot prices, Iacoviello GPR/AI-GPR daily indices, and cross-asset controls.
  2. `02_data_cleaning.py`: Log returns, missing value interpolation, and ADF / PP stationarity tests.
  3. `03_feature_engineering.py`: 5-day rolling realized standard deviations, HAR components (daily, weekly, monthly), and technical indicators.
  4. `04_descriptive_statistics.py`: Summary statistics, Pearson correlation matrix, and ARCH-LM tests.
  5. `05_econometric_models.py`: Parametric GARCH(1,1), EGARCH(1,1), and GJR-GARCH(1,1) under standardized Student-$t$ errors.
  6. `06_classical_ml.py`: ElasticNet, SVR (Linear, Poly, RBF), Random Forest, XGBoost, and LightGBM.
  7. `07_lstm_model.py`: PyTorch LSTM recurrent neural network.
  8. `08_quantum_model.py`: 4-qubit Parameterized Quantum Circuit (PQC) statevector simulator in PennyLane with circular CNOT entanglement.
  9. `09_walk_forward_validation.py`: Expanding-window recursive walk-forward validation (655-day test sample, 2024–2026).
  10. `10_statistical_tests.py`: Pairwise Diebold-Mariano predictive accuracy tests with Harvey-Leybourne-Newbold corrections and Benjamini-Hochberg FDR adjustments.
  11. `11_shap_analysis.py`: TreeSHAP and permutation feature importances.
  12. `12_robustness_tests.py`: GPR regime partitioning (Low, Medium, High) with 95% bootstrap CIs and 80th/90th percentile threshold checks.
  13. `13_generate_figures.py`: Publication-ready 300 DPI figures.
  14. `14_generate_tables.py`: Fills master spreadsheet tables.
  15. `15_reproducibility_report.py`: End-to-end verification and diagnostic checks.
  16. `generate_manuscript_tex.py`: Generates the complete master LaTeX source.
  17. `generate_docx.py`: Compiles the master Word (.docx) document with embedded figures and tables.
  18. `generate_supplementary.py`: Generates the Supplementary Appendix (LaTeX and DOCX).
  19. `generate_cover_letter.py`: Generates the 1-page submission Cover Letter (LaTeX and DOCX).
  20. `generate_graphical_abstract.py`: Generates the 300 DPI high-resolution Graphical Abstract.
* `data/`: Raw and preprocessed CSV datasets (2016–2026, $N = 2,473$ daily trading observations).
* `figures/`: High-resolution figures (`figure_01` to `figure_12`) and `graphical_abstract.png`.
* `tables.xlsx`: Complete 21-sheet empirical tables workbook.
* `statistical_results.xlsx`: Detailed model out-of-sample metrics, loss values, and statistical tests.
* `references.bib`: BibTeX bibliography file with 44 curated research references.
* `Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript.pdf` / `.tex` / `.docx`: Master submission manuscript.
* `supplementary_material.pdf` / `.tex` / `.docx`: Supplementary Appendix document.
* `cover_letter.pdf` / `.tex` / `.docx`: Journal Cover Letter.

---

## ⚙️ Installation & Requirements

1. **Clone the repository:**
   ```bash
   git clone https://github.com/rsoorat/Quantum-Oil-GPR-Benchmark.git
   cd Quantum-Oil-GPR-Benchmark
   ```

2. **Create and activate a virtual environment:**
   ```bash
   python -m venv .venv
   # On Windows:
   .venv\Scripts\activate
   # On Linux/macOS:
   source .venv/bin/activate
   ```

3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

---

## 🚀 Reproduction Pipeline

To reproduce all empirical results, models, tables, and figures from scratch, run:

```bash
python code/15_reproducibility_report.py
```

To recompile all submission deliverables (PDFs, DOCX, TeX):

```bash
python code/generate_cover_letter.py
python code/generate_supplementary.py
python code/generate_manuscript_tex.py
python code/generate_docx.py
python code/generate_graphical_abstract.py
```

---

## 📜 Citation & License

If you use this code or benchmark in your research, please cite:

```bibtex
@article{soorat2026quantum,
  title={Quantum Kernel Regression and Geopolitical Risk in Crude Oil Volatility Forecasting: An Empirical Out-of-Sample Benchmark},
  author={Soorat, Ram and Rahman, Afzalur and Priyanka and Husain, Uvesh},
  journal={Cogent Business \& Management},
  year={2026}
}
```

This repository is distributed under the **MIT License**.
