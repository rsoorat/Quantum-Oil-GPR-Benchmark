# Empirical Pipeline Reproducibility Report

Overall Status: **PASSED**

## 1. Execution Log

| Script | Status | Details |
|---|---|---|
| code/01_data_download.py | PASSED | Success |
| code/02_data_cleaning.py | PASSED | Success |
| code/03_feature_engineering.py | PASSED | Success |
| code/04_descriptive_statistics.py | PASSED | Success |
| code/05_econometric_models.py | PASSED | Success |
| code/09_walk_forward_validation.py | PASSED | Success |
| code/10_statistical_tests.py | PASSED | Success |
| code/11_shap_analysis.py | PASSED | Success |
| code/12_robustness_tests.py | PASSED | Success |
| code/13_generate_figures.py | PASSED | Success |
| code/14_generate_tables.py | PASSED | Success |

## 2. Output File Verification

| Required File | Verification Status | Size |
|---|---|---|
| data/raw_wti_data.csv | PASSED | 46305 bytes |
| data/clean_wti_dataset.csv | PASSED | 477419 bytes |
| data/oil_model_dataset.csv | PASSED | 1764306 bytes |
| data/oil_model_predictions.csv | PASSED | 35673 bytes |
| tables.xlsx | PASSED | 24873 bytes |
| statistical_results.xlsx | PASSED | 12935 bytes |
| figures/figure_01_wti_price.png | PASSED | 199026 bytes |
| figures/figure_02_wti_returns.png | PASSED | 183316 bytes |
| figures/figure_03_wti_volatility.png | PASSED | 208918 bytes |
| figures/figure_04_gpr.png | PASSED | 433158 bytes |
| figures/figure_05_gpr_oil_volatility.png | PASSED | 398368 bytes |
| figures/figure_06_correlation.png | PASSED | 286797 bytes |
| figures/figure_07_gpr_regimes.png | PASSED | 91874 bytes |
| figures/figure_08_actual_vs_predicted.png | PASSED | 413684 bytes |
| figures/figure_09_model_comparison.png | PASSED | 115752 bytes |
| figures/figure_10_regime_comparison.png | PASSED | 111243 bytes |
| figures/figure_11_shap.png | PASSED | 142898 bytes |
| figures/figure_12_economic_performance.png | PASSED | 421318 bytes |
