[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.22840954.svg)](https://doi.org/10.5281/zenodo.22840954)
# Quantum Kernel Methods for Crude Oil Volatility Forecasting under Geopolitical Risk: A Controlled Out-of-Sample Benchmark

[![Python 3.11.9](https://img.shields.io/badge/python-3.11.9-blue.svg)](https://www.python.org/downloads/release/python-3119/)
[![PennyLane 0.45.1](https://img.shields.io/badge/PennyLane-0.45.1-brightgreen.svg)](https://pennylane.ai/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

This repository contains the complete empirical replication package, dataset pipelines, PennyLane quantum circuit implementations, econometric specifications, and machine learning models for the research paper:

> **"Quantum Kernel Methods for Crude Oil Volatility Forecasting under Geopolitical Risk: A Controlled Out-of-Sample Benchmark"**  
> *Target Journal / Publication:* **F1000Research** (ISSN: 2046-1402)  
> *Authors:* **Hamood Amur Al Wardi**, **Uvesh Husain**, **Shylaja H N** *(Corresponding Author)*, **Ram Soorat**, **Priyanka**, and **Afzalur Rahman**

### 👥 Author Information & ORCID Registry

| Author Name | Role | Affiliation | Verified ORCID iD |
|:---|:---|:---|:---|
| **Hamood Amur Al Wardi** | Co-Author | Mazoon College, Muscat, Oman | [0009-0006-5697-5159](https://orcid.org/0009-0006-5697-5159) |
| **Uvesh Husain** | Co-Author | Mazoon College, Muscat, Oman | [0000-0002-8502-8488](https://orcid.org/0000-0002-8502-8488) |
| **Shylaja H N** | Corresponding Author | Manipal Academy of Higher Ed., India | [0000-0001-9807-8575](https://orcid.org/0000-0001-9807-8575) |
| **Ram Soorat** | Co-Author | Woxsen University, Hyderabad, India | [0000-0001-7875-9197](https://orcid.org/0000-0001-7875-9197) |
| **Priyanka** | Co-Author | University of Delhi, Delhi, India | [0009-0008-1520-0706](https://orcid.org/0009-0008-1520-0706) |
| **Afzalur Rahman** | Co-Author | Woxsen University, Hyderabad, India | [0000-0002-1561-561X](https://orcid.org/0000-0002-1561-561X) |

---

## ⚠️ Data Access Notice

All **analysis code**, quantum-circuit implementations, and **derived datasets** used for replication are made available through this repository, **subject to the terms of the underlying data providers**:

| Data Source | Provider | Access |
|-------------|----------|--------|
| WTI Crude Oil spot prices | [FRED (DCOILWTICO)](https://fred.stlouisfed.org/series/DCOILWTICO) | Open (FRED API) |
| Daily GPR Index | [Matteo Iacoviello](https://www.matteoiacoviello.com/gpr.htm) | Open (direct download) |
| AI-GPR / GPR_OIL Index | [Iacoviello & Tong](https://www.matteoiacoviello.com/gpr.htm) | Open (direct download) |
| VIX, Gold, DXY, Natural Gas, Brent, Treasury Yield | Yahoo Finance | Open (Yahoo Finance API) |

**Data download date:** August 18, 2026. Exact API endpoints are documented in `code/01_data_download.py` and in the manuscript's Table 1 (Variable Definitions).

---

## 📁 Repository Structure

* `code/`: Complete, automated Python modeling and compilation pipeline:
  1. `01_data_download.py`: Ingestion of FRED WTI spot prices, Iacoviello GPR/AI-GPR daily indices, and cross-asset controls.
  2. `02_data_cleaning.py`: Log returns, missing value interpolation, and ADF / PP stationarity tests.
  3. `03_feature_engineering.py`: 5-day rolling realized standard deviations, HAR components (daily, weekly, monthly), and technical indicators.
  4. `04_descriptive_statistics.py`: Summary statistics, Pearson correlation matrix, and ARCH-LM tests.
  5. `05_econometric_models.py`: Parametric GARCH(1,1), EGARCH(1,1), and GJR-GARCH(1,1) under standardized Student-t errors.
  6. `06_classical_ml.py`: ElasticNet, SVR (Linear, Poly, RBF), Random Forest, XGBoost, and LightGBM.
  7. `07_lstm_model.py`: PyTorch LSTM recurrent neural network.
  8. `08_quantum_model.py`: 4-qubit Parameterized Quantum Circuit (PQC) statevector simulator in PennyLane with circular CNOT entanglement.
  9. `09_walk_forward_validation.py`: Expanding-window recursive walk-forward validation (655-day test sample, 2024–2026).
  10. `10_statistical_tests.py`: Pairwise Diebold-Mariano predictive accuracy tests with Harvey-Leybourne-Newbold corrections and Benjamini-Hochberg FDR adjustments.
  11. `11_shap_analysis.py`: TreeSHAP and permutation feature importances.
  12. `12_robustness_tests.py`: GPR regime partitioning (Low, Medium, High) with 95% bootstrap CIs, 80th/90th percentile threshold checks, and 4D portfolio sensitivity.
  13. `13_generate_figures.py`: Publication-ready 300 DPI figures.
  14. `14_generate_tables.py`: Fills master spreadsheet tables.
  15. `15_reproducibility_report.py`: End-to-end verification and diagnostic checks.
  16. `generate_manuscript_tex.py`: Generates the complete master LaTeX source.
  17. `generate_docx.py`: Compiles the master Word (.docx) document with embedded figures and tables.
  18. `generate_supplementary.py`: Generates the Supplementary Appendix (LaTeX and DOCX).
  19. `generate_cover_letter.py`: Generates the 1-page submission Cover Letter (LaTeX and DOCX).
  20. `generate_graphical_abstract.py`: Generates the 300 DPI high-resolution Graphical Abstract.
* `data/`: Raw and preprocessed CSV datasets (2016–2026, N = 2,473 daily trading observations).
* `figures/`: High-resolution figures (`figure_01` to `figure_12`) and `graphical_abstract.png`.
* `tables.xlsx`: Complete 21-sheet empirical tables workbook.
* `statistical_results.xlsx`: Detailed model out-of-sample metrics, loss values, and statistical tests.
* `references.bib`: BibTeX bibliography file with curated research references.
* `Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript.pdf` / `.tex` / `.docx`: Master submission manuscript.
* `supplementary_material.pdf` / `.tex` / `.docx`: Supplementary Appendix document.
* `cover_letter.pdf` / `.tex` / `.docx`: Journal Cover Letter.

---

## ⚙️ Installation & Requirements

### Python Environment

| Package | Version |
|---------|---------|
| Python | 3.11.9 |
| PennyLane | 0.45.1 |
| scikit-learn | 1.4.1 |
| Statsmodels | 0.14.1 |
| ARCH | 6.3 |
| PyTorch | 2.2.1 |
| XGBoost | 2.0.3 |
| LightGBM | 4.3.0 |
| Pandas | 2.2.1 |
| NumPy | 1.26.4 |
| openpyxl | ≥ 3.1 |
| python-docx | ≥ 1.1 |

**Operating system:** Tested on Windows 11 (x86-64).  
**Hardware:** All quantum circuits use PennyLane `default.qubit` (CPU statevector simulation); no GPU required.

1. **Clone the repository:**
   ```bash
   git clone https://github.com/rsoorat/Quantum-Oil-GPR-Benchmark.git
   cd Quantum-Oil-GPR-Benchmark
   ```

2. **Create and activate a virtual environment:**
   ```bash
   python -m venv .venv
   # On Windows:
   .venv\Scripts\activate
   # On Linux/macOS:
   source .venv/bin/activate
   ```

3. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

---

## 🔁 Reproducibility

### Random Seeds

All stochastic components use **`seed = 42`** throughout:

```python
import numpy as np, random, torch
random.seed(42)
np.random.seed(42)
torch.manual_seed(42)
torch.use_deterministic_algorithms(True)  # where supported
```

The LSTM model (`07_lstm_model.py`) sets both NumPy and PyTorch seeds before training. Tree-based models (XGBoost, LightGBM, Random Forest) use `random_state=42`.

### One-Command Replication

To reproduce **all** empirical results, models, tables, and figures from scratch, run the pipeline in order:

```bash
# Step 1 — Download all data
python code/01_data_download.py

# Step 2–3 — Clean and engineer features
python code/02_data_cleaning.py
python code/03_feature_engineering.py

# Steps 4–12 — Run all models, tests, explainability, and robustness
python code/04_descriptive_statistics.py
python code/05_econometric_models.py
python code/06_classical_ml.py
python code/07_lstm_model.py
python code/08_quantum_model.py
python code/09_walk_forward_validation.py
python code/10_statistical_tests.py
python code/11_shap_analysis.py
python code/12_robustness_tests.py

# Steps 13–15 — Generate outputs
python code/13_generate_figures.py
python code/14_generate_tables.py
python code/15_reproducibility_report.py
```

To recompile all submission deliverables (PDFs, DOCX, TeX):

```bash
python code/generate_cover_letter.py
python code/generate_supplementary.py
python code/generate_manuscript_tex.py
python code/generate_docx.py
python code/generate_graphical_abstract.py
```

### Reproducibility Notes

- **Quantum kernel:** The `default.qubit` statevector simulator is deterministic given fixed inputs; no additional seed is required for the quantum circuit itself.
- **LSTM:** Results may vary slightly across operating systems or PyTorch versions due to floating-point ordering differences in parallel operations, even with seeds set. The reported RMSE = 0.7382 was obtained on the configuration listed above.
- **Data vintage:** Exact replication requires downloading data as of **August 18, 2026**. Later downloads may include data revisions or extended series.

---

## 🔬 Key Empirical Findings

| Objective | Best Model | Key Metric |
|-----------|-----------|------------|
| Point volatility (RMSE) | HAR-RV-type | RMSE = 0.6708, R² = 0.780 |
| Linear ML forecast | SVR-Linear | RMSE = 0.6717 |
| QLIKE / asymmetric loss | XGBoost | QLIKE = 0.1574 |
| VaR tail calibration | GARCH / GJR-GARCH | 4.73–4.89% breach rate; Kupiec p > 0.75 |
| Quantum kernel research | QSVR vs RBF-SVR | QSVR RMSE 0.7007 < RBF 0.7140 (controlled 4-feature) |
| Regime / stress analysis | GPR indicators | 413/655 (63%) test obs in high-GPR regime |

> **Important:** QSVR fails unconditional VaR coverage (7.79% breach rate, Kupiec p = 0.0024). It should not be used as a standalone tail-risk model without further distributional calibration.

---

## 📜 Citation & License

If you use this code or benchmark in your research, please cite:

```bibtex
@article{wardi2026quantum,
  title={Quantum Kernel Methods for Crude Oil Volatility Forecasting under Geopolitical Risk: A Controlled Out-of-Sample Benchmark},
  author={Al Wardi, Hamood Amur and Husain, Uvesh and Shylaja, H. N. and Soorat, Ram and Priyanka and Rahman, Afzalur},
  journal={Journal of Commodity Markets},
  year={2026}
}
```

This repository is distributed under the **MIT License**.
