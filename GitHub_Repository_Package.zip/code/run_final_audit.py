import fitz, re, sys

sys.stdout.reconfigure(encoding='utf-8')

print("================ FINAL PRE-SUBMISSION AUDIT REPORT ================")

# 1. Main Manuscript
doc_m = fitz.Document("Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript.pdf")
def clean_text(doc):
    raw = " ".join([p.get_text() for p in doc])
    # remove hyphenation across line breaks
    dehyphen = re.sub(r'(\w+)-\s*\n\s*(\w+)', r'\1\2', raw)
    return re.sub(r'\s+', ' ', dehyphen).strip()

doc_s = fitz.Document("supplementary_material.pdf")
text_m = clean_text(doc_m)
text_s = clean_text(doc_s)

eq2_pass = "Volt,5" in text_m
har_count = text_m.count("HAR-RV-type")
abs_pass = "suggesting that GPR may be more informative" in text_m
port_pass = "lower realized portfolio volatility" in text_m
q_m = len(re.findall(r"\bTable\s*\?\?", text_m))

print(f"[Check 1] Manuscript Equation (2) uses Volt,5: {'PASS' if eq2_pass else 'FAIL'}")
print(f"[Check 4] Table 21 / Framework uses HAR-RV-type: {'PASS' if har_count >= 20 else 'FAIL'} ({har_count} occurrences)")
print(f"[Check 5] Abstract uses 'suggesting that GPR may be more informative': {'PASS' if abs_pass else 'FAIL'}")
print(f"[Check 6] Portfolio uses 'lower realized portfolio volatility': {'PASS' if port_pass else 'FAIL'}")

supp_sens_pass = ("Overall performance remains qualitatively similar" in text_s and 
                  "QSVR attains the highest Sharpe ratio at the 20% target" in text_s)
supp_rob_pass = (("principal modelperformance hierarchy" in text_s or
                  ("principal model" in text_s and "hierarchy remains stable" in text_s)) and 
                 "complete empirical invariance" not in text_s)
q_s = len(re.findall(r"\bTable\s*\?\?", text_s))

print(f"[Check 2] Supplementary Target-Vol Sensitivity narrative updated: {'PASS' if supp_sens_pass else 'FAIL'}")
print(f"[Check 3] Supplementary Robustness uses 'principal model-performance hierarchy': {'PASS' if supp_rob_pass else 'FAIL'}")
print(f"[Check 7] Undefined Table placeholders (Table ??): Manuscript: {q_m} | Supplementary: {q_s} -> {'PASS' if q_m == 0 and q_s == 0 else 'FAIL'}")

print("===================================================================")
