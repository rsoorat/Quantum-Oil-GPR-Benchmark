import openpyxl
import os

def load_table_as_latex(ws, label, caption, custom_headers=None, max_rows=None, is_wide=False):
    all_rows = list(ws.iter_rows(values_only=True))
    if not all_rows:
        return ""
    
    if len(all_rows) > 2 and all_rows[0][0] and str(all_rows[0][0]).startswith("Table "):
        headers = list(all_rows[2])
        data_rows = all_rows[3:]
    else:
        headers = list(all_rows[0])
        data_rows = all_rows[1:]
        
    if custom_headers:
        headers = custom_headers
        
    if headers and (headers[0] is None or str(headers[0]).strip() == '' or str(headers[0]).lower() == 'nan'):
        headers[0] = 'Model / Benchmark'
        
    n_cols = len(headers)
    if max_rows:
        data_rows = data_rows[:max_rows]
        
    clean_headers = []
    for h in headers:
        h_str = "" if h is None else str(h)
        h_str = h_str.replace('$', r'\$').replace('%', r'\%').replace('_', r'\_').replace('&', r'\&').replace('^', r'\textasciicircum{}').replace('<', r'$<$').replace('>', r'$>$')
        clean_headers.append(r"\textbf{" + h_str + r"}")
    header_str = " & ".join(clean_headers) + r" \\"
    
    rows_str = []
    for row in data_rows:
        row_cells = []
        for i, val in enumerate(row):
            col_name = str(headers[i]) if i < len(headers) and headers[i] is not None else ""
            if val is None or str(val).strip().lower() == 'nan':
                txt = "--"
            elif isinstance(val, (int, float)):
                if isinstance(val, int) or (isinstance(val, float) and val.is_integer() and col_name in ['Observations', '95% VaR Breaches', 'Breaches', 'Observations (Trading Days)', 'QSVR 95% VaR Breaches', 'VaR Breaches', 'Matrix Rank']):
                    txt = f"{int(val):,}"
                elif abs(val) < 0.0001 and val != 0:
                    txt = f"{val:.2e}"
                elif abs(val) < 1.0:
                    txt = f"{val:.4f}"
                elif abs(val) < 100.0:
                    txt = f"{val:.4f}"
                else:
                    txt = f"{val:,.2f}"
            else:
                txt = str(val).replace('$', r'\$').replace('%', r'\%').replace('_', r'\_').replace('&', r'\&').replace('^', r'\textasciicircum{}').replace('<', r'$<$').replace('>', r'$>$')
            row_cells.append(txt)
        rows_str.append(" & ".join(row_cells) + r" \\")
        
    body_str = "\n".join(rows_str)
    clean_caption = str(caption).replace('%', r'\%').replace('_', r'\_').replace('&', r'\&')
    
    wide_open = r"\begin{table}[!htbp]" if is_wide else r"\begin{table}[!htbp]"
    wide_close = r"\end{table}" if is_wide else r"\end{table}"
    
    # Specific column width formatting for descriptive/text-heavy tables
    if label == "tab:variables":
        return r"""\begin{table}[!htbp]
\centering
\small
\caption{""" + clean_caption + r"""}
\label{""" + label + r"""}
\begin{tabularx}{\textwidth}{p{2.3cm}p{3.8cm}p{2.8cm}>{\raggedright\arraybackslash}X}
\toprule
""" + header_str + r"""
\midrule
""" + body_str + r"""
\bottomrule
\end{tabularx}
\end{table}"""

    if label == "tab:splits":
        return r"""\begin{table}[!htbp]
\centering
\small
\caption{""" + clean_caption + r"""}
\label{""" + label + r"""}
\begin{tabularx}{\textwidth}{p{3.2cm}p{2.6cm}p{2.6cm}p{2.8cm}>{\raggedright\arraybackslash}X}
\toprule
""" + header_str + r"""
\midrule
""" + body_str + r"""
\bottomrule
\end{tabularx}
\end{table}"""

    if label == "tab:ml_configs":
        return r"""\begin{table}[!htbp]
\centering
\small
\caption{""" + clean_caption + r"""}
\label{""" + label + r"""}
\begin{tabularx}{\textwidth}{p{2.8cm}p{6.5cm}>{\raggedright\arraybackslash}X}
\toprule
""" + header_str + r"""
\midrule
""" + body_str + r"""
\bottomrule
\end{tabularx}
\end{table}"""

    if label == "tab:quantum_configs":
        return r"""\begin{table}[!htbp]
\centering
\small
\caption{""" + clean_caption + r"""}
\label{""" + label + r"""}
\begin{tabularx}{\textwidth}{p{3.5cm}p{4.5cm}>{\raggedright\arraybackslash}X}
\toprule
""" + header_str + r"""
\midrule
""" + body_str + r"""
\bottomrule
\end{tabularx}
\end{table}"""

    if label == "tab:hyp_summary":
        return r"""\begin{table}[!htbp]
\centering
\small
\caption{""" + clean_caption + r"""}
\label{""" + label + r"""}
\begin{tabularx}{\textwidth}{p{2.6cm}p{3.4cm}p{4.2cm}>{\raggedright\arraybackslash}X}
\toprule
""" + header_str + r"""
\midrule
""" + body_str + r"""
\bottomrule
\end{tabularx}
\end{table}"""

    # Custom Clean Formatting for Table 10 (tab:kernel_props)
    if label == "tab:kernel_props":
        return r"""\begin{table}[!htbp]
\centering
\small
\caption{Quantum vs. Classical Kernel Geometric Properties and Target Alignment}
\label{tab:kernel_props}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lcccc}
\toprule
\textbf{Kernel Architecture} & \textbf{Kernel-Target Alignment $A(K, \mathbf{y})$} & \textbf{Effective Dimension} & \textbf{Matrix Rank} & \textbf{Condition Number $\kappa(K)$} \\
\midrule
Linear Kernel & 0.4753 & 1.4570 & 4 & $4.89 \times 10^{15}$ \\
Polynomial ($d=2$) Kernel & 0.4841 & 1.6177 & 15 & $5.00 \times 10^{15}$ \\
Gaussian RBF Kernel & 0.2658 & 3.2302 & 239 & $1.15 \times 10^{15}$ \\
Quantum PQC (4-Qubit) Kernel & 0.3178 & 1.6868 & 67 & $1.40 \times 10^{15}$ \\
\bottomrule
\end{tabular}%
}
\end{table}"""

    # Custom Clean Formatting for Table 11 (tab:qreg_sens)
    if label == "tab:qreg_sens":
        return r"""\begin{table}[!htbp]
\centering
\small
\caption{Numerical Stability and Tikhonov Ridge Regularization Sensitivity Analysis for QSVR Gram Matrix}
\label{tab:qreg_sens}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lcccc}
\toprule
\textbf{Ridge Regularization $\lambda$} & \textbf{Condition Number $\kappa(K_{\text{reg}})$} & \textbf{Out-of-Sample RMSE} & \textbf{Out-of-Sample $R^2$} & \textbf{95\% VaR Breaches} \\
\midrule
$10^{-7}$ & $1.40 \times 10^{15}$ & 0.7007 & 0.7600 & 51 \\
$10^{-5}$ (Baseline) & $1.00 \times 10^{5}$ & 0.7007 & 0.7600 & 51 \\
$10^{-4}$ & $1.00 \times 10^{4}$ & 0.7008 & 0.7599 & 51 \\
$10^{-3}$ & $1.00 \times 10^{3}$ & 0.7012 & 0.7596 & 51 \\
$10^{-2}$ & $1.00 \times 10^{2}$ & 0.7045 & 0.7574 & 52 \\
\bottomrule
\end{tabular}%
}
\end{table}"""

    # Custom Clean Formatting for Table 17 (tab:robustness) - 13 rows pivoted
    if label == "tab:robustness":
        return r"""\begin{table}[!htbp]
\centering
\small
\caption{Alternative Geopolitical Risk Percentile Threshold Robustness Checks (80th and 90th Percentiles)}
\label{tab:robustness}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lrrrr}
\toprule
\multirow{2}{*}{\textbf{Model / Benchmark}} & \multicolumn{2}{c}{\textbf{80th Percentile Cutoff (149.51)}} & \multicolumn{2}{c}{\textbf{90th Percentile Cutoff (180.53)}} \\
\cmidrule(lr){2-3} \cmidrule(lr){4-5}
 & \textbf{Normal ($N=295$)} & \textbf{High-Risk ($N=360$)} & \textbf{Normal ($N=476$)} & \textbf{High-Risk ($N=179$)} \\
\midrule
HAR-RV-type & 0.5058 & 0.7803 & 0.4783 & 0.9533 \\
GARCH(1,1) & 0.6611 & 0.9067 & 0.6475 & 1.0606 \\
EGARCH(1,1) & 0.6490 & 0.9170 & 0.6421 & 1.0718 \\
GJR-GARCH(1,1) & 0.6836 & 1.0212 & 0.6733 & 1.2120 \\
ElasticNet & 0.5208 & 0.8207 & 0.4966 & 1.0011 \\
SVR-Linear & 0.5077 & 0.7808 & 0.4794 & 0.9542 \\
SVR-Poly & 0.8228 & 1.6465 & 0.9051 & 1.9544 \\
SVR-RBF & 0.6215 & 1.1063 & 0.6605 & 1.3033 \\
Random Forest & 0.6036 & 0.7964 & 0.5533 & 0.9703 \\
XGBoost & 0.5452 & 0.8412 & 0.5229 & 1.0199 \\
LightGBM & 0.5567 & 0.8855 & 0.5230 & 1.0895 \\
PyTorch LSTM & 0.6109 & 0.8280 & 0.5957 & 0.9692 \\
QSVR (4-Qubit) & 0.5239 & 0.8175 & 0.4897 & 1.0060 \\
\bottomrule
\end{tabular}%
}
\end{table}"""

    # Custom Clean Formatting for Table 13 (tab:regimes) - 13 rows pivoted
    if label == "tab:regimes":
        return r"""\begin{table}[!htbp]
\centering
\small
\caption{Out-of-Sample Forecasting RMSE across Geopolitical Risk Regimes (Pre-Test Thresholds with 95\% Bootstrap CIs)}
\label{tab:regimes}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lccc}
\toprule
\textbf{Model / Benchmark} & \textbf{Low GPR ($N=80$)} & \textbf{Medium GPR ($N=162$)} & \textbf{High GPR ($N=413$)} \\
\midrule
HAR-RV-type & 0.4940 [0.3377, 0.6383] & 0.5034 [0.4218, 0.5927] & 0.7529 [0.6064, 0.8997] \\
GARCH(1,1) & 0.6641 [0.5645, 0.7701] & 0.6290 [0.5468, 0.7239] & 0.8878 [0.7788, 1.0028] \\
EGARCH(1,1) & 0.6394 [0.5499, 0.7238] & 0.6247 [0.5531, 0.6997] & 0.8955 [0.7850, 1.0076] \\
GJR-GARCH(1,1) & 0.7150 [0.5987, 0.8243] & 0.6558 [0.5605, 0.7479] & 0.9884 [0.8654, 1.1118] \\
ElasticNet & 0.4916 [0.3367, 0.6361] & 0.5239 [0.4426, 0.6105] & 0.7905 [0.6324, 0.9504] \\
SVR-Linear & 0.4936 [0.3347, 0.6406] & 0.5049 [0.4202, 0.5915] & 0.7534 [0.6059, 0.9062] \\
SVR-Poly & 0.6880 [0.5707, 0.8099] & 0.8679 [0.7500, 1.0047] & 1.5666 [1.3283, 1.8315] \\
SVR-RBF & 0.5650 [0.4191, 0.7148] & 0.6310 [0.5318, 0.7341] & 1.0601 [0.8778, 1.2585] \\
Random Forest & 0.5123 [0.3722, 0.6500] & 0.6372 [0.5155, 0.7594] & 0.7738 [0.6493, 0.8988] \\
XGBoost & 0.4681 [0.3194, 0.6205] & 0.5744 [0.4584, 0.7038] & 0.8090 [0.6872, 0.9328] \\
LightGBM & 0.4794 [0.3279, 0.6217] & 0.5878 [0.4662, 0.7152] & 0.8509 [0.7176, 0.9930] \\
PyTorch LSTM & 0.5932 [0.4493, 0.7497] & 0.6179 [0.5265, 0.7287] & 0.8010 [0.6534, 0.9515] \\
QSVR (4-Qubit) & 0.4840 [0.3295, 0.6341] & 0.5342 [0.4547, 0.6191] & 0.7872 [0.6506, 0.9368] \\
\bottomrule
\end{tabular}%
}
\end{table}"""

    # Custom Clean Formatting for Table 18 (tab:cost_sens)
    if label == "tab:cost_sens":
        return r"""\begin{table}[!htbp]
\centering
\small
\caption{Transaction Cost Sensitivity Analysis for Volatility-Targeting Strategy (1 to 20 bps)}
\label{tab:cost_sens}
\resizebox{\textwidth}{!}{%
\begin{tabular}{lrrrrrrrrrr}
\toprule
\multirow{2}{*}{\textbf{Cost}} & \multicolumn{2}{c}{\textbf{HAR-RV-type}} & \multicolumn{2}{c}{\textbf{SVR-Linear}} & \multicolumn{2}{c}{\textbf{QSVR}} & \multicolumn{2}{c}{\textbf{ElasticNet}} & \multicolumn{2}{c}{\textbf{SVR-RBF}} \\
\cmidrule(lr){2-3} \cmidrule(lr){4-5} \cmidrule(lr){6-7} \cmidrule(lr){8-9} \cmidrule(lr){10-11}
\textbf{(bps)} & \textbf{Sharpe} & \textbf{Return} & \textbf{Sharpe} & \textbf{Return} & \textbf{Sharpe} & \textbf{Return} & \textbf{Sharpe} & \textbf{Return} & \textbf{Sharpe} & \textbf{Return} \\
\midrule
1 bps & 0.3607 & +19.80\% & 0.3411 & +18.69\% & 0.3196 & +17.02\% & 0.2467 & +12.90\% & 0.3307 & +15.30\% \\
5 bps & 0.2981 & +16.09\% & 0.2796 & +15.08\% & 0.2682 & +14.10\% & 0.1957 & +10.10\% & 0.2718 & +12.41\% \\
10 bps & 0.2198 & +11.61\% & 0.2027 & +10.71\% & 0.2040 & +10.54\% & 0.1318 & +6.70\% & 0.1980 & +8.89\% \\
20 bps & 0.0626 & +3.18\% & 0.0485 & +2.46\% & 0.0753 & +3.76\% & 0.0040 & +0.20\% & 0.0503 & +2.19\% \\
\bottomrule
\end{tabular}%
}
\end{table}"""

    # Custom Clean Formatting for Table 15 (tab:risk_mgmt)
    if label == "tab:risk_mgmt":
        return r"""\begin{table}[!htbp]
\centering
\small
\caption{""" + clean_caption + r"""}
\label{""" + label + r"""}
\resizebox{\textwidth}{!}{%
\begin{tabular}{llrrrrrrrr}
\toprule
\textbf{Model} & \textbf{Distribution} & \textbf{Breaches} & \textbf{Rate (\%)} & \textbf{Kupiec LR} & \textbf{Kupiec $p$} & \textbf{Christ. LR} & \textbf{Indep. $p$} & \textbf{CC $p$} & \textbf{CVaR (\%)} \\
\midrule
""" + body_str + r"""
\bottomrule
\end{tabular}%
}
\end{table}"""

    # For all numerical tables (including tab:ablation and tab:neg_sens):
    col_align = "l" + "r" * (n_cols - 1)
    if n_cols > 5:
        table_tex = wide_open + r"""
\centering
\small
\caption{""" + clean_caption + r"""}
\label{""" + label + r"""}
\resizebox{\textwidth}{!}{%
\begin{tabular}{""" + col_align + r"""}
\toprule
""" + header_str + r"""
\midrule
""" + body_str + r"""
\bottomrule
\end{tabular}%
}
""" + wide_close
    else:
        table_tex = wide_open + r"""
\centering
\small
\caption{""" + clean_caption + r"""}
\label{""" + label + r"""}
\begin{tabular}{""" + col_align + r"""}
\toprule
""" + header_str + r"""
\midrule
""" + body_str + r"""
\bottomrule
\end{tabular}
""" + wide_close
    return table_tex

def main():
    print("=== Generating Full Academic LaTeX Manuscript Source ===")
    
    wb = openpyxl.load_workbook("tables.xlsx")
    
    t1 = load_table_as_latex(wb['VariableDefinitions'], "tab:variables", "Variable Definitions, Descriptions, and Data Sources", is_wide=True)
    t17 = load_table_as_latex(wb['NegativePriceSensitivity'], "tab:neg_sens", "Sensitivity Analysis: Treatment of April 20, 2020 WTI Negative Price Event", is_wide=True)
    t2 = load_table_as_latex(wb['SampleSplits'], "tab:splits", "Chronological Sample Splitting Details (2016–2026, N = 2,473 Trading Days)", is_wide=True)
    t3 = load_table_as_latex(wb['DescriptiveStats'], "tab:descriptive", "Descriptive Statistics for Core Volatility and Exogenous Risk Variables", is_wide=True)
    t4 = load_table_as_latex(wb['Correlations'], "tab:correlation", "Pearson Correlation Matrix across Core Predictor Variables", is_wide=True)
    t5 = load_table_as_latex(wb['H1_Regression'], "tab:h1_reg", "Multivariate Econometric OLS Regression of 5-Day Rolling Volatility Proxy on Lagged Geopolitical Risk (Testing Hypothesis H1)", is_wide=True)
    t6 = load_table_as_latex(wb['EconometricSummary'], "tab:econometric", "Econometric Baseline Parameter Estimates: GARCH(1,1), EGARCH(1,1), GJR-GARCH(1,1), and HAR-RV", is_wide=True)
    t7 = load_table_as_latex(wb['MLConfigs'], "tab:ml_configs", "Classical Machine Learning Benchmark Hyperparameter Configurations", is_wide=True)
    t8 = load_table_as_latex(wb['QuantumConfigs'], "tab:quantum_configs", "Quantum Support Vector Regression (QSVR) Circuit Architecture Specification", is_wide=True)
    t9 = load_table_as_latex(wb['KernelProperties'], "tab:kernel_props", "Quantum vs. Classical Kernel Geometric Properties and Target Alignment", is_wide=True)
    t20 = load_table_as_latex(wb['QuantumRegSensitivity'], "tab:qreg_sens", "Numerical Stability and Tikhonov Ridge Regularization Sensitivity Analysis for QSVR Gram Matrix", is_wide=True)
    t10 = load_table_as_latex(wb['AblationStudy'], "tab:ablation", "Feature Ablation Study: Forecasting RMSE across Nested Predictor Subsets", is_wide=True)
    t11_4f = load_table_as_latex(wb['Controlled4FBenchmark'], "tab:controlled_4f", "Controlled 4-Feature Benchmark: Direct Comparison of Quantum vs. Classical Kernels on Identical Information Set", is_wide=True)
    t11 = load_table_as_latex(wb['ModelPerformance'], "tab:perf", "Out-of-Sample Volatility Forecasting Accuracy Metrics Comparison (655-Day Test Window)", is_wide=True)
    t12 = load_table_as_latex(wb['Key_DM_FDR_Comparisons'], "tab:dm_tests", "Pairwise Diebold-Mariano Predictive Accuracy Tests with HLN Corrections and Benjamini-Hochberg FDR Adjustments", is_wide=True)
    t13 = load_table_as_latex(wb['RegimeAnalysis'], "tab:regimes", "Out-of-Sample Forecasting RMSE across Geopolitical Risk Regimes (Pre-Test Thresholds with 95% Bootstrap CIs)", is_wide=True)
    t14 = load_table_as_latex(wb['RobustnessTests'], "tab:robustness", "Alternative Geopolitical Risk Percentile Threshold Robustness Checks (80th and 90th Percentiles)", is_wide=True)
    t15 = load_table_as_latex(wb['RiskManagement'], "tab:risk_mgmt", "Economic Risk Management: 95% Value-at-Risk (VaR) Coverage Backtesting with Associated Expected Shortfall (CVaR) Estimates (Model-Consistent Distributions)", is_wide=True)
    t16 = load_table_as_latex(wb['PortfolioPerformance'], "tab:portfolio", "Economic Significance: Volatility-Targeting Portfolio Performance (15% Target Vol, 5 bps Cost)", is_wide=True)
    t18 = load_table_as_latex(wb['CostSensitivity'], "tab:cost_sens", "Transaction Cost Sensitivity Analysis for Volatility-Targeting Strategy (1 to 20 bps)", is_wide=True)
    t19 = load_table_as_latex(wb['HypothesisSummary'], "tab:hyp_summary", "Summary of Formal Hypothesis Testing Decisions", is_wide=True)
    
    tex_doc = r"""\documentclass[11pt,a4paper]{article}

\usepackage[utf8]{inputenc}
\usepackage[margin=1in]{geometry}
\usepackage{amsmath,amssymb,amsfonts,bm}
\usepackage{booktabs,tabularx,array,multirow}
\usepackage{graphicx}
\usepackage{float}
\usepackage{setspace}
\usepackage{microtype}
\usepackage{natbib}
\usepackage{xurl}
\usepackage[colorlinks=true,linkcolor=blue,citecolor=blue,urlcolor=blue]{hyperref}
\usepackage{caption}
\usepackage{subcaption}
\usepackage{authblk}
\usepackage{placeins}

% Float tuning to keep floats adjacent to text
\renewcommand{\topfraction}{0.85}
\renewcommand{\bottomfraction}{0.85}
\renewcommand{\textfraction}{0.15}
\renewcommand{\floatpagefraction}{0.70}

\onehalfspacing

\title{\textbf{Quantum Kernel Methods for Crude Oil Volatility Forecasting under Geopolitical Risk: A Controlled Out-of-Sample Benchmark}}

\author[1]{\textbf{Hamood Amur Al Wardi}\thanks{Email: \href{mailto:omaniconsul@gmail.com}{omaniconsul@gmail.com}; ORCID: \href{https://orcid.org/0009-0006-5697-5159}{0009-0006-5697-5159}}}
\author[2]{\textbf{Uvesh Husain}\thanks{Email: \href{mailto:u78.husain@gmail.com}{u78.husain@gmail.com}; ORCID: \href{https://orcid.org/0000-0002-8502-8488}{0000-0002-8502-8488}}}
\author[3,*]{\textbf{Shylaja H N}\thanks{Corresponding author. Email: \href{mailto:shylaja.hn@manipal.edu}{shylaja.hn@manipal.edu}; ORCID: \href{https://orcid.org/0000-0001-9807-8575}{0000-0001-9807-8575}}}
\author[4]{\textbf{Ram Soorat}\thanks{Email: \href{mailto:rsoorat@gmail.com}{rsoorat@gmail.com}; ORCID: \href{https://orcid.org/0000-0001-7875-9197}{0000-0001-7875-9197}}}
\author[5]{\textbf{Priyanka}\thanks{Email: \href{mailto:priyanka292c@gmail.com}{priyanka292c@gmail.com}; ORCID: \href{https://orcid.org/0009-0008-1520-0706}{0009-0008-1520-0706}}}
\author[6]{\textbf{Afzalur Rahman}\thanks{Email: \href{mailto:afzalur.rahman@woxsen.edu.in}{afzalur.rahman@woxsen.edu.in}; ORCID: \href{https://orcid.org/0000-0002-1561-561X}{0000-0002-1561-561X}}}

\affil[1]{\textit{Economics and Business Studies Department, Mazoon College, Muscat, Sultanate of Oman}}
\affil[2]{\textit{Economics and Business Studies Department, Mazoon College, Muscat, Sultanate of Oman}}
\affil[3]{\textit{Manipal Institute of Commerce Finance and Economics, Manipal Academy of Higher Education, Manipal, India}}
\affil[4]{\textit{School of Technology, Woxsen University, Kamkole, Hyderabad 502345, Telangana, India}}
\affil[5]{\textit{Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India}}
\affil[6]{\textit{School of Business, Woxsen University, Kamkole, Hyderabad 502345, Telangana, India}}

\date{\today}

\begin{document}

\maketitle

\begin{abstract}
Forecasting crude oil volatility under geopolitical uncertainty is vital for energy asset pricing, macro-risk surveillance, and financial hedging. This study presents a comprehensive out-of-sample empirical benchmark comparing a 4-qubit Parameterized Quantum Circuit (PQC) kernel regression model (QSVR) against twelve classical benchmark models (yielding thirteen models in total)---including a Heterogeneous Autoregressive rolling-volatility specification (HAR-RV-type model), GARCH(1,1), EGARCH(1,1), and GJR-GARCH(1,1)---as well as classical machine learning regressors (ElasticNet, Linear/Poly/RBF SVR, Random Forest, XGBoost, LightGBM, and PyTorch LSTM).

Using a ten-year daily dataset (2016--2026, $N = 2,473$ clean trading days) incorporating daily newspaper-based Geopolitical Risk (GPRD), AI-based Geopolitical Risk (AI-GPR), and cross-asset macroeconomic controls, models produce one-day-ahead forecasts of a five-day rolling volatility proxy observed at day $t$ (rather than five-day-ahead forecasts of future volatility) and are evaluated across a 655-day out-of-sample window (2024--2026). Our empirical results establish five core findings:
\begin{enumerate}
    \item Multi-component autoregressive models (HAR-RV-type, $\text{RMSE} = 0.6708, R^2 = 0.7800$) and regularized linear shrinkage (SVR-Linear, $\text{RMSE} = 0.6717$; ElasticNet, $\text{RMSE} = 0.7017$) dominate point-forecasting accuracy under symmetric RMSE loss, whereas tree ensembles lead under asymmetric variance-penalizing QLIKE loss (XGBoost, $\text{QLIKE} = 0.1574$).
    \item In a controlled 4-feature experiment where quantum and classical kernel machines operate on identical inputs, the 4-qubit quantum kernel ($\text{RMSE} = 0.7007, R^2 = 0.7600$) outperforms classical Gaussian RBF kernel regression ($\text{RMSE} = 0.7140, R^2 = 0.7508$), providing empirical evidence of a distinct nonlinear representation under the controlled identical-input setting, though linear models still maintain the lowest point error.
    \item While the 4-qubit quantum kernel achieves competitive point accuracy, pairwise Diebold-Mariano tests with Benjamini-Hochberg False Discovery Rate (FDR) adjustments confirm that quantum kernel simulation on classical hardware does not offer statistically significant point-forecast superiority over strong linear benchmarks ($p_{\text{FDR}} = 0.1712$), reframing the contribution as an empirical kernel representation study rather than a computational quantum advantage.
    \item In the full multivariate econometric specification with Newey-West HAC standard errors, lagged daily GPR does not retain statistical significance ($\beta = 0.0008, t = 1.4243, p = 0.1544$; Variance Inflation Factors $< 3.0$) after controlling for volatility persistence ($\beta = 0.8860, t = 22.35, p < 0.0001$) and equity market volatility (VIX, $\beta = 0.0250, t = 3.68, p = 0.0002$), indicating that autoregressive persistence dominates predictive attribution (accounting for over 96\% of permutation importance), suggesting that GPR may be more informative for regime stratification and stress-period analysis than for incremental daily point forecasting.
    \item In formal 95\% Value-at-Risk (VaR) backtesting with model-consistent innovation distributions, parametric Student-$t$ GARCH(1,1) and GJR-GARCH models achieve near-nominal unconditional coverage ($4.73\%$--$4.89\%$ breaches, passing Kupiec POF tests with $p > 0.75$), whereas EGARCH is overly conservative ($2.90\%$ breaches, Kupiec $p = 0.0077$) and QSVR is under-calibrated ($7.79\%$ breaches, Kupiec $p = 0.0024$) despite satisfying the temporal independence null in Christoffersen tests ($p = 0.5904$).
\end{enumerate}

\noindent \textbf{Keywords:} Crude Oil Volatility, Rolling Volatility, Geopolitical Risk, Quantum Machine Learning, Quantum Kernel Regression, HAR-RV-type, Value-at-Risk, Kupiec Test, Christoffersen Test, Forecast Evaluation. \\
\noindent \textbf{JEL Classification:} C22, C53, C58, G17, Q41, Q47.
\end{abstract}

\FloatBarrier
\section{Introduction}
\label{sec:intro}

Crude oil is the cornerstone of global industrial production, transportation networks, and petrochemical supply chains. Consequently, unexpected disruptions and violent price swings in crude oil markets transmit profound shocks throughout the global macroeconomy, influencing sovereign inflation trajectories, monetary policy decisions, and international equity market stability \citep{hamilton2003oil}. As demonstrated in structural macroeconomic analyses, energy price fluctuations reflect a complex combination of global demand shifts, precautionary stockpiling, and supply shocks \citep{kilian2009not, baumeister2016forty}. Predicting crude oil volatility accurately, while incorporating cross-market information from global benchmarks, is therefore a fundamental objective for energy risk managers, derivatives trading desks, and macroeconomic surveillance authorities \citep{alqahtani2020predictability, alqahtani2021oil}.

In energy econometrics, conditional variance modeling has traditionally relied on Generalized Autoregressive Conditional Heteroskedasticity (GARCH) specifications \citep{engle1982autoregressive, bollerslev1986generalized}, their asymmetric counterparts such as EGARCH \citep{nelson1991conditional} and GJR-GARCH \citep{glosten1993relation}, and Heterogeneous Autoregressive specifications (HAR-RV-type models) \citep{corsi2009simple}. While these econometric frameworks effectively capture short-term clustering, long-memory persistence, and leverage asymmetries, they often struggle when processing high-dimensional, multi-source exogenous signals---such as real-time textual geopolitical risk indices and cross-asset macroeconomic controls---without encountering severe parameter proliferation and in-sample overfitting \citep{smales2021volatility, bouoiyour2019what}.

In recent years, the intersection of quantum information science and statistical computation has introduced Quantum Machine Learning (QML) as a potential paradigm for high-dimensional pattern recognition \citep{biamonte2017quantum}. Foundational surveys have highlighted the potential of quantum computing for risk analysis and financial mathematics \citep{herman2023quantum, egger2020quantum, orus2019quantum}. Practical applications have emerged in quantum kernel estimation \citep{havlicek2019supervised, schuld2019quantum}, expressive quantum neural architectures \citep{abbas2021power}, and energy forecasting \citep{liu2020geopolitical, martin2021towards}. In particular, Parameterized Quantum Circuit (PQC) kernel methods map classical input data into exponentially large Hilbert spaces via non-linear unitary operations, computing inner-product kernel matrices through quantum state fidelity overlaps \citep{huang2021power, cerezo2021variational}.

This paper presents an extensive out-of-sample empirical benchmark comparing a 4-qubit PennyLane Quantum Support Vector Regression (QSVR) model against twelve classical econometric and machine learning benchmarks across a 10-year daily historical sample (2016--2026, $N = 2,473$ clean trading days) with an explicit 655-day test window (2024--2026).\footnote{Replication code, PennyLane quantum circuit implementations, and publicly distributable derived empirical datasets are openly accessible at \url{https://github.com/rsoorat/Quantum-Oil-GPR-Benchmark}.}

\FloatBarrier
\section{Literature Review}
\label{sec:lit}

\subsection{Crude Oil Volatility Dynamics and Geopolitical Risk}
Geopolitical tensions and policy uncertainty have emerged as vital determinants of global commodity market dynamics. Following the development of text-based economic policy uncertainty indices \citep{baker2016measuring}, \citet{caldara2022measuring} introduced the daily and monthly Geopolitical Risk (GPR) indices based on automated newspaper article counts. Their empirical findings revealed that geopolitical escalations trigger sharp contractions in macroeconomic investment and substantial surges in commodity market volatility. 

Recent empirical studies demonstrate that geopolitical risk exerts a heterogeneous impact across energy commodity returns and volatility spillovers intensify during international crises \citep{smales2021volatility, demiralay2021geopolitical, bouoiyour2019what}. Furthermore, time-varying sensitivity and energy market uncertainty fluctuate across market regimes \citep{laubsch2024influence}, motivating flexible non-linear and econometric forecasting frameworks \citep{alqahtani2021oil}.

\subsection{Econometric Volatility Modeling and Realized Volatility}
In financial econometrics, conditional heteroskedasticity is conventionally modeled through ARCH and GARCH frameworks \citep{engle1982autoregressive, bollerslev1986generalized}, with asymmetric leverage dynamics captured by EGARCH \citep{nelson1991conditional} and GJR-GARCH \citep{glosten1993relation}. With the availability of continuous intra-day price feeds, realized volatility emerged as a non-parametric, model-free estimator of integrated variance \citep{andersen2003modeling}. 

To bridge multi-scale temporal dynamics, \citet{corsi2009simple} formulated the benchmark Heterogeneous Autoregressive model of Realized Volatility (HAR-RV-type specification). For rigorous forecast comparison, \citet{patton2011volatility} proved that only MSE and QLIKE loss functions provide robust model rankings when evaluated against noisy volatility proxies, while \citet{diebold1995comparing} and \citet{harvey1997testing} established standard predictive accuracy tests.

\subsection{Machine Learning and Regularized Asset Pricing}
The integration of machine learning into financial economics has expanded significantly. Support Vector Regression provides a robust margin-based framework for non-linear time-series modeling \citep{vapnik1995nature}. To overcome high-dimensional collinearity, penalized shrinkage methods such as the Lasso \citep{tibshirani1996regression} and ElasticNet \citep{zou2005regularization} enforce parameter sparsity and stability. Tree-based ensemble methods, including Random Forests \citep{breiman2001random}, XGBoost \citep{chen2016xgboost}, and LightGBM \citep{ke2017lightgbm}, capture complex non-linear interactions. For sequential dependencies, recurrent architectures such as Long Short-Term Memory (LSTM) networks capture temporal memory \citep{hochreiter1997long}. Model interpretability is provided through Shapley additive explanations \citep{lundberg2017unified}, while kernel-target alignment offers geometric diagnostics \citep{cristianini2001kernel}.

\subsection{Quantum Machine Learning in Financial Modeling}
Quantum Machine Learning investigates whether quantum computational mechanics can enhance statistical pattern recognition \citep{biamonte2017quantum}. In the Noisy Intermediate-Scale Quantum era, Parameterized Quantum Circuits serve as hybrid quantum-classical learning architectures \citep{cerezo2021variational}. \citet{havlicek2019supervised} and \citet{schuld2019quantum} established that supervised QML can be naturally represented as kernel estimation in quantum Hilbert spaces. Theoretical investigations have analyzed the expressive capacity and power of data in quantum learning \citep{huang2021power, abbas2021power}. Recent research has explored quantum computing across financial forecasting \citep{egger2020quantum, orus2019quantum}, risk analytics \citep{herman2023quantum}, and energy volatility modeling \citep{liu2020geopolitical, martin2021towards}. Using open-source differentiable quantum frameworks like PennyLane \citep{bergholm2018pennylane}, this study conducts a transparent out-of-sample empirical benchmark of quantum kernel methods.

\FloatBarrier
\section{Theoretical Framework and Hypotheses}
\label{sec:theory}

Building on the econometric and quantum machine learning literature, we formulate four formal, testable hypotheses (H1, H2, and tail-risk components H5a and H5b under the Value-at-Risk evaluation framework H5), one comparative research question (RQ3), and one complementary descriptive quantum-kernel diagnostic (D1):

\begin{itemize}
    \item \textbf{Hypothesis H1 (Geopolitical Risk Incremental Significance):} We test whether lagged daily geopolitical risk indices (GPRD, AI-GPR) exert a statistically significant positive effect ($\beta > 0, p < 0.05$) on the 5-day rolling volatility proxy in a dynamic econometric specification after controlling for autoregressive volatility persistence and cross-asset financial conditions with Newey-West HAC standard errors \citep{newey1987simple}.
    \item \textbf{Hypothesis H2 (Asymmetric Return Innovation Dynamics):} Asymmetric volatility specifications will exhibit statistically significant responses to return innovations ($\gamma \ne 0, p < 0.05$). The direction of asymmetry is parameterized differently across specifications: in GJR-GARCH, leverage implies $\gamma > 0$, whereas in Nelson's (1991) EGARCH, asymmetry implies $\gamma < 0$, with both formulations testing whether negative crude oil return innovations generate greater volatility surges than positive innovations of identical magnitude \citep{glosten1993relation, nelson1991conditional}.
    \item \textbf{Research Question RQ3 (Comparative Forecasting Performance):} How does quantum kernel regression compare with econometric, linear, and nonlinear machine-learning benchmarks in out-of-sample crude oil volatility forecasting under identical information sets? \citep{corsi2009simple, diebold1995comparing}.
    \item \textbf{Quantum Geometry Diagnostic (D1):} As a complementary descriptive diagnostic rather than a formal inferential hypothesis, we report Kernel-Target Alignment $A(K, \mathbf{y})$, Gram matrix effective dimension, numerical rank, and condition number for each kernel to characterize quantum-versus-classical representational geometry in finite samples \citep{cristianini2001kernel, abbas2021power}.
    \item \textbf{Hypothesis H5a (Violation Independence):} VaR violations exhibit no statistically significant temporal dependence, satisfying the Christoffersen independence test null hypothesis ($p > 0.05$) \citep{christoffersen1998evaluating}.
    \item \textbf{Hypothesis H5b (Unconditional Coverage):} The model achieves statistically adequate 95\% VaR unconditional coverage, failing to reject the Kupiec proportion of failures null hypothesis ($p > 0.05$). A model that fails unconditional coverage cannot be considered well-calibrated for risk management, even if the independence null is not rejected \citep{kupiec1995techniques}.
\end{itemize}

\FloatBarrier
\section{Data, Variables, and Descriptive Statistics}
\label{sec:data}

\subsection{Data Collection and Strict Information Horizon}
Our empirical dataset spans a ten-year historical period from August 18, 2016, to August 18, 2026. Following an initial 22-trading-day initialization window required to construct the monthly rolling components for the HAR-RV-type model and lagged predictors, the final clean dataset comprises $N = 2,473$ daily trading observations (September 27, 2016 to August 18, 2026). 

The primary dependent variable is the 5-day rolling volatility proxy (calculated as the rolling sample standard deviation of daily percentage log returns) of West Texas Intermediate (WTI) crude oil spot returns. Daily WTI spot prices were obtained directly from the Federal Reserve Bank of St. Louis Economic Data repository (FRED, Series \texttt{DCOILWTICO}, reflecting the U.S. Energy Information Administration Cushing spot price series). The raw FRED \texttt{DCOILWTICO} series contains an extraordinary negative price observation of $-\$36.98$/barrel on April 20, 2020. This exceptional spot index print coincided with the historic settlement collapse of the prompt May 2020 NYMEX WTI futures contract at $-\$37.63$/barrel, which was driven by severe physical storage exhaustion at the Cushing delivery hub, as documented by the CFTC and EIA.

To capture geopolitical risk, we utilize daily newspaper-based Geopolitical Risk (GPRD) indices and daily Artificial Intelligence Geopolitical Risk (AI-GPR) indices constructed by Matteo Iacoviello \citep{caldara2022measuring, iacoviello2026ai}. We incorporate the aggregate GPRD index, the AI-GPR index, and the oil-specific AI geopolitical risk subindex (\text{GPR\_OIL}). Unlike traditional dictionary-based or keyword-matching text methods that rely on static keyword co-occurrence frequencies \citep{caldara2022measuring}, the AI-GPR framework developed by Iacoviello and Tong \citep{iacoviello2026ai} leverages state-of-the-art Large Language Models (LLMs) and transformer-based Natural Language Processing (NLP) architectures to parse global news archives. By evaluating complete sentence context, syntax, and narrative semantics, the LLM classifier disambiguates routine political discourse from credible military threats, ongoing armed conflict, and bilateral diplomatic crises. Furthermore, the oil-specific AI geopolitical risk subindex (\text{GPR\_OIL}) specifically isolates textual mentions where geopolitical tensions directly intersect with petroleum infrastructure, strategic maritime transit bottlenecks (such as the Strait of Hormuz, the Bab el-Mandeb Strait, and the Suez Canal), pipeline logistics, and OPEC+ production negotiations. To account for broader financial conditions, we obtain six cross-asset control variables: the CBOE Volatility Index (VIX), Gold COMEX futures returns, the US Dollar Index (DXY) returns, Natural Gas futures returns, Brent Crude spot returns, and daily changes in the U.S. 10-Year Treasury Yield. Table \ref{tab:variables} provides complete definitions and sources.

To prevent look-ahead bias, all predictor variables are strictly lagged by one period ($t-1$), ensuring that every forecast $\hat{\sigma}_t$ is generated strictly using information available within the $\mathcal{F}_{t-1}$ information set. All feature-scaling and min-max normalization parameters ($[0, \pi]$) were estimated exclusively using the training data (2016--2022) and then applied unchanged to validation and test observations.

""" + t1 + r"""

\subsection{Treatment of Negative WTI Price Event and Sensitivity Analysis}
Because logarithmic returns $R_t = 100 \ln(P_t / P_{t-1})$ are mathematically undefined for non-positive prices ($P_t \le 0$), we evaluate three transparent computational transformations of this observation for log-return construction: baseline continuous linear interpolation, observation exclusion, and shifted-price transformation. Specifically, for the baseline interpolation, the negative observation on April 20, 2020 ($P_{2020-04-20} = -\$36.98$/bbl in FRED \texttt{DCOILWTICO}) was replaced by the arithmetic mean of the immediately adjacent observations from the identical FRED \texttt{DCOILWTICO} series ($P_{2020-04-17} = \$18.31$/bbl and $P_{2020-04-21} = \$8.91$/bbl), yielding an adjusted computational baseline value of $\$13.61$/bbl ($P_{\text{adj}} = [18.31 + 8.91]/2 = \$13.61$). Crucially, all values used in the negative-price transformation were taken directly from the same downloaded primary series used to construct returns; no adjacent observations from different contract months or unrelated futures series were substituted. We emphasize that this interpolation is strictly a computational transformation used for continuous log-return construction, rather than an attempt to economically reconstruct a real physical transaction price:
\begin{equation}
R_t = 100 \times \ln\left( \frac{P_t^{\text{adj}}}{P_{t-1}^{\text{adj}}} \right)
\end{equation}

To verify whether this synthetic computational adjustment alters model rankings or tail-risk conclusions, Table \ref{tab:neg_sens} presents a formal sensitivity analysis across three distinct treatments: Specification A (Baseline linear interpolation, $P_{2020-04-20} = \$13.61$), Specification B (Observation exclusion), and Specification C (Positive price shift $P_t + \$40.0$). Across all three specifications, the model forecasting error hierarchy remains stable: HAR-RV-type ($\text{RMSE} = 0.6708$--$0.6725$) and SVR-Linear ($\text{RMSE} = 0.6717$--$0.6730$) consistently achieve the lowest errors, followed by QSVR ($\text{RMSE} = 0.7007$--$0.7019$) and ElasticNet ($\text{RMSE} = 0.7017$--$0.7034$), with 95\% VaR breaches for QSVR remaining invariant (51 vs 52 breaches). This confirms that our substantive empirical findings and benchmark rankings remain robust across all three evaluated treatments of the negative price event.

""" + t17 + r"""

\subsection{Chronological Sample Splitting}
To ensure rigorous out-of-sample evaluation, the dataset is partitioned chronologically without shuffling:
\begin{itemize}
    \item \textbf{Training Set:} September 27, 2016 to December 30, 2022 ($N = 1,570$ trading days, 63.5\% of sample).
    \item \textbf{Validation Set:} January 3, 2023 to December 29, 2023 ($N = 248$ trading days, 10.0\% of sample), used for hyperparameter tuning and model selection.
    \item \textbf{Out-of-Sample Test Set:} January 2, 2024 to August 18, 2026 ($N = 655$ trading days, 26.5\% of sample), held strictly separate for out-of-sample evaluation.
\end{itemize}
Table \ref{tab:splits} details the chronological partition design.

""" + t2 + r"""

\subsection{Descriptive Statistics and Econometric Tests}
Table \ref{tab:descriptive} reports the summary descriptive statistics for core variables. Daily WTI crude oil returns exhibit a daily mean of $0.0281\%$, a daily standard deviation of $3.2919\%$, moderate negative skewness ($-0.7513$), and heavy excess kurtosis ($46.2351$). The Jarque-Bera test strongly rejects normality ($\text{JB} = 193,124.91, p < 0.001$). The primary target variable---the 5-day rolling volatility proxy---averages $2.3086\%$ with a maximum of $33.8571\%$. Engle's ARCH-LM test on WTI returns confirms highly significant autoregressive conditional heteroskedasticity ($\text{LM} = 676.19, p < 0.0001$), justifying GARCH modeling \citep{engle1982autoregressive}.

""" + t3 + r"""

Table \ref{tab:correlation} presents the Pearson correlation matrix. The 5-day rolling volatility proxy exhibits a strong positive correlation with the VIX equity volatility index ($r = 0.5544$), a positive correlation with Brent crude volatility, and a modest positive unconditional correlation with the daily GPR index ($r = 0.0711$).

""" + t4 + r"""

Figure \ref{fig:data_overview} illustrates the ten-year empirical dynamics of the crude oil market and geopolitical risk indicators across four panels. Figure \ref{fig:price} shows the historical trajectory of WTI crude oil daily spot prices from 2016 to 2026, highlighting the unprecedented negative settlement price anomaly on April 20, 2020, followed by the commodity super-cycle rally peaking during the 2022 Russia-Ukraine invasion. Figure \ref{fig:returns} depicts the corresponding percentage daily log returns, exhibiting pronounced volatility clustering where tranquil regimes are periodically interrupted by violent return shocks. Figure \ref{fig:volatility} plots the primary target variable---the 5-day rolling volatility proxy---revealing sharp cyclical spikes during macroeconomic crises. Finally, Figure \ref{fig:gpr} displays the daily newspaper-based Geopolitical Risk index (GPRD) alongside the AI-based geopolitical risk index (AI-GPR), capturing major global geopolitical escalations throughout the decade.

Figure \ref{fig:gpr_correlation_overview} presents the bivariate co-movement and cross-asset correlation structure governing the empirical dataset. Figure \ref{fig:gpr_vol_comovement} demonstrates the dynamic co-movement between the 5-day rolling volatility proxy and the daily geopolitical risk index, showing that while major geopolitical escalations frequently coincide with elevated energy volatility, several local geopolitical spikes occur during subdued market conditions without inducing sustained volatility spikes. Figure \ref{fig:corr_heatmap} visualizes the Pearson correlation heatmap across all thirteen predictor variables and controls, documenting strong cross-asset association between crude oil volatility and the CBOE VIX index ($r = 0.5544$), moderate co-movement with natural gas returns, and modest unconditional correlation with daily GPR indicators ($r = 0.0711$), confirming that collinearity among predictors remains controlled.

\begin{figure}[!htbp]
\centering
\begin{subfigure}[b]{0.48\textwidth}
    \includegraphics[width=\textwidth]{figures/figure_01_wti_price.png}
    \caption{WTI Crude Oil Daily Spot Price Dynamics.}
    \label{fig:price}
\end{subfigure}
\hfill
\begin{subfigure}[b]{0.48\textwidth}
    \includegraphics[width=\textwidth]{figures/figure_02_wti_returns.png}
    \caption{WTI Percentage Daily Log Returns.}
    \label{fig:returns}
\end{subfigure}
\vskip\baselineskip
\begin{subfigure}[b]{0.48\textwidth}
    \includegraphics[width=\textwidth]{figures/figure_03_wti_volatility.png}
    \caption{5-Day Rolling Volatility Proxy.}
    \label{fig:volatility}
\end{subfigure}
\hfill
\begin{subfigure}[b]{0.48\textwidth}
    \includegraphics[width=\textwidth]{figures/figure_04_gpr.png}
    \caption{Daily Geopolitical Risk Indices (GPRD and AI-GPR).}
    \label{fig:gpr}
\end{subfigure}
\caption{WTI Crude Oil Market Dynamics and Geopolitical Risk Indicators (2016--2026, $N = 2,473$).}
\label{fig:data_overview}
\end{figure}

\begin{figure}[!htbp]
\centering
\begin{subfigure}[b]{0.48\textwidth}
    \includegraphics[width=\textwidth]{figures/figure_05_gpr_oil_volatility.png}
    \caption{Co-movement: Volatility Proxy vs. Daily GPR.}
    \label{fig:gpr_vol_comovement}
\end{subfigure}
\hfill
\begin{subfigure}[b]{0.48\textwidth}
    \includegraphics[width=\textwidth]{figures/figure_06_correlation.png}
    \caption{Pearson Correlation Heatmap across Predictors.}
    \label{fig:corr_heatmap}
\end{subfigure}
\caption{Geopolitical Risk Co-movement and Correlation Structure.}
\label{fig:gpr_correlation_overview}
\end{figure}

\subsection{Econometric Test of Hypothesis H1 and Multicollinearity Analysis}
To formally test Hypothesis \textbf{H1}, we estimate an econometric OLS regression of the 5-day rolling volatility proxy on lagged geopolitical risk indices with Newey-West HAC standard errors (5 lags) \citep{newey1987simple}:
\begin{equation}
\text{Vol}_{t,5} = \alpha + \beta_1 \text{Vol}_{t-1,5} + \beta_2 \text{GPRD}_{t-1} + \beta_3 \Delta\text{GPRD}_{t-1} + \beta_4 \text{GPR\_AI}_{t-1} + \gamma \text{VIX}_{t-1} + \varepsilon_t
\end{equation}
Table \ref{tab:h1_reg} reports the empirical estimates. In this full dynamic specification, lagged rolling volatility exerts an overwhelming positive effect ($\beta_1 = 0.8860, t = 22.3510, p < 0.0001$), and lagged equity volatility ($\text{VIX}_{t-1}$) is highly significant ($\gamma = 0.0250, t = 3.6758, p = 0.0002$). However, lagged daily GPR ($\text{GPRD}_{t-1}$) yields a coefficient of $\beta_2 = 0.0008$ with a $t$-statistic of $1.4243$ ($p = 0.1544$), while $\text{GPR\_AI}_{t-1}$ yields $\beta_4 = -0.0004$ ($t = -1.0685, p = 0.2853$).

To evaluate whether correlation between GPRD and AI-GPR ($r = 0.7386$) introduces collinearity instability, we calculate Variance Inflation Factors (VIF): $\text{VIF}(\text{GPRD}) = 2.9618$, $\text{VIF}(\text{GPR\_AI}) = 2.5195$, $\text{VIF}(\text{Vol\_Lag1}) = 1.4651$, $\text{VIF}(\Delta\text{GPRD}) = 1.3325$, and $\text{VIF}(\text{VIX}) = 1.4465$. All VIF values remain well below the standard threshold of 5.0, confirming that multicollinearity does not compromise the coefficient estimates. Consequently, Hypothesis \textbf{H1} is rejected in the full dynamic multivariate econometric specification.

""" + t5 + r"""

\FloatBarrier
\section{Econometric, Machine Learning, and Quantum Methodology}
\label{sec:methodology}

Our empirical methodology systematically benchmarks classical econometrics against modern Artificial Intelligence (AI) and Quantum Artificial Intelligence (QAI) paradigms under a strictly controlled out-of-sample framework. Specifically, the model space spans three distinct algorithmic tiers: (i) classical parametric and semi-parametric econometric specifications (GARCH, EGARCH, GJR-GARCH, and the Heterogeneous Autoregressive model of Realized Volatility, HAR-RV-type); (ii) classical Artificial Intelligence and machine learning architectures, including regularized linear shrinkage (ElasticNet), kernel Support Vector Machines (Linear, Polynomial, and Gaussian RBF SVR), tree-based gradient boosting and ensemble learning (Random Forest, XGBoost, and LightGBM), and deep recurrent neural networks (PyTorch Long Short-Term Memory, LSTM); and (iii) Quantum Artificial Intelligence, instantiated via a 4-qubit Parameterized Quantum Circuit (PQC) kernel machine operating in an exponentially expanded Hilbert feature space. By evaluating all AI, ML, and econometric baselines over an identical chronological information horizon, we ensure fair and transparent attribution of predictive performance across linear, nonlinear classical AI, and quantum kernel representations.

\subsection{Econometric Baseline Specifications: GARCH, EGARCH, GJR-GARCH, and HAR-RV-type Model}
To benchmark conditional volatility modeling, we estimate three parametric GARCH-family specifications under standardized Student-$t$ innovation distributions alongside Corsi's (2009) HAR-RV-type framework:
\begin{align}
\text{GARCH(1,1):} \quad \sigma_t^2 &= \omega + \alpha \varepsilon_{t-1}^2 + \beta \sigma_{t-1}^2 \\
\text{EGARCH(1,1):} \quad \ln(\sigma_t^2) &= \omega + \alpha \left( \left| \frac{\varepsilon_{t-1}}{\sigma_{t-1}} \right| - \sqrt{\frac{2}{\pi}} \right) + \gamma \frac{\varepsilon_{t-1}}{\sigma_{t-1}} + \beta \ln(\sigma_{t-1}^2) \\
\text{GJR-GARCH(1,1):} \quad \sigma_t^2 &= \omega + \left( \alpha + \gamma \mathbb{I}_{(\varepsilon_{t-1} < 0)} \right) \varepsilon_{t-1}^2 + \beta \sigma_{t-1}^2 \\
\text{HAR-RV-type:} \quad \text{RV}_t &= \beta_0 + \beta_d \text{RV}_{t-1} + \beta_w \text{RV}_{t-1}^{(w)} + \beta_m \text{RV}_{t-1}^{(m)} + \varepsilon_t
\end{align}
where $\mathbb{I}_{(\cdot)}$ is an indicator function. In GJR-GARCH, the asymmetric leverage parameter is positive and statistically significant ($\gamma = 0.0527, t = 2.2154, p = 0.0267$) \citep{glosten1993relation}. In EGARCH, the asymmetric parameter is negative and statistically significant ($\gamma = -0.0433, t = -2.6560, p = 0.0079$) \citep{nelson1991conditional}, confirming that negative return shocks generate larger surges in conditional log-variance than positive shocks of identical magnitude, supporting Hypothesis \textbf{H2} for both asymmetric specifications.

Table \ref{tab:econometric} summarizes the parameter estimates and diagnostic tests for all econometric models.

""" + t6 + r"""

\subsection{Classical Machine Learning Benchmark Models}
We implement six classical machine learning algorithms:
\begin{itemize}
    \item \textbf{Regularized Linear Regression (ElasticNet):} Minimizes MSE with combined $\ell_1$ (Lasso) and $\ell_2$ (Ridge) penalties \citep{zou2005regularization, tibshirani1996regression}: $\mathcal{L}_{\text{EN}} = \frac{1}{2N} \|\mathbf{y} - X\mathbf{w}\|_2^2 + \alpha \rho \|\mathbf{w}\|_1 + \frac{\alpha(1-\rho)}{2} \|\mathbf{w}\|_2^2$ with validation parameters $\alpha = 0.01, \rho = 0.20$.
    \item \textbf{Support Vector Regression (SVR):} Formulates an $\varepsilon$-insensitive loss tube \citep{vapnik1995nature}: $\mathcal{L}_{\text{SVR}} = \frac{1}{2}\|\mathbf{w}\|^2 + C \sum_{i=1}^N \max(0, |y_i - f(\mathbf{x}_i)| - \varepsilon)$. We benchmark Linear ($K(\mathbf{x}, \mathbf{x}') = \mathbf{x}^\top \mathbf{x}'$), Polynomial ($K(\mathbf{x}, \mathbf{x}') = (\mathbf{x}^\top \mathbf{x}' + 1)^2$), and Gaussian Radial Basis Function (RBF: $K(\mathbf{x}, \mathbf{x}') = \exp(-\gamma \|\mathbf{x} - \mathbf{x}'\|^2)$) kernels with $C = 1.0, \varepsilon = 0.05$.
    \item \textbf{Tree Ensembles (Random Forest, XGBoost, LightGBM):} Random Forest averages 100 decorrelated decision trees \citep{breiman2001random}. XGBoost minimizes second-order Taylor expansion loss with tree shrinkage ($\eta = 0.05$, max depth = 3) \citep{chen2016xgboost}. LightGBM utilizes leaf-wise gradient-based one-side sampling \citep{ke2017lightgbm}.
    \item \textbf{Deep Learning (PyTorch LSTM):} A single-layer recurrent Long Short-Term Memory network with 32 hidden units, a 5-day lookback sequence window, and Adam optimization ($\text{lr} = 0.001$) \citep{hochreiter1997long}.
\end{itemize}
Table \ref{tab:ml_configs} details the hyperparameter configurations.

""" + t7 + r"""

\subsection{Quantum Support Vector Regression (QSVR) Architecture}
The QSVR model utilizes PennyLane's \texttt{default.qubit} statevector simulator on 4 qubits \citep{bergholm2018pennylane}, mapping four normalized features $\mathbf{x} = [x_1, x_2, x_3, x_4]^\top \in [0, \pi]^4$ (comprising $\text{Vol\_Lag1}$, $\text{GPRD\_Lag1}$, $\text{VIX\_Lag1}$, and $\text{Return\_Lag1}$) into 16-dimensional Hilbert space:
\begin{equation}
U(\mathbf{x}) = U_{\text{ent}} \left( \bigotimes_{k=1}^4 R_Y(x_k) \right)
\end{equation}
where $R_Y(\theta) = \exp(-i \theta Y / 2)$ and $U_{\text{ent}} = \text{CNOT}_{(3,0)}\text{CNOT}_{(2,3)}\text{CNOT}_{(1,2)}\text{CNOT}_{(0,1)}$ implements circular entanglement \citep{havlicek2019supervised, schuld2019quantum}. The quantum transition fidelity defines the kernel:
\begin{equation}
K_Q(\mathbf{x}_i, \mathbf{x}_j) = |\langle 0000 | U^\dagger(\mathbf{x}_i) U(\mathbf{x}_j) | 0000 \rangle|^2
\end{equation}
To ensure numerical stability in SVR dual quadratic programming, a Tikhonov ridge regularization $\lambda = 10^{-5}$ is added to the Gram matrix ($K_{\text{reg}} = K_Q + \lambda I$). Figure \ref{fig:quantum_circuit} details the schematic layout of this 4-qubit Parameterized Quantum Circuit, showing the sequential state initialization, parameterized single-qubit Pauli-$Y$ feature rotations, circular CNOT entangling gates, and subsequent fidelity overlap kernel evaluation. Table \ref{tab:quantum_configs} details the quantum circuit specification, and Table \ref{tab:kernel_props} reports the kernel geometric properties.

The empirical quantum Gram matrix achieves an effective numerical rank of 67, exceeding the single-state Hilbert space dimension $d=16$ because the fidelity kernel acts on density operators residing in the $d^2 = 256$-dimensional space of Hermitian operators (see Supplementary Appendix A for formal operator algebra proofs) \citep{abbas2021power, huang2021power}. Crucially, this rank reflects a distinct finite-sample geometric structure rather than inherent predictive superiority: high-dimensional Gaussian RBF achieves an even higher numerical rank (239) yet performs worse out-of-sample, whereas regularized linear models (rank 4) achieve the lowest point forecast error. Table \ref{tab:qreg_sens} demonstrates that out-of-sample performance is invariant to the Tikhonov ridge regularizer across $\lambda \in [10^{-7}, 10^{-4}]$.

\begin{figure}[!htbp]
\centering
\includegraphics[width=\textwidth]{figures/figure_quantum_circuit.png}
\caption{4-Qubit Parameterized Quantum Circuit (PQC) Architecture for Feature Mapping and Quantum Kernel Fidelity Estimation. Four normalized financial features ($x_1=\text{Vol\_Lag1}$, $x_2=\text{GPRD\_Lag1}$, $x_3=\text{VIX\_Lag1}$, $x_4=\text{Return\_Lag1}$) are mapped via Pauli-$Y$ single-qubit rotations $R_Y(x_k)$ onto 4 qubits, followed by a cyclic circular CNOT entanglement network. Quantum state transition fidelity $K_Q(\mathbf{x}_i, \mathbf{x}_j) = |\langle 0000 | U^\dagger(\mathbf{x}_i) U(\mathbf{x}_j) | 0000 \rangle|^2$ is evaluated and regularized ($\tilde{K}_Q = K_Q + \lambda I$) for dual quadratic support vector optimization.}
\label{fig:quantum_circuit}
\end{figure}

""" + t8 + r"""

""" + t9 + r"""

""" + t20 + r"""

\subsection{Mathematical Bridge: Rolling Volatility Forecast to Daily Value-at-Risk}
Our target variable is the 5-day rolling volatility proxy (calculated as the 5-day rolling sample standard deviation of daily percentage log returns):
\begin{equation}
\text{Vol}_{t,5} = \sqrt{ \frac{1}{4} \sum_{k=0}^4 \left( R_{t-k} - \bar{R}_{t,5} \right)^2 }
\end{equation}
Under the assumption of local conditional stationarity over the 5-day window, daily returns follow $R_{t+1} = \mu_{t+1} + \sigma_{t+1} z_{t+1}$ with $z_{t+1} \sim \text{i.i.d.}(0, 1)$. Taking conditional expectations yields $\mathbb{E}[\text{Vol}_{t+1,5}^2 \mid \mathcal{F}_t] \approx \sigma_{t+1}^2$. Thus, the rolling volatility proxy forecast $\hat{\sigma}_t$ estimates the conditional daily standard deviation scale. This mapping should be interpreted as a local-stationarity approximation rather than an exact identity between five-day rolling volatility and one-step conditional variance.

For GARCH models estimated under Student-$t$ error distributions with estimated degrees of freedom $\hat{\nu}$ and conditional mean $\hat{\mu}$, the 95\% 1-day Value-at-Risk is calculated using the exact model-consistent Student-$t$ quantile:
\begin{equation}
\text{VaR}_{0.95, t}^{\text{GARCH}} = \hat{\mu} + \hat{\sigma}_t \left( -t_{\hat{\nu}}^{-1}(0.05) \sqrt{\frac{\hat{\nu}-2}{\hat{\nu}}} \right)
\end{equation}
For regression and machine learning models minimizing mean squared error (MSE loss), point forecasts $\hat{\sigma}_t$ are converted to 95\% VaR using the standard empirical Gaussian critical value $z_{0.95} = 1.64485$:
\begin{equation}
\text{VaR}_{0.95, t}^{\text{ML}} = 1.64485 \times \hat{\sigma}_t
\end{equation}

\FloatBarrier
\section{Empirical Forecasting Results and Ablation Analysis}
\label{sec:results}

\subsection{Feature Ablation Study: Assessing the Incremental Value of GPR}
To resolve whether geopolitical risk variables contribute incremental predictive power over pure volatility persistence, we conduct a systematic feature ablation study across three nested predictor sets:
\begin{itemize}
    \item \textbf{Subset 1 (Volatility Persistence Only / HAR lags):} Pure autoregressive volatility lags ($\text{Vol\_Lag1}, \text{Vol\_Lag2}, \text{HAR\_w}, \text{HAR\_m}$).
    \item \textbf{Subset 2 (Volatility Persistence + Financial Controls):} Volatility lags plus cross-asset controls (VIX, Gold, DXY, Gas, Brent, Treasury Yield).
    \item \textbf{Subset 3 (Full Information Set: Volatility + Controls + GPR):} Full predictor matrix including GPRD, AI-GPR, and GPR\_OIL.
\end{itemize}
Table \ref{tab:ablation} reports the ablation results across ElasticNet, XGBoost, and SVR-RBF. Across all models, Subset 1 achieves the highest point forecasting accuracy (ElasticNet $\text{RMSE} = 0.6695, R^2 = 0.7809$), demonstrating that volatility persistence dominates predictive attribution. Adding macroeconomic controls and GPR variables introduces minor variance, indicating that GPR variables provide descriptive value for stratifying periods of elevated geopolitical stress rather than functioning as an incremental daily point predictor.

""" + t10 + r"""

\subsection{Controlled 4-Feature Benchmark and Full-Model Comparison}
To isolate the mathematical contribution of the quantum kernel from feature-set differences, Table \ref{tab:controlled_4f} reports a controlled 4-feature benchmark where SVR-Linear, ElasticNet, SVR-RBF, and QSVR are trained on the exact same 4 core features ($\text{Vol\_Lag1}$, $\text{GPRD\_Lag1}$, $\text{VIX\_Lag1}$, $\text{Return\_Lag1}$). In this controlled setting:
\begin{itemize}
    \item QSVR achieves lower RMSE ($\text{RMSE} = 0.7007$ vs. $0.7140$) and higher $R^2$ ($0.7600$ vs. $0.7508$) than classical Gaussian SVR-RBF on the identical four-feature information set, although SVR-RBF remains slightly better under asymmetric QLIKE loss ($\text{QLIKE} = 0.1709$ vs. $0.1734$).
    \item SVR-Linear ($\text{RMSE} = 0.6726, R^2 = 0.7788$) and ElasticNet ($\text{RMSE} = 0.6797, R^2 = 0.7741$) achieve the lowest point errors on the 4-feature set, confirming that linear regularization remains superior under symmetric MSE loss.
\end{itemize}

""" + t11_4f + r"""

Table \ref{tab:perf} presents the out-of-sample forecasting performance across all thirteen evaluated models over the 655-day test window (2024--2026) using Root Mean Squared Error (RMSE), Mean Absolute Error (MAE), coefficient of determination ($R^2$), and Patton's Gaussian Quasi-Likelihood loss ($\text{QLIKE} = \frac{\text{RV}_t}{\hat{v}_t} - \ln\frac{\text{RV}_t}{\hat{v}_t} - 1$, where $\text{RV}_t = \sigma_t^2$ and $\hat{v}_t = \hat{\sigma}_t^2$) \citep{patton2011volatility}.

The empirical hierarchy reveals that:
\begin{enumerate}
    \item \textbf{Loss Function-Dependent Model Rankings:} Model rankings depend on the chosen loss metric. Under symmetric RMSE loss, HAR-RV-type ($\text{RMSE} = 0.6708, R^2 = 0.7800$) and SVR-Linear ($\text{RMSE} = 0.6717, R^2 = 0.7794$) lead the benchmark, closely followed by ElasticNet ($\text{RMSE} = 0.7017, R^2 = 0.7593$) and QSVR ($\text{RMSE} = 0.7007, R^2 = 0.7600$). In contrast, under asymmetric variance-penalizing QLIKE loss, tree ensembles perform best (XGBoost $\text{QLIKE} = 0.1574$, Random Forest $\text{QLIKE} = 0.1668$), with QSVR remaining competitive ($\text{QLIKE} = 0.1734$).
    \item \textbf{Transparent Pairwise Diebold-Mariano and FDR Tests:} Table \ref{tab:dm_tests} presents pairwise Diebold-Mariano tests with Harvey-Leybourne-Newbold small-sample corrections \citep{diebold1995comparing, harvey1997testing}, controlling for False Discovery Rates \citep{benjamini1995controlling}. The forecasting difference between QSVR and the HAR-RV-type model yields a Raw $p = 0.1207$ and a BH-Adjusted $p_{\text{FDR}} = 0.1712$, confirming no statistically significant difference in predictive accuracy at the $5\%$ level. Similarly, the difference between QSVR and ElasticNet yields $p_{\text{FDR}} = 0.9604$. However, QSVR significantly outperforms Gaussian RBF SVR ($p_{\text{FDR}} = 0.0001$) and standard GARCH ($p_{\text{FDR}} = 0.0007$) under MSE loss.
\end{enumerate}

""" + t11 + r"""

""" + t12 + r"""

Figure \ref{fig:forecasts} compares the out-of-sample volatility forecast trajectories generated by leading models against the actual 5-day rolling volatility proxy across the 655-day test window (January 2024 to August 2026). All leading models track the primary volatility shifts during the test period; the linear models (HAR-RV-type and SVR-Linear) follow high-frequency volatility movements closely, whereas the 4-qubit QSVR model generates a smooth, highly stable prediction path that captures the underlying conditional variance scale without suffering from destabilizing out-of-sample overreactions.

Figure \ref{fig:model_comp} provides a comprehensive visual ranking of out-of-sample Root Mean Squared Error (RMSE) across all thirteen evaluated specifications on the held-out test sample. The graphical hierarchy in Figure \ref{fig:model_comp} confirms that parsimonious linear models (HAR-RV-type, $\text{RMSE} = 0.6708$; SVR-Linear, $\text{RMSE} = 0.6717$; ElasticNet, $\text{RMSE} = 0.7017$) achieve the highest point-forecasting precision under symmetric quadratic loss. The 4-qubit QSVR model ($\text{RMSE} = 0.7007$) demonstrates strong competitiveness against classical tree ensembles (Random Forest, $\text{RMSE} = 0.7160$; LightGBM, $\text{RMSE} = 0.7554$) and parametric GARCH specifications (GARCH, $\text{RMSE} = 0.8054$), while high-dimensional classical RBF-SVR incurs substantial error ($\text{RMSE} = 0.9202$) due to feature over-parameterization.

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.92\textwidth]{figures/figure_08_actual_vs_predicted.png}
\caption{Out-of-Sample Volatility Forecasts vs. Actual 5-Day Rolling Volatility Proxy (2024--2026 Test Window).}
\label{fig:forecasts}
\end{figure}

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.88\textwidth]{figures/figure_09_model_comparison.png}
\caption{Out-of-Sample Root Mean Squared Error (RMSE) Model Comparison across All Evaluated Specifications.}
\label{fig:model_comp}
\end{figure}

\FloatBarrier
\section{Geopolitical Risk Regime Analysis and Robustness Checks}
\label{sec:regimes}

\subsection{Performance Across Geopolitical Risk Regimes}
To eliminate look-ahead bias in regime classification, geopolitical risk thresholds were estimated exclusively from the pre-test historical sample (September 2016 to December 2023, $N = 1,818$ trading days) and held fixed during the 2024--2026 test period: Low GPR ($\text{GPRD} \le 106.77$, $N = 80$), Medium GPR ($106.77 < \text{GPRD} \le 140.53$, $N = 162$), and High GPR ($\text{GPRD} > 140.53$, $N = 413$). Figure \ref{fig:regimes_dist} visualizes the out-of-sample test set regime distribution, and Table \ref{tab:regimes} presents regime-specific RMSE alongside 95\% bootstrap confidence intervals (1,000 resamples). Complementing the tabular results, Figure \ref{fig:regime_comp} displays the forecasting RMSE across the three geopolitical risk regimes for representative models (HAR-RV-type, GARCH, ElasticNet, SVR-RBF, XGBoost, and QSVR). As shown in Figure \ref{fig:regime_comp}, forecasting error increases substantially across all specifications during the High GPR regime due to headline-driven noise; nevertheless, HAR-RV-type ($\text{RMSE} = 0.7529, [0.6064, 0.8997]$) and SVR-Linear ($\text{RMSE} = 0.7534, [0.6059, 0.9062]$) achieve the lowest point forecasting errors, while QSVR ($\text{RMSE} = 0.7872, [0.6506, 0.9368]$) remains competitive with ElasticNet ($\text{RMSE} = 0.7905, [0.6324, 0.9504]$), outperforming standard GARCH ($\text{RMSE} = 0.8878$) and SVR-RBF ($\text{RMSE} = 1.0601$).

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.75\textwidth]{figures/figure_07_gpr_regimes.png}
\caption{Out-of-Sample Test Set Trading Days across Geopolitical Risk Regimes ($N = 655$: Low = 80, Medium = 162, High = 413).}
\label{fig:regimes_dist}
\end{figure}

""" + t13 + r"""

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.88\textwidth]{figures/figure_10_regime_comparison.png}
\caption{Forecasting RMSE across Geopolitical Risk Regimes for Selected Representative Specifications (HAR-RV-type, GARCH, ElasticNet, SVR-RBF, XGBoost, QSVR).}
\label{fig:regime_comp}
\end{figure}

\subsection{Alternative Percentile Threshold Robustness Checks}
To verify that regime findings are not sensitive to threshold selection, Table \ref{tab:robustness} reports model RMSE under alternative 80th (149.51) and 90th (180.53) percentile high-risk cutoffs estimated on pre-test data. The relative performance hierarchy remains stable, confirming robustness against threshold variations.

""" + t14 + r"""

\FloatBarrier
\section{Model Explainability and Quantum Sensitivity Analysis}
\label{sec:explainability}

To inspect the internal decision logic of the models, we perform permutation feature importance analysis on XGBoost and ElasticNet, alongside state sensitivity analysis on the QSVR quantum circuit \citep{lundberg2017unified}. Figure \ref{fig:shap} illustrates the normalized feature importances. 

Lagged rolling volatility ($\text{Vol\_Lag1}$) accounts for $96.56\%$ of the normalized permutation-importance measure for XGBoost and $49.80\%$ for ElasticNet, confirming that volatility persistence dominates predictive attribution. Among exogenous variables, the oil-specific AI geopolitical risk subindex ($\text{GPR\_OIL\_Lag1}$, $1.50\%$), Brent crude returns ($0.66\%$), and Natural Gas returns ($0.46\%$) provide the highest incremental attributions.

In the QSVR model, wire gradient sensitivity is defined as the mean absolute expectation gradient of the Pauli-Z observable on wire $w$ with respect to input feature $x_{i, w}$ across validation samples: $\text{Sensitivity}(w) = \frac{1}{N_{\text{val}}} \sum_{i=1}^{N_{\text{val}}} \left| \frac{\partial \langle Z_w \rangle(\mathbf{x}_i)}{\partial x_{i, w}} \right|$. Normalized gradient sensitivity indicates that the first wire ($\text{Vol\_Lag1}$) contributes $98.68\%$ of aggregate QSVR wire sensitivity, while the geopolitical wire ($\text{GPRD\_Lag1}$) contributes $0.50\%$.

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.88\textwidth]{figures/figure_11_shap.png}
\caption{Top 10 Normalized Feature Importances from Permutation Analysis (Dominance of Volatility Persistence).}
\label{fig:shap}
\end{figure}

\FloatBarrier
\section{Economic Risk Management and Portfolio Backtesting}
\label{sec:economic}

\subsection{Value-at-Risk (VaR) Backtesting with Associated Expected Shortfall Estimates}
To evaluate Hypotheses \textbf{H5a} and \textbf{H5b}, we assess the economic risk management utility of 1-day ahead 95\% Value-at-Risk and associated Expected Shortfall ($\text{CVaR}_{0.95, t} = \mathbb{E}[-R_t \mid -R_t > \text{VaR}_{0.95, t}]$) across the 655 out-of-sample trading days \citep{engle2004caviar}. A VaR breach occurs when the realized loss exceeds the VaR threshold: $-R_t > \text{VaR}_{0.95, t} \iff R_t < -\text{VaR}_{0.95, t}$. For a well-calibrated 95\% VaR model over $N=655$ days, the expected number of breaches is $655 \times 0.05 = 32.75$ ($5.0\%$).

Table \ref{tab:risk_mgmt} reports formal backtesting statistics across models under their model-specific innovation distribution assumptions:
\begin{enumerate}
    \item \textbf{Unconditional Coverage (Kupiec POF Test - Hypothesis H5b):} The Student-$t$ GARCH specifications provide better calibrated VaR estimates under their model-specific innovation assumptions: parametric GARCH(1,1) under its fitted Student-$t$ distribution ($\hat{\nu} = 5.79$) generates 32 breaches ($4.89\%, LR_{\text{POF}} = 0.0182, p = 0.8927$), and GJR-GARCH(1,1) ($\hat{\nu} = 5.77$) generates 31 breaches ($4.73\%, LR_{\text{POF}} = 0.1001, p = 0.7517$), achieving near-nominal coverage and supporting Hypothesis \textbf{H5b} for GARCH and GJR-GARCH specifications \citep{kupiec1995techniques}. Conversely, EGARCH is overly conservative (19 breaches, $2.90\%, LR_{\text{POF}} = 4.1956, p = 0.0077$). In contrast, machine learning and kernel regressors evaluated under standard Gaussian conditional quantiles (HAR-RV-type: 50 breaches, $7.63\%$; QSVR: 51 breaches, $7.79\%$; ElasticNet: 52 breaches, $7.94\%$) generate higher violation rates, leading to a rejection of Hypothesis \textbf{H5b} for QSVR ($p = 0.0024$). This divergence reflects the combined effect of volatility forecasting and distributional tail modeling, highlighting that point-volatility forecasts alone do not guarantee well-calibrated tail-risk estimates.
    \item \textbf{Conditional Coverage and Independence (Christoffersen Test - Hypothesis H5a):} In Christoffersen independence tests ($LR_{\text{ind}}$) \citep{christoffersen1998evaluating}, the 4-qubit QSVR ($p = 0.5904$), SVR-RBF ($p = 0.3388$), and GARCH ($p = 0.7254$) provide no statistical evidence against the independence null hypothesis in Christoffersen tests. However, in joint conditional coverage testing ($LR_{\text{cc}}$), QSVR yields $p = 0.0086$, indicating that while the data provide no statistical evidence against the independence null hypothesis, the combined hypothesis of correct coverage and independence is rejected due to the higher breach frequency under Gaussian quantiles.
\end{enumerate}

""" + t15 + r"""

\subsection{Volatility-Targeting Dynamic Asset Allocation Strategy}
To assess the economic utility of volatility forecasts, we execute a daily volatility-targeting strategy in WTI crude oil. We use a 15\% annualized volatility target ($\sigma_{\text{target}} = 15\%$) as an illustrative baseline risk-budget assumption. In volatility targeting, scaling the target volatility ($\sigma_{\text{target}} \in \{10\%, 15\%, 20\%\}$) linearly scales daily position sizes subject to the maximum leverage constraint $w_{\text{max}} = 2.0$, leaving cross-model relative rankings and risk-adjusted Sharpe ratios qualitatively invariant. The rolling daily standard deviation forecast $\hat{\sigma}_t$ is converted to annualized percentage units via $\hat{\sigma}_t^{\text{ann}} = \hat{\sigma}_t \times \sqrt{252}$, and portfolio weights are:
\begin{equation}
w_t = \min\left( \frac{\sigma_{\text{target}}}{\hat{\sigma}_t^{\text{ann}}}, w_{\text{max}} \right), \quad R_{\text{port}, t} = w_t R_t - c \cdot |w_t - w_{t-1}|
\end{equation}
with maximum leverage $w_{\text{max}} = 2.0$, and a baseline transaction cost of $c = 5$ basis points ($0.05\%$). We report the Compound Annual Growth Rate $\text{CAGR} = (1 + R_{\text{cum}} / 100)^{252 / N_{\text{test}}} - 1$.

Table \ref{tab:portfolio} and Figure \ref{fig:portfolio} present strategy performance over the 2024--2026 test window. The HAR-RV-type strategy generates the highest cumulative net return ($+16.09\%$, $\text{CAGR} = +5.91\%$, Sharpe ratio $0.298$), followed by SVR-Linear ($+15.08\%$, $\text{CAGR} = +5.55\%$, Sharpe $0.280$), QSVR ($+14.10\%$, $\text{CAGR} = +5.20\%$, Sharpe $0.268$), and SVR-RBF ($+12.41\%$, $\text{CAGR} = +4.60\%$, Sharpe $0.272$). The Na\"ive 20-day historical volatility benchmark ($+9.19\%$, $\text{CAGR} = +3.44\%$, Sharpe $0.222$) confirms that HAR-RV-type, SVR-Linear, and QSVR all outperform the na\"ive forecasting strategy on a risk-adjusted basis.

\noindent \textbf{Important comparability note.} Passive WTI produces the highest absolute cumulative return ($+20.29\%$, $\text{CAGR} = +7.37\%$), but suffers a severe maximum drawdown of $-39.26\%$ and an annualized volatility of $41.23\%$, yielding a Sharpe ratio of $0.172$. In contrast, dynamic volatility-targeting strategies deliberately de-risk during turbulent market regimes, substantially curtailing peak-to-trough losses ($-15.11\%$ to $-20.91\%$ across leading specifications) and cutting annualized volatility by more than half ($18.92\%$--$19.32\%$ across the top three forecasting models, and $13.00\%$--$19.32\%$ across all volatility-targeting strategies). Consequently, while passive buy-and-hold delivers higher raw unhedged returns, leading volatility-targeting models achieve superior risk-adjusted performance (HAR-RV-type Sharpe $0.298$, SVR-Linear $0.280$, QSVR $0.268$). Within the specified volatility-targeting strategy, the economic value of the forecasts is reflected primarily in lower realized portfolio volatility, reduced drawdowns, and improved risk-adjusted performance rather than higher raw returns. This comparison demonstrates that the economic value of accurate volatility forecasting resides in systematic downside risk containment and enhanced risk-adjusted Sharpe ratios rather than unconstrained directional market outperformance.

To ensure robustness against market friction assumptions, Table \ref{tab:cost_sens} presents a transaction cost sensitivity analysis across $c \in \{1, 5, 10, 20\}$ basis points. Economic returns remain positive for all five reported strategies even at the 20-bps transaction-cost assumption, although net returns and Sharpe ratios decline substantially as implementation costs increase.

\begin{figure}[!htbp]
\centering
\includegraphics[width=0.92\textwidth]{figures/figure_12_economic_performance.png}
\caption{Cumulative Portfolio Net Returns for Volatility-Targeting Asset Allocation Strategy (2024--2026 Test Window).}
\label{fig:portfolio}
\end{figure}

""" + t16 + r"""

""" + t18 + r"""

\FloatBarrier
\section{Discussion and Practical Implications}
\label{sec:discuss}

\subsection{Synthesis of Empirical Hypotheses and Research Questions}
Table \ref{tab:hyp_summary} synthesizes the empirical findings and decisions across the four formal testable hypotheses (H1, H2, H5a, H5b), one comparative research question (RQ3), and one descriptive quantum geometry diagnostic (D1) formulated in Section \ref{sec:theory}.

""" + t19 + r"""

\subsection{Managerial and Theoretical Insights}
The empirical findings deliver four practical insights:
\begin{enumerate}
    \item \textbf{Parsimony and Linear Dominance in Daily Volatility:} In low signal-to-noise daily financial time series, regularized linear shrinkage (ElasticNet, SVR-Linear) and heterogeneous autoregression (HAR-RV-type specification) achieve the lowest RMSE errors, reliably outperforming complex deep neural networks and unregularized non-linear regressors \citep{corsi2009simple, zou2005regularization, laubsch2024influence}. Predictive attribution is measured using out-of-sample permutation feature importance on the held-out test set (computed across Random Forest, XGBoost, and linear models under MSE loss with 100 random shuffles per feature), where permuting lagged volatility features accounts for over 96\% of the total performance deterioration, whereas permuting daily geopolitical risk indices accounts for less than 1\% of predictive attribution (see Section 5.3 and Section 6).
    \item \textbf{Quantum-Kernel Representation as a Research-Grade Alternative:} The 4-qubit QSVR represents a non-linear kernel representation methodology rather than a production-ready forecasting system. It demonstrates competitive point accuracy ($\text{RMSE} = 0.7007$) and outperforms classical Gaussian RBF regression under controlled identical inputs. However, it does not achieve statistically significant improvement over linear or HAR-RV-type benchmarks ($p_{\text{FDR}} = 0.1712$), and its VaR breach rate of 7.79\% significantly exceeds the nominal 5\% level --- the model should not be regarded as a well-calibrated tail-risk model without further distributional calibration. Its geometric profile (KTA=0.3178, effective dimension=1.6868) is intermediate between linear/polynomial and RBF kernels, indicating the circuit occupies a distinct but not dominant representational niche on this dataset. Future work on larger qubit architectures, error-mitigated hardware deployment, and asymmetric loss optimization may extend practical relevance \citep{schuld2019quantum, abbas2021power, jerbi2023quantum, dinut2026comparative}.
    \item \textbf{Role of Geopolitical Indices:} Geopolitical risk measures provide limited incremental predictive power on daily horizons ($p = 0.1544$ in multivariate HAC regressions; VIF $< 3.0$). Their primary value resides in providing descriptive value for stratifying periods of elevated geopolitical stress and tail-risk analysis rather than serving as primary drivers of daily point volatility \citep{caldara2022measuring, iacoviello2026ai, jin2023geopolitical, abdelmalek2026quantile}.
    \item \textbf{Practitioner Model Selection:} The appropriate model depends on the use case. Table~\ref{tab:decision_fw} summarizes the evidence-based decision framework.
\end{enumerate}

\begin{table}[!htbp]
\centering
\small
\caption{Evidence-Based Practitioner Decision Framework: Model Selection by Objective}
\label{tab:decision_fw}
\begin{tabular}{p{3.8cm}p{3cm}p{5.2cm}}
\toprule
\textbf{Decision Objective} & \textbf{Preferred Model} & \textbf{Evidence Basis} \\
\midrule
Point volatility forecast (RMSE) & HAR-RV-type & Lowest RMSE=0.6708; DM $p>0.84$ vs SVR-Linear \\
Linear ML forecast & SVR-Linear & RMSE=0.6717; near-identical to the HAR-RV-type model \\
Asymmetric QLIKE forecast & XGBoost & Lowest QLIKE=0.1574 \\
Tail-risk calibration (VaR) & GARCH / GJR-GARCH & 4.89\% / 4.73\% breach rates; Kupiec $p>0.75$ \\
Nonlinear kernel research & QSVR & Outperforms RBF-SVR in controlled 4-feature setting \\
Portfolio volatility targeting & HAR-RV-type & Highest net return (+16.09\%) and Sharpe ratio (0.298) among volatility-targeting strategies; SVR-Linear (+15.08\%, Sharpe 0.280) provides a strong alternative \\
Regime \& stress analysis & GPR indicators & Best for regime stratification (63\% high-GPR test window) \\
\bottomrule
\end{tabular}
\end{table}

\section{Limitations and Future Research}
\label{sec:limits}
Several limitations should be noted:
\begin{itemize}
    \item \textbf{Classical Simulation Hardware:} The quantum kernel was evaluated using statevector simulation on classical CPUs. Future work should deploy variational quantum algorithms on physical Noisy Intermediate-Scale Quantum hardware \citep{cerezo2021variational}.
    \item \textbf{Feature Dimensionality Limits:} The 4-qubit circuit required selecting four primary features ex ante. Scalable multi-qubit architectures with barren-plateau mitigation should be investigated \citep{abbas2021power, huang2021power}.
    \item \textbf{Alternative Loss Functions:} Future quantum regression research could formulate quantile-loss quantum circuits or asymmetric QLIKE-optimized quantum Hamiltonians to improve direct tail-risk estimation \citep{engle2004caviar, patton2011volatility}.
\end{itemize}

\section{Conclusion}
\label{sec:conclusion}
This study presented a rigorous out-of-sample empirical benchmark of quantum kernel regression against twelve classical econometric and machine learning specifications for crude oil volatility forecasting under geopolitical risk. Our empirical findings demonstrate that parsimonious linear models (HAR-RV-type and SVR-Linear) achieve the highest point forecasting accuracy under symmetric RMSE loss, while tree ensembles lead under asymmetric QLIKE loss. 

The controlled four-feature experiment shows that the 4-qubit quantum kernel achieves lower RMSE than the matched Gaussian RBF specification, providing empirical evidence of a distinct nonlinear representation under the controlled identical-input setting. However, QSVR does not achieve statistically significant superiority over the strongest linear benchmarks ($p_{\text{FDR}} = 0.1712$) and its 95\% VaR forecasts are under-calibrated despite no evidence of temporal clustering in violations. Finally, dynamic econometric testing reveals that geopolitical risk indices serve primarily as regime-stratification variables rather than incremental point predictors. The publicly distributable derived datasets, replication code, quantum circuits, and statistical pipelines are openly available to support full replication of the reported empirical analysis.

\FloatBarrier
\section*{Declaration of Funding}
No funding was received for this work.

\section*{Data Availability Statement}
The publicly distributable derived datasets, replication code, model specifications, and quantum circuits are openly available in the project repository at \url{https://github.com/rsoorat/Quantum-Oil-GPR-Benchmark}. Any underlying raw market data subject to third-party licensing restrictions are available from their original providers or from the corresponding author, Shylaja H N, where permitted upon reasonable request at \href{mailto:shylaja.hn@manipal.edu}{shylaja.hn@manipal.edu}.

\section*{Declaration of Generative AI and AI-Assisted Technologies in the Writing Process}
During the preparation of this work, the authors used Anthropic Claude and Google DeepMind AI tools in order to assist with code optimization, data processing, and manuscript editing for clarity and formatting. After using these tools, the authors reviewed and edited the content as needed and take full responsibility for the content of the published article.

\section*{Conflict of Interest Statement}
The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

\bibliographystyle{elsarticle-harv}
\bibliography{references}

\end{document}
"""
    with open("Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript.tex", "w", encoding="utf-8") as f:
        f.write(tex_doc)
    print("Complete LaTeX manuscript generated: Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript.tex")

if __name__ == "__main__":
    main()
