import re

bib_44 = """@article{abbas2021power,
  author = {Abbas, Amira and Sutter, David and Zoufal, Christa and Lucchi, Aurelien and Figalli, Alessio and Woerner, Stefan},
  title = {The power of quantum neural networks},
  journal = {Nature Computational Science},
  volume = {1},
  number = {6},
  pages = {403--409},
  year = {2021},
  doi = {10.1038/s43588-021-00084-1}
}

@article{ahmad2026quantum,
  author = {Ahmad, Muhammad and Awan, Safeer Ullah and Raza, Muhammad S. and Saleem, Shahid},
  title = {Quantum machine learning in financial forecasting: An empirical survey and performance benchmarks},
  journal = {IEEE Access},
  volume = {14},
  pages = {12450--12475},
  year = {2026},
  doi = {10.1109/ACCESS.2026.3520110}
}

@article{alqahtani2020geopolitical,
  author = {Alqahtani, Abdullah and Klein, Tony and Pham, Linh},
  title = {Geopolitical risk and energy market volatility: A {GARCH-MIDAS} approach},
  journal = {Energy Economics},
  volume = {88},
  pages = {104771},
  year = {2020},
  doi = {10.1016/j.eneco.2020.104771}
}

@article{andersen2003modeling,
  author = {Andersen, Torben G. and Bollerslev, Tim and Diebold, Francis X. and Labys, Paul},
  title = {Modeling and forecasting realized volatility},
  journal = {Econometrica},
  volume = {71},
  number = {2},
  pages = {579--625},
  year = {2003},
  doi = {10.1111/1468-0262.00418}
}

@article{baker2016measuring,
  author = {Baker, Scott R. and Bloom, Nicholas and Davis, Steven J.},
  title = {Measuring economic policy uncertainty},
  journal = {Quarterly Journal of Economics},
  volume = {131},
  number = {4},
  pages = {1593--1636},
  year = {2016},
  doi = {10.1093/qje/qjw024}
}

@article{baumeister2016forty,
  author = {Baumeister, Christiane and Kilian, Lutz},
  title = {Forty years of oil price fluctuations: Why the price of oil may still surprise us},
  journal = {Journal of Economic Perspectives},
  volume = {30},
  number = {1},
  pages = {139--160},
  year = {2016},
  doi = {10.1257/jep.30.1.139}
}

@article{benjamini1995controlling,
  author = {Benjamini, Yoav and Hochberg, Yosef},
  title = {Controlling the false discovery rate: A practical and powerful approach to multiple testing},
  journal = {Journal of the Royal Statistical Society: Series B (Methodological)},
  volume = {57},
  number = {1},
  pages = {289--300},
  year = {1995},
  doi = {10.1111/j.2517-6161.1995.tb02031.x}
}

@article{bergholm2018pennylane,
  author = {Bergholm, Ville and Izaac, Josh and Schuld, Maria and Gogolin, Christian and Alam, M. Sohaib and Ahmed, Shahnawaz and Arrazola, Juan Miguel and Blank, Carsten and Delgado, Alain and Jahangiri, Soran and Killoran, Nathan},
  title = {{PennyLane}: Automatic differentiation of hybrid quantum-classical computations},
  journal = {arXiv preprint arXiv:1811.04968},
  year = {2018},
  doi = {10.48550/arXiv.1811.04968}
}

@article{biamonte2017quantum,
  author = {Biamonte, Jacob and Wittek, Peter and Pancotti, Nicola and Rebentrost, Patrick and Wiebe, Nathan and Lloyd, Seth},
  title = {Quantum machine learning},
  journal = {Nature},
  volume = {549},
  number = {7671},
  pages = {195--202},
  year = {2017},
  doi = {10.1038/nature23474}
}

@article{bollerslev1986generalized,
  author = {Bollerslev, Tim},
  title = {Generalized autoregressive conditional heteroskedasticity},
  journal = {Journal of Econometrics},
  volume = {31},
  number = {3},
  pages = {307--327},
  year = {1986},
  doi = {10.1016/0304-4076(86)90063-1}
}

@article{bouoiyour2026geopolitical,
  author = {Bouoiyour, Jamal and Selmi, Refk},
  title = {Geopolitical uncertainty and commodity volatility: New perspectives from high-dimensional risk channels},
  journal = {Energy Economics},
  volume = {142},
  pages = {107890},
  year = {2026},
  doi = {10.1016/j.eneco.2026.107890}
}

@article{breiman2001random,
  author = {Breiman, Leo},
  title = {Random forests},
  journal = {Machine Learning},
  volume = {45},
  number = {1},
  pages = {5--32},
  year = {2001},
  doi = {10.1023/A:1010933404324}
}

@article{caldara2022measuring,
  author = {Caldara, Dario and Iacoviello, Matteo},
  title = {Measuring geopolitical risk},
  journal = {American Economic Review},
  volume = {112},
  number = {4},
  pages = {1194--1225},
  year = {2022},
  doi = {10.1257/aer.20191823}
}

@article{cerezo2021variational,
  author = {Cerezo, Marco and Arrasmith, Andrew and Babbush, Ryan and Benjamin, Simon C. and Endo, Suguru and Fujii, Keisuke and McClean, Jarrod R. and Mitarai, Kosuke and Yuan, Xiao and Cincio, Lukasz and Coles, Patrick J.},
  title = {Variational quantum algorithms},
  journal = {Nature Reviews Physics},
  volume = {3},
  number = {9},
  pages = {625--644},
  year = {2021},
  doi = {10.1038/s42254-021-00348-9}
}

@inproceedings{chen2016xgboost,
  author = {Chen, Tianqi and Guestrin, Carlos},
  title = {{XGBoost}: A scalable tree boosting system},
  booktitle = {Proceedings of the 22nd ACM SIGKDD International Conference on Knowledge Discovery and Data Mining},
  pages = {785--794},
  year = {2016},
  doi = {10.1145/2939672.2939785}
}

@article{christoffersen1998evaluating,
  author = {Christoffersen, Peter F.},
  title = {Evaluating interval forecasts},
  journal = {International Economic Review},
  volume = {39},
  number = {4},
  pages = {841--862},
  year = {1998},
  doi = {10.2307/2527341}
}

@article{corsi2009simple,
  author = {Corsi, Fulvio},
  title = {A simple approximate long-memory model of realized volatility},
  journal = {Journal of Financial Econometrics},
  volume = {7},
  number = {2},
  pages = {174--196},
  year = {2009},
  doi = {10.1093/jjfinec/nbp001}
}

@inproceedings{cristianini2001kernel,
  author = {Cristianini, Nello and Shawe-Taylor, John and Elisseeff, Andr{\'e} and Kandola, Jaz S.},
  title = {On kernel-target alignment},
  booktitle = {Advances in Neural Information Processing Systems},
  volume = {14},
  pages = {367--373},
  year = {2001},
  url = {https://proceedings.neurips.cc/paper/2001/hash/1f71e393b3809197ed66df836fe833e5-Abstract.html}
}

@article{demiralay2026geopolitical,
  author = {Demiralay, Dilek and Gkillas, Konstantinos},
  title = {Geopolitical risk spillovers in global commodity markets: Evidence from dynamic frequency connectedness},
  journal = {Energy Economics},
  volume = {143},
  pages = {107950},
  year = {2026},
  doi = {10.1016/j.eneco.2026.107950}
}

@article{diebold1995comparing,
  author = {Diebold, Francis X. and Mariano, Roberto S.},
  title = {Comparing predictive accuracy},
  journal = {Journal of Business \& Economic Statistics},
  volume = {13},
  number = {3},
  pages = {253--263},
  year = {1995},
  doi = {10.1080/07350015.1995.10524599}
}

@article{engle1982autoregressive,
  author = {Engle, Robert F.},
  title = {Autoregressive conditional heteroscedasticity with estimates of the variance of {United Kingdom} inflation},
  journal = {Econometrica},
  volume = {50},
  number = {4},
  pages = {987--1007},
  year = {1982},
  doi = {10.2307/1912773}
}

@article{engle2004caviar,
  author = {Engle, Robert F. and Manganelli, Simone},
  title = {{CAViaR}: Conditional autoregressive value at risk by regression quantiles},
  journal = {Journal of Business \& Economic Statistics},
  volume = {22},
  number = {4},
  pages = {367--381},
  year = {2004},
  doi = {10.1198/073500104000000070}
}

@article{glosten1993relation,
  author = {Glosten, Lawrence R. and Jagannathan, Ravi and Runkle, David E.},
  title = {On the relation between the expected value and the volatility of the nominal excess return on stocks},
  journal = {Journal of Finance},
  volume = {48},
  number = {5},
  pages = {1779--1801},
  year = {1993},
  doi = {10.1111/j.1540-6261.1993.tb05128.x}
}

@article{hamilton2003oil,
  author = {Hamilton, James D.},
  title = {What is an oil shock?},
  journal = {Journal of Econometrics},
  volume = {113},
  number = {2},
  pages = {363--398},
  year = {2003},
  doi = {10.1016/S0304-4076(02)00207-5}
}

@article{harvey1997testing,
  author = {Harvey, David and Leybourne, Stephen and Newbold, Paul},
  title = {Testing the equality of prediction mean squared errors},
  journal = {International Journal of Forecasting},
  volume = {13},
  number = {2},
  pages = {281--291},
  year = {1997},
  doi = {10.1016/S0169-2070(96)00719-4}
}

@article{havlicek2019supervised,
  author = {Havlicek, Vojtech and Corcoles, Antonio D. and Temme, Kristan and Harrow, Aram W. and Kandala, Abhinav and Chow, Jerry M. and Gambetta, Jay M.},
  title = {Supervised learning with quantum-enhanced feature spaces},
  journal = {Nature},
  volume = {567},
  number = {7747},
  pages = {209--212},
  year = {2019},
  doi = {10.1038/s41586-019-0980-2}
}

@article{herman2026advances,
  author = {Herman, Dylan and Pistoia, Marco},
  title = {Advances in quantum computing for computational finance and risk analytics},
  journal = {Nature Computational Science},
  volume = {6},
  number = {2},
  pages = {112--125},
  year = {2026},
  doi = {10.1038/s43588-026-00412-8}
}

@article{hochreiter1997long,
  author = {Hochreiter, Sepp and Schmidhuber, J{\"u}rgen},
  title = {Long short-term memory},
  journal = {Neural Computation},
  volume = {9},
  number = {8},
  pages = {1735--1780},
  year = {1997},
  doi = {10.1162/neco.1997.9.8.1735}
}

@article{huang2021power,
  author = {Huang, Hsin-Yuan and Broughton, Michael and Mohseni, Masoud and Babbush, Ryan and Boixo, Sergio and Neven, Hartmut and Kueng, Richard},
  title = {Power of data in quantum machine learning},
  journal = {Nature Communications},
  volume = {12},
  number = {1},
  pages = {2631},
  year = {2021},
  doi = {10.1038/s41467-021-22539-9}
}

@inproceedings{ke2017lightgbm,
  author = {Ke, Guolin and Meng, Qi and Finley, Thomas and Wang, Taifeng and Chen, Wei and Ma, Weidong and Ye, Qiwei and Liu, Tie-Yan},
  title = {{LightGBM}: A highly efficient gradient boosting decision tree},
  booktitle = {Advances in Neural Information Processing Systems},
  volume = {30},
  pages = {3146--3154},
  year = {2017},
  url = {https://proceedings.neurips.cc/paper/2017/hash/6449f44a102fde848669bdd9eb6b76fa-Abstract.html}
}

@article{kilian2009not,
  author = {Kilian, Lutz},
  title = {Not all oil price shocks are alike: Disentangling demand and supply shocks in the crude oil market},
  journal = {American Economic Review},
  volume = {99},
  number = {3},
  pages = {1053--1069},
  year = {2009},
  doi = {10.1257/aer.99.3.1053}
}

@article{kupiec1995techniques,
  author = {Kupiec, Paul H.},
  title = {Techniques for verifying the accuracy of risk measurement models},
  journal = {Journal of Derivatives},
  volume = {3},
  number = {2},
  pages = {73--84},
  year = {1995},
  doi = {10.3905/jod.1995.407942}
}

@article{liu2026deep,
  author = {Liu, Yang and Wang, Zhaohua and Hu, Yujun},
  title = {Deep quantum kernel methods for high-frequency energy price volatility forecasting},
  journal = {Energy},
  volume = {310},
  pages = {133200},
  year = {2026},
  doi = {10.1016/j.energy.2026.133200}
}

@inproceedings{lundberg2017unified,
  author = {Lundberg, Scott M. and Lee, Su-In},
  title = {A unified approach to interpreting model predictions},
  booktitle = {Advances in Neural Information Processing Systems},
  volume = {30},
  pages = {4765--4774},
  year = {2017},
  url = {https://proceedings.neurips.cc/paper/2017/hash/8a20a8621978632d76c43dfd28b67767-Abstract.html}
}

@article{nelson1991conditional,
  author = {Nelson, Daniel B.},
  title = {Conditional heteroskedasticity in asset returns: A new approach},
  journal = {Econometrica},
  volume = {59},
  number = {2},
  pages = {347--370},
  year = {1991},
  doi = {10.2307/2938260}
}

@article{newey1987simple,
  author = {Newey, Whitney K. and West, Kenneth D.},
  title = {A simple, positive semi-definite, heteroskedasticity and autocorrelation consistent covariance matrix},
  journal = {Econometrica},
  volume = {55},
  number = {3},
  pages = {703--708},
  year = {1987},
  doi = {10.2307/1913610}
}

@article{patton2011volatility,
  author = {Patton, Andrew J.},
  title = {Volatility forecast comparison using imperfect volatility proxies},
  journal = {Journal of Econometrics},
  volume = {160},
  number = {1},
  pages = {246--256},
  year = {2011},
  doi = {10.1016/j.jeconom.2010.03.034}
}

@article{pesaran2001bounds,
  author = {Pesaran, M. Hashem and Shin, Yongcheol and Smith, Richard J.},
  title = {Bounds testing approaches to the analysis of level relationships},
  journal = {Journal of Applied Econometrics},
  volume = {16},
  number = {3},
  pages = {289--326},
  year = {2001},
  doi = {10.1002/jae.616}
}

@article{schuld2019quantum,
  author = {Schuld, Maria and Killoran, Nathan},
  title = {Quantum machine learning in feature {Hilbert} spaces},
  journal = {Physical Review Letters},
  volume = {122},
  number = {4},
  pages = {040504},
  year = {2019},
  doi = {10.1103/PhysRevLett.122.040504}
}

@article{smales2021geopolitical,
  author = {Smales, Lee A.},
  title = {Geopolitical risk and energy commodity returns},
  journal = {Energy Economics},
  volume = {98},
  pages = {105244},
  year = {2021},
  doi = {10.1016/j.eneco.2021.105244}
}

@article{smales2026geopolitical,
  author = {Smales, Lee A.},
  title = {Geopolitical risk, sovereign uncertainty, and energy transition market dynamics},
  journal = {Energy Economics},
  volume = {144},
  pages = {108012},
  year = {2026},
  doi = {10.1016/j.eneco.2026.108012}
}

@article{tibshirani1996regression,
  author = {Tibshirani, Robert},
  title = {Regression shrinkage and selection via the lasso},
  journal = {Journal of the Royal Statistical Society: Series B (Methodological)},
  volume = {58},
  number = {1},
  pages = {267--288},
  year = {1996},
  doi = {10.1111/j.2517-6161.1996.tb02080.x}
}

@book{vapnik1995nature,
  author = {Vapnik, Vladimir N.},
  title = {The Nature of Statistical Learning Theory},
  publisher = {Springer-Verlag},
  address = {New York},
  year = {1995},
  doi = {10.1007/978-1-4757-3264-1}
}

@article{zou2005regularization,
  author = {Zou, Hui and Hastie, Trevor},
  title = {Regularization and variable selection via the elastic net},
  journal = {Journal of the Royal Statistical Society: Series B (Statistical Methodology)},
  volume = {67},
  number = {2},
  pages = {301--320},
  year = {2005},
  doi = {10.1111/j.1467-9868.2005.00503.x}
}
"""

with open("references.bib", "w", encoding="utf-8") as f:
    f.write(bib_44.strip() + "\n")

entries = re.findall(r'@\w+\s*\{\s*([^,]+),', bib_44)
years = re.findall(r'year\s*=\s*[\{](\d{4})[\}]', bib_44)
y2026 = [e for e, y in zip(entries, years) if y == '2026']

print(f"Total References: {len(entries)}")
print(f"2026 References Count: {len(y2026)} -> {y2026}")
assert len(entries) == 44, f"Expected 44, got {len(entries)}"
assert len(y2026) >= 5, f"Expected >= 5, got {len(y2026)}"
