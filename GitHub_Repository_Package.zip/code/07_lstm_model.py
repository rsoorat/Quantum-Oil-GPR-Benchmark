import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
import numpy as np
from sklearn.preprocessing import StandardScaler

class LSTMRegressor(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_layers, output_dim, dropout=0.2):
        super(LSTMRegressor, self).__init__()
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.lstm = nn.LSTM(input_dim, hidden_dim, num_layers, batch_first=True, dropout=dropout if num_layers > 1 else 0.0)
        self.fc = nn.Linear(hidden_dim, output_dim)
        
    def forward(self, x):
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim).to(x.device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_dim).to(x.device)
        out, _ = self.lstm(x, (h0, c0))
        out = self.fc(out[:, -1, :])
        return out.squeeze()

def create_sequences(X, y, seq_length):
    xs = []
    ys = []
    for i in range(len(X) - seq_length + 1):
        x = X[i:(i + seq_length)]
        xs.append(x)
        ys.append(y[i + seq_length - 1])
    return np.array(xs), np.array(ys)

def train_lstm(X_train, y_train, X_val, y_val, seq_length=5, epochs=30, batch_size=32, lr=0.005):
    # Scale data
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_val_scaled = scaler.transform(X_val)
    
    # Create sequences
    X_tr_seq, y_tr_seq = create_sequences(X_train_scaled, y_train, seq_length)
    X_val_seq, y_val_seq = create_sequences(X_val_scaled, y_val, seq_length)
    
    # Convert to PyTorch tensors
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    X_tr_tensor = torch.tensor(X_tr_seq, dtype=torch.float32).to(device)
    y_tr_tensor = torch.tensor(y_tr_seq, dtype=torch.float32).to(device)
    X_val_tensor = torch.tensor(X_val_seq, dtype=torch.float32).to(device)
    y_val_tensor = torch.tensor(y_val_seq, dtype=torch.float32).to(device)
    
    train_dataset = TensorDataset(X_tr_tensor, y_tr_tensor)
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=False)
    
    # Initialize model
    input_dim = X_train.shape[1]
    model = LSTMRegressor(input_dim=input_dim, hidden_dim=32, num_layers=1, output_dim=1, dropout=0.2).to(device)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)
    
    best_val_loss = float('inf')
    best_state_dict = None
    
    # Training Loop
    for epoch in range(epochs):
        model.train()
        for batch_x, batch_y in train_loader:
            optimizer.zero_grad()
            outputs = model(batch_x)
            loss = criterion(outputs, batch_y)
            loss.backward()
            optimizer.step()
            
        # Validation
        model.eval()
        with torch.no_grad():
            val_outputs = model(X_val_tensor)
            val_loss = criterion(val_outputs, y_val_tensor).item()
            
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_state_dict = model.state_dict()
            
    # Load best model
    if best_state_dict is not None:
        model.load_state_dict(best_state_dict)
        
    return model, scaler, seq_length

def predict_lstm(model, scaler, X_test, seq_length):
    model.eval()
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    X_scaled = scaler.transform(X_test)
    
    # We need padding or sequences to forecast. For a test sample, we construct
    # sequences using historical context. For prediction, we return predictions
    # aligned with the test target dates.
    X_seq, _ = create_sequences(X_scaled, np.zeros(len(X_scaled)), seq_length)
    X_tensor = torch.tensor(X_seq, dtype=torch.float32).to(device)
    
    with torch.no_grad():
        preds = model(X_tensor)
        
    return preds.cpu().numpy()

def main():
    print("LSTM model code successfully defined.")

if __name__ == "__main__":
    main()
