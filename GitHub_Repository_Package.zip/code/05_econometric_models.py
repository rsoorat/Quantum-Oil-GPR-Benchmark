import pandas as pd
import numpy as np
import yaml
from arch import arch_model
import statsmodels.api as sm
import openpyxl

def main():
    print("=== Step 5: Econometric Volatility Modeling (GARCH, EGARCH, GJR-GARCH, HAR-RV) ===")
    
    # Load configuration
    with open("config.yaml", "r") as f:
        config = yaml.safe_load(f)
        
    dataset_path = config['data']['oil_model_dataset_path']
    df = pd.read_csv(dataset_path)
    df['date'] = pd.to_datetime(df['date'])
    
    # Use returns for GARCH
    returns = df['WTI_Return'].values
    
    # 1. Fit GARCH(1,1) with Student-t distribution
    print("\n1. Estimating GARCH(1,1)...")
    mod_garch = arch_model(returns, p=1, q=1, vol='Garch', dist='studentst', rescale=False)
    res_garch = mod_garch.fit(disp='off')
    print(res_garch.summary())
    
    # 2. Fit EGARCH(1,1) with Student-t distribution and asymmetric parameter o=1
    print("\n2. Estimating EGARCH(1,1)...")
    mod_egarch = arch_model(returns, p=1, o=1, q=1, vol='EGarch', dist='studentst', rescale=False)
    res_egarch = mod_egarch.fit(disp='off')
    print(res_egarch.summary())
    
    # 3. Fit GJR-GARCH(1,1) with Student-t distribution
    print("\n3. Estimating GJR-GARCH(1,1)...")
    mod_gjr = arch_model(returns, p=1, o=1, q=1, vol='Garch', dist='studentst', rescale=False)
    res_gjr = mod_gjr.fit(disp='off')
    print(res_gjr.summary())
    
    # 4. Fit HAR-RV (Corsi, 2009) with Newey-West HAC errors
    # RV_t = beta_0 + beta_d * RV_{t-1} + beta_w * RV_{t-1}^{(w)} + beta_m * RV_{t-1}^{(m)} + eps_t
    print("\n4. Estimating HAR-RV Benchmark (Corsi, 2009)...")
    X_har = df[['HAR_d_Lag1', 'HAR_w_Lag1', 'HAR_m_Lag1']]
    X_har = sm.add_constant(X_har)
    y_har = df['Target_Vol']
    res_har = sm.OLS(y_har, X_har).fit(cov_type='HAC', cov_kwds={'maxlags': 5})
    print(res_har.summary())
    
    # Consolidate parameter estimates for reporting
    params_summary = []
    
    # GARCH
    for p_name in res_garch.params.index:
        params_summary.append({
            'Model': 'GARCH(1,1)',
            'Parameter': p_name,
            'Coefficient': res_garch.params[p_name],
            'Std Error': res_garch.std_err[p_name],
            't-stat': res_garch.tvalues[p_name],
            'p-value': res_garch.pvalues[p_name]
        })
        
    # EGARCH
    for p_name in res_egarch.params.index:
        params_summary.append({
            'Model': 'EGARCH(1,1)',
            'Parameter': p_name,
            'Coefficient': res_egarch.params[p_name],
            'Std Error': res_egarch.std_err[p_name],
            't-stat': res_egarch.tvalues[p_name],
            'p-value': res_egarch.pvalues[p_name]
        })
        
    # GJR-GARCH
    for p_name in res_gjr.params.index:
        params_summary.append({
            'Model': 'GJR-GARCH(1,1)',
            'Parameter': p_name,
            'Coefficient': res_gjr.params[p_name],
            'Std Error': res_gjr.std_err[p_name],
            't-stat': res_gjr.tvalues[p_name],
            'p-value': res_gjr.pvalues[p_name]
        })
        
    # HAR-RV
    for p_name in res_har.params.index:
        params_summary.append({
            'Model': 'HAR-RV',
            'Parameter': p_name,
            'Coefficient': res_har.params[p_name],
            'Std Error': res_har.bse[p_name],
            't-stat': res_har.tvalues[p_name],
            'p-value': res_har.pvalues[p_name]
        })
        
    df_params = pd.DataFrame(params_summary)
    
    # Model Selection Info Criteria
    model_selection = [
        {'Model': 'GARCH(1,1)', 'Log-Likelihood': res_garch.loglikelihood, 'AIC': res_garch.aic, 'BIC': res_garch.bic},
        {'Model': 'EGARCH(1,1)', 'Log-Likelihood': res_egarch.loglikelihood, 'AIC': res_egarch.aic, 'BIC': res_egarch.bic},
        {'Model': 'GJR-GARCH(1,1)', 'Log-Likelihood': res_gjr.loglikelihood, 'AIC': res_gjr.aic, 'BIC': res_gjr.bic},
        {'Model': 'HAR-RV', 'Log-Likelihood': res_har.llf, 'AIC': res_har.aic, 'BIC': res_har.bic}
    ]
    df_models = pd.DataFrame(model_selection)
    
    # Save to tables.xlsx
    try:
        wb = openpyxl.load_workbook("tables.xlsx")
    except FileNotFoundError:
        wb = openpyxl.Workbook()
        if 'Sheet' in wb.sheetnames:
            wb.remove(wb['Sheet'])
    if 'EconometricSummary' in wb.sheetnames:
        wb.remove(wb['EconometricSummary'])
    ws_g = wb.create_sheet('EconometricSummary')
    ws_g.append(['Model', 'Parameter', 'Coefficient', 'Std Error', 't-stat', 'p-value'])
    for idx, row in df_params.iterrows():
        ws_g.append(list(row.values))
        
    if 'ModelSelection' in wb.sheetnames:
        wb.remove(wb['ModelSelection'])
    ws_ms = wb.create_sheet('ModelSelection')
    ws_ms.append(['Model', 'Log-Likelihood', 'AIC', 'BIC'])
    for idx, row in df_models.iterrows():
        ws_ms.append(list(row.values))
        
    wb.save("tables.xlsx")
    print("Econometric parameters and HAR-RV results saved to tables.xlsx.")

if __name__ == "__main__":
    main()
