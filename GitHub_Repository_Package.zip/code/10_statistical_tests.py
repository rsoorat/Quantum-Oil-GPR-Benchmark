import pandas as pd
import numpy as np
import yaml
from scipy.stats import t
import openpyxl
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

def qlike_loss(y_true, y_pred):
    """
    Standard Gaussian QLIKE loss in terms of variance:
    QLIKE_t = RV_t / v_hat_t - ln(RV_t / v_hat_t) - 1
    where RV_t = y_true^2 and v_hat_t = y_pred^2
    """
    rv_true = np.clip(y_true ** 2, 1e-6, None)
    v_pred = np.clip(y_pred ** 2, 1e-6, None)
    return np.mean(rv_true / v_pred - np.log(rv_true / v_pred) - 1)

def dm_test(y_true, y_pred1, y_pred2, h=1, power=2):
    """
    Diebold-Mariano Test with Harvey-Leybourne-Newbold correction and Newey-West HAC variance.
    power=2 for MSE loss differential.
    """
    e1 = np.abs(y_true - y_pred1) ** power
    e2 = np.abs(y_true - y_pred2) ** power
    d = e1 - e2
    d_bar = np.mean(d)
    N = len(d)
    
    # Newey-West HAC variance estimator (lag truncation = h-1)
    gamma = np.zeros(h)
    for lag in range(h):
        if lag == 0:
            gamma[lag] = np.mean((d - d_bar) ** 2)
        else:
            gamma[lag] = np.mean((d[:-lag] - d_bar) * (d[lag:] - d_bar))
            
    var_d = gamma[0]
    for lag in range(1, h):
        var_d += 2 * (1 - lag/h) * gamma[lag]
        
    var_d_bar = var_d / N
    if var_d_bar <= 0:
        var_d_bar = 1e-8
        
    stat = d_bar / np.sqrt(var_d_bar)
    
    # Harvey-Leybourne-Newbold small sample correction
    hln_corr = np.sqrt((N + 1 - 2*h + (h/N)*(h-1)) / N)
    stat_corrected = stat * hln_corr
    
    # Two-sided p-value from Student-t distribution
    p_val = 2 * (1 - t.cdf(np.abs(stat_corrected), df=N-1))
    
    return stat_corrected, p_val

def benjamini_hochberg(p_values):
    """
    Applies Benjamini-Hochberg False Discovery Rate (FDR) adjustment.
    """
    p_arr = np.array(p_values)
    n = len(p_arr)
    sorted_indices = np.argsort(p_arr)
    sorted_p = p_arr[sorted_indices]
    
    adjusted_p = np.zeros(n)
    cum_min = 1.0
    for i in range(n-1, -1, -1):
        rank = i + 1
        adj = (sorted_p[i] * n) / rank
        cum_min = min(cum_min, adj)
        adjusted_p[sorted_indices[i]] = min(1.0, cum_min)
        
    return adjusted_p

def main():
    print("=== Step 10: Statistical Evaluation, DM Tests, and FDR Corrections ===")
    
    df_preds = pd.read_csv("data/oil_model_predictions.csv")
    y_true = df_preds['Actual_Vol'].values
    
    model_cols = [c for c in df_preds.columns if c not in ['date', 'Actual_Vol']]
    
    # 1. Performance Metrics
    performance_metrics = []
    print("\n--- Out-of-Sample Volatility Forecasting Accuracy ---")
    for m in model_cols:
        y_pred = df_preds[m].values
        mae = mean_absolute_error(y_true, y_pred)
        rmse = np.sqrt(mean_squared_error(y_true, y_pred))
        r2 = r2_score(y_true, y_pred)
        qlike = qlike_loss(y_true, y_pred)
        
        print(f"  {m:22s}: RMSE={rmse:.4f}, MAE={mae:.4f}, R2={r2:.4f}, QLIKE={qlike:.4f}")
        
        performance_metrics.append({
            'Model': m,
            'RMSE': rmse,
            'MAE': mae,
            'R^2': r2,
            'QLIKE': qlike
        })
        
    df_metrics = pd.DataFrame(performance_metrics)
    
    # 2. Pairwise Diebold-Mariano Tests with FDR
    print("\n--- Pairwise Diebold-Mariano Tests (MSE Loss) ---")
    n_models = len(model_cols)
    dm_matrix_stat = np.zeros((n_models, n_models))
    dm_matrix_p = np.zeros((n_models, n_models))
    dm_matrix_fdr = np.zeros((n_models, n_models))
    
    p_vals_flat = []
    pairs = []
    for i in range(n_models):
        for j in range(n_models):
            if i == j:
                dm_matrix_p[i, j] = 1.0
            else:
                pred_i = df_preds[model_cols[i]].values
                pred_j = df_preds[model_cols[j]].values
                stat, p_val = dm_test(y_true, pred_i, pred_j, h=1, power=2)
                dm_matrix_stat[i, j] = stat
                dm_matrix_p[i, j] = p_val
                if i < j:
                    p_vals_flat.append(p_val)
                    pairs.append((i, j))
                    
    # FDR adjustment across all 78 pairs
    fdr_adj = benjamini_hochberg(p_vals_flat)
    np.fill_diagonal(dm_matrix_fdr, 1.0)
    
    pairwise_rows = []
    for idx, (i, j) in enumerate(pairs):
        dm_matrix_fdr[i, j] = fdr_adj[idx]
        dm_matrix_fdr[j, i] = fdr_adj[idx]
        m1 = model_cols[i].replace('_Forecast', '')
        m2 = model_cols[j].replace('_Forecast', '')
        stat_val = dm_matrix_stat[i, j]
        p_raw = p_vals_flat[idx]
        p_fdr = fdr_adj[idx]
        sig_fdr = "Yes (q < 0.05)" if p_fdr < 0.05 else "No (p >= 0.05)"
        
        pairwise_rows.append({
            'Model A': m1,
            'Model B': m2,
            'DM Statistic (HLN)': stat_val,
            'Raw p-value': p_raw,
            'BH-Adjusted p-value': p_fdr,
            'Significant at FDR q=0.05': sig_fdr
        })
        
    df_pairwise_dm = pd.DataFrame(pairwise_rows)
    
    # Key comparisons focusing on QSVR and leading baselines
    key_pairs_list = [
        ('QSVR', 'HAR_RV'),
        ('QSVR', 'SVR_Linear'),
        ('QSVR', 'ElasticNet'),
        ('QSVR', 'SVR_RBF'),
        ('QSVR', 'GARCH'),
        ('QSVR', 'XGBoost'),
        ('HAR_RV', 'SVR_Linear'),
        ('HAR_RV', 'ElasticNet'),
        ('HAR_RV', 'GARCH'),
        ('HAR_RV', 'SVR_RBF'),
        ('SVR_Linear', 'ElasticNet'),
        ('ElasticNet', 'GARCH'),
        ('XGBoost', 'LightGBM')
    ]
    key_dm_rows = []
    for m1, m2 in key_pairs_list:
        sub = df_pairwise_dm[((df_pairwise_dm['Model A'] == m1) & (df_pairwise_dm['Model B'] == m2)) | 
                             ((df_pairwise_dm['Model A'] == m2) & (df_pairwise_dm['Model B'] == m1))]
        if not sub.empty:
            key_dm_rows.append(sub.iloc[0].to_dict())
    df_key_dm = pd.DataFrame(key_dm_rows)
    
    clean_cols = [m.replace('_Forecast', '') for m in model_cols]
    df_dm_p = pd.DataFrame(dm_matrix_p, index=clean_cols, columns=clean_cols)
    df_dm_fdr = pd.DataFrame(dm_matrix_fdr, index=clean_cols, columns=clean_cols)
    
    # 3. Save to tables.xlsx
    try:
        wb = openpyxl.load_workbook("tables.xlsx")
    except FileNotFoundError:
        wb = openpyxl.Workbook()
        if 'Sheet' in wb.sheetnames:
            wb.remove(wb['Sheet'])
    
    if 'ModelPerformance' in wb.sheetnames:
        wb.remove(wb['ModelPerformance'])
    ws_perf = wb.create_sheet('ModelPerformance')
    ws_perf.append(['Model', 'RMSE', 'MAE', 'R^2', 'QLIKE'])
    for idx, row in df_metrics.iterrows():
        ws_perf.append(list(row.values))
        
    # Table with side-by-side Raw and BH-adjusted p-values
    if 'Key_DM_FDR_Comparisons' in wb.sheetnames:
        wb.remove(wb['Key_DM_FDR_Comparisons'])
    ws_kdm = wb.create_sheet('Key_DM_FDR_Comparisons')
    ws_kdm.append(list(df_key_dm.columns))
    for idx, row in df_key_dm.iterrows():
        ws_kdm.append(list(row.values))
        
    if 'All_Pairwise_DM_FDR' in wb.sheetnames:
        wb.remove(wb['All_Pairwise_DM_FDR'])
    ws_adm = wb.create_sheet('All_Pairwise_DM_FDR')
    ws_adm.append(list(df_pairwise_dm.columns))
    for idx, row in df_pairwise_dm.iterrows():
        ws_adm.append(list(row.values))
        
    if 'DM_Test_pvalues' in wb.sheetnames:
        wb.remove(wb['DM_Test_pvalues'])
    ws_dm = wb.create_sheet('DM_Test_pvalues')
    ws_dm.append(['Model / Benchmark'] + [m.replace('_Forecast', '') for m in model_cols])
    for i, m in enumerate(model_cols):
        ws_dm.append([m.replace('_Forecast', '')] + list(dm_matrix_p[i, :]))
        
    if 'DM_FDR_pvalues' in wb.sheetnames:
        wb.remove(wb['DM_FDR_pvalues'])
    ws_fdr = wb.create_sheet('DM_FDR_pvalues')
    ws_fdr.append(['Model / Benchmark'] + [m.replace('_Forecast', '') for m in model_cols])
    for i, m in enumerate(model_cols):
        ws_fdr.append([m.replace('_Forecast', '')] + list(dm_matrix_fdr[i, :]))
        
    wb.save("tables.xlsx")
    
    # Save to statistical_results.xlsx
    with pd.ExcelWriter("statistical_results.xlsx", engine='openpyxl', mode='w') as writer:
        df_metrics.to_excel(writer, sheet_name="Performance_Metrics", index=False)
        df_key_dm.to_excel(writer, sheet_name="Key_DM_FDR", index=False)
        df_pairwise_dm.to_excel(writer, sheet_name="All_Pairwise_DM", index=False)
        df_dm_p.to_excel(writer, sheet_name="DM_Raw_pvalues")
        df_dm_fdr.to_excel(writer, sheet_name="DM_BH_FDR_pvalues")
        
    print("\nModel performance, Diebold-Mariano raw and BH-FDR adjusted results saved.")

if __name__ == "__main__":
    main()
