import os, shutil, zipfile

def main():
    print("=== Creating Submission Zip & Shareable PDF Package ===")
    
    base_dir = os.path.abspath(".")
    
    # 1. Create dedicated shareable PDFs directory
    share_dir = os.path.join(base_dir, "PDF_Share_Package")
    os.makedirs(share_dir, exist_ok=True)
    
    shutil.copy2("Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript.pdf", os.path.join(share_dir, "1_Main_Manuscript_Quantum_Oil_GPR.pdf"))
    shutil.copy2("supplementary_material.pdf", os.path.join(share_dir, "2_Supplementary_Online_Appendix.pdf"))
    shutil.copy2("cover_letter.pdf", os.path.join(share_dir, "3_Cover_Letter.pdf"))
    shutil.copy2("Title_Page.pdf", os.path.join(share_dir, "4_Title_Page_with_Author_Details.pdf"))
    shutil.copy2("Declaration_of_Interest.pdf", os.path.join(share_dir, "5_Declaration_of_Interest_Statement.pdf"))
    shutil.copy2("figures/graphical_abstract.pdf", os.path.join(share_dir, "6_Graphical_Abstract.pdf"))
    shutil.copy2("figures/graphical_abstract.png", os.path.join(share_dir, "7_Graphical_Abstract.png"))
    
    # 2. Create Shareable PDFs ZIP
    share_zip_path = os.path.join(base_dir, "Shareable_PDFs_Package.zip")
    with zipfile.ZipFile(share_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, _, files in os.walk(share_dir):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, share_dir)
                zipf.write(file_path, arcname)
    print(f"Created: {share_zip_path} ({os.path.getsize(share_zip_path):,} bytes)")

    # 3. Create Full Journal Submission ZIP
    sub_zip_path = os.path.join(base_dir, "Journal_Submission_Package.zip")
    with zipfile.ZipFile(sub_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # Key PDF and DOCX files
        files_to_add = [
            "Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript.pdf",
            "Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript.docx",
            "supplementary_material.pdf",
            "Supplementary_Material.docx",
            "cover_letter.pdf",
            "Cover_Letter.docx",
            "Title_Page.pdf",
            "Title_Page.docx",
            "Declaration_of_Interest.pdf",
            "Declaration_of_Interest.docx",
            "Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript.tex",
            "supplementary_material.tex",
            "cover_letter.tex",
            "Title_Page.tex",
            "Declaration_of_Interest.tex",
            "references.bib",
            "tables.xlsx",
            "README.md",
            "config.yaml"
        ]
        for f in files_to_add:
            if os.path.exists(f):
                zipf.write(f, arcname=os.path.join("manuscript_files", f))
                
        # Add Figures
        if os.path.exists("figures"):
            for root, _, files in os.walk("figures"):
                for file in files:
                    file_path = os.path.join(root, file)
                    arcname = os.path.join("figures", os.path.relpath(file_path, "figures"))
                    zipf.write(file_path, arcname)
                    
        # Add Code
        if os.path.exists("code"):
            for root, _, files in os.walk("code"):
                for file in files:
                    if "__pycache__" not in root:
                        file_path = os.path.join(root, file)
                        arcname = os.path.join("code", os.path.relpath(file_path, "code"))
                        zipf.write(file_path, arcname)
                        
    print(f"Created: {sub_zip_path} ({os.path.getsize(sub_zip_path):,} bytes)")
    print("=== All packages successfully assembled! ===")

if __name__ == "__main__":
    main()
