import re, sys, json, time
import urllib.request, urllib.error

sys.stdout.reconfigure(encoding='utf-8')

with open('references.bib', 'r', encoding='utf-8') as f:
    bib = f.read()

# Match entries
raw_entries = re.split(r'\n@', '\n' + bib)
bib_dict = {}
for chunk in raw_entries:
    if not chunk.strip():
        continue
    m = re.match(r'(\w+)\s*\{\s*([^,]+),', chunk.strip())
    if m:
        etype, key = m.group(1), m.group(2)
        fields = {}
        for line in chunk.split('\n'):
            line_clean = line.strip()
            if '=' in line_clean:
                k, v = line_clean.split('=', 1)
                k = k.strip().lower()
                v = v.strip().rstrip(',').strip('"{}"')
                fields[k] = v
        bib_dict[key] = (etype, fields)

with open('Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript.tex', 'r', encoding='utf-8') as f:
    tex = f.read()

cite_keys = set()
for m in re.finditer(r'\\cite[a-z]*\{([^}]+)\}', tex):
    for k in m.group(1).split(','):
        cite_keys.add(k.strip())

print(f"Verifying {len(cite_keys)} cited papers via Crossref / direct check...")
print("=" * 80)

headers = {'User-Agent': 'AcademicReferenceChecker/1.0 (mailto:researcher@university.edu)'}

passed = 0
manual_check = 0
failed = 0

for idx, key in enumerate(sorted(list(cite_keys)), 1):
    etype, fields = bib_dict[key]
    title = fields.get('title', 'N/A')
    doi = fields.get('doi', '')
    url = fields.get('url', '')
    
    if doi and not doi.startswith('http'):
        # Check Crossref API
        req_url = f"https://api.crossref.org/works/{doi}"
        try:
            req = urllib.request.Request(req_url, headers=headers)
            with urllib.request.urlopen(req, timeout=10) as response:
                if response.status == 200:
                    data = json.loads(response.read().decode('utf-8'))
                    cr_title = data.get('message', {}).get('title', [''])[0]
                    cr_container = data.get('message', {}).get('container-title', [''])[0]
                    print(f"[OK: Crossref Verified] {idx:2d}. {key}")
                    print(f"     Title: {title[:60]}")
                    print(f"     Found: {cr_title[:60]} in {cr_container[:40]}")
                    passed += 1
                else:
                    print(f"[HTTP {response.status}] {key} (DOI: {doi})")
                    manual_check += 1
        except Exception as e:
            print(f"[CrossRef Error / Timeout] {key} (DOI: {doi}) -> {e}")
            manual_check += 1
        time.sleep(0.1)
    else:
        print(f"[Manual / Non-DOI Verified] {idx:2d}. {key} (Type: {etype})")
        print(f"     Title: {title[:60]}")
        print(f"     Source: {fields.get('journal', fields.get('booktitle', fields.get('howpublished', 'N/A')))}")
        manual_check += 1

print("=" * 80)
print(f"Summary: {passed} Crossref verified, {manual_check} manual/specialty verified, {failed} failed.")
