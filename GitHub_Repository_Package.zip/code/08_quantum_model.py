import pennylane as qml
import numpy as np
import pandas as pd
from sklearn.svm import SVR
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.metrics.pairwise import rbf_kernel, polynomial_kernel, linear_kernel
import openpyxl

QUANTUM_FEATURES = ['Vol_Lag1', 'GPRD_Lag1', 'VIX_Lag1', 'Return_Lag1']

dev = qml.device('default.qubit', wires=4)

@qml.qnode(dev)
def get_pqc_state(x):
    # Angle embedding via RY rotations
    qml.AngleEmbedding(x, wires=range(4), rotation='Y')
    # Entanglement layer via circular CNOT chain
    qml.CNOT(wires=[0, 1])
    qml.CNOT(wires=[1, 2])
    qml.CNOT(wires=[2, 3])
    qml.CNOT(wires=[3, 0])
    return qml.state()

def compute_quantum_states(X_scaled):
    """
    Computes 16-dimensional quantum statevectors for all samples in X_scaled.
    """
    states = np.array([get_pqc_state(row) for row in X_scaled])
    return states

def compute_quantum_kernel(states1, states2):
    """
    Computes fidelity overlap Gram matrix: K_ij = |<psi(x_i)|psi(x_j)>|^2
    """
    overlap = states1 @ states2.T.conj()
    K = np.abs(overlap) ** 2
    return K

def compute_kernel_alignment(K, y):
    """
    Kernel-Target Alignment A(K, y) = <K, y y^T>_F / (||K||_F * ||y y^T||_F)
    """
    y_mat = np.outer(y, y)
    norm_k = np.linalg.norm(K, 'fro')
    norm_y = np.linalg.norm(y_mat, 'fro')
    if norm_k == 0 or norm_y == 0:
        return 0.0
    return np.sum(K * y_mat) / (norm_k * norm_y)

def compute_kernel_properties(K):
    """
    Computes condition number, rank, and effective dimension of a kernel matrix.
    """
    evals = np.linalg.eigvalsh(K)
    evals = np.sort(evals)[::-1]
    evals = np.clip(evals, 0, None)
    
    cond_num = evals[0] / (evals[-1] + 1e-12)
    rank = np.sum(evals > 1e-6)
    # Effective dimension (normalized entropy of spectrum)
    p = evals / (np.sum(evals) + 1e-12)
    eff_dim = np.exp(-np.sum(p * np.log(p + 1e-12)))
    
    return cond_num, rank, eff_dim

def train_qsvr(X_train, y_train, X_val, y_val, C_val=1.0):
    X_train_q = X_train[QUANTUM_FEATURES].values
    X_val_q = X_val[QUANTUM_FEATURES].values
    
    scaler = MinMaxScaler(feature_range=(0, np.pi))
    X_train_scaled = scaler.fit_transform(X_train_q)
    X_val_scaled = scaler.transform(X_val_q)
    
    # Compute states
    states_train = compute_quantum_states(X_train_scaled)
    states_val = compute_quantum_states(X_val_scaled)
    
    # Compute Gram matrices
    K_train = compute_quantum_kernel(states_train, states_train)
    K_val = compute_quantum_kernel(states_val, states_train)
    
    # Fit SVR with precomputed kernel
    qsvr = SVR(kernel='precomputed', C=C_val, epsilon=0.05)
    qsvr.fit(K_train, y_train)
    
    return qsvr, scaler, states_train

def predict_qsvr(model, scaler, states_train, X_test_raw):
    X_test_q = X_test_raw[QUANTUM_FEATURES].values
    X_test_scaled = scaler.transform(X_test_q)
    states_test = compute_quantum_states(X_test_scaled)
    K_test = compute_quantum_kernel(states_test, states_train)
    preds = model.predict(K_test)
    return preds

def benchmark_kernels(X_train_scaled, y_train):
    """
    Computes kernel alignment, condition number, and effective dimension for Linear, Poly, RBF, and Quantum kernels.
    """
    states_train = compute_quantum_states(X_train_scaled)
    K_quantum = compute_quantum_kernel(states_train, states_train)
    K_linear = linear_kernel(X_train_scaled, X_train_scaled)
    K_poly = polynomial_kernel(X_train_scaled, X_train_scaled, degree=2)
    K_rbf = rbf_kernel(X_train_scaled, X_train_scaled, gamma=1.0)
    
    kernels = {
        'Linear Kernel': K_linear,
        'Polynomial (d=2) Kernel': K_poly,
        'RBF (Gaussian) Kernel': K_rbf,
        'Quantum PQC (4-Qubit) Kernel': K_quantum
    }
    
    kernel_bench = []
    for name, K in kernels.items():
        alignment = compute_kernel_alignment(K, y_train)
        cond, rank, eff_dim = compute_kernel_properties(K)
        kernel_bench.append({
            'Kernel Architecture': name,
            'Kernel-Target Alignment': alignment,
            'Effective Dimension': eff_dim,
            'Matrix Rank': rank,
            'Condition Number': cond
        })
        
    return pd.DataFrame(kernel_bench)

def main():
    print("=== Step 8: Quantum Kernel Properties and Benchmarking ===")
    
    # Create Quantum Configs table
    q_configs = [
        {'Component': 'Quantum Framework', 'Parameter Value': 'PennyLane (v0.45.1) default.qubit', 'Details / Structure': 'Exact statevector simulation in C++ backend'},
        {'Component': 'Qubit Register', 'Parameter Value': '4 Wires (n=4)', 'Details / Structure': '1 qubit assigned per encoded feature'},
        {'Component': 'Encoded Features', 'Parameter Value': 'Vol_Lag1, GPRD_Lag1, VIX_Lag1, Return_Lag1', 'Details / Structure': 'Normalized to [0, pi] dynamic range'},
        {'Component': 'Feature Map Encoding', 'Parameter Value': 'Angle Embedding: R_Y(x_i)', 'Details / Structure': 'Single-qubit Pauli-Y rotation gates: exp(-i*x_i/2 * Y)'},
        {'Component': 'Entanglement Topology', 'Parameter Value': 'Circular CNOT Chain', 'Details / Structure': 'CNOT(0->1), CNOT(1->2), CNOT(2->3), CNOT(3->0)'},
        {'Component': 'Hilbert Space Dimension', 'Parameter Value': '2^4 = 16 dimensions', 'Details / Structure': 'Full complex statevector |psi(x)> in C^16'},
        {'Component': 'Quantum Kernel Function', 'Parameter Value': '|<psi(x_i)|psi(x_j)>|^2', 'Details / Structure': 'Transition probability overlap fidelity in [0, 1]'},
        {'Component': 'Dual Optimizer', 'Parameter Value': 'Support Vector Regression (C=1.0, eps=0.05)', 'Details / Structure': 'Convex quadratic programming on precomputed Gram matrix'}
    ]
    df_q = pd.DataFrame(q_configs)
    
    try:
        wb = openpyxl.load_workbook("tables.xlsx")
    except FileNotFoundError:
        wb = openpyxl.Workbook()
        if 'Sheet' in wb.sheetnames:
            wb.remove(wb['Sheet'])
    if 'QuantumConfigs' in wb.sheetnames:
        wb.remove(wb['QuantumConfigs'])
    ws_q = wb.create_sheet('QuantumConfigs')
    ws_q.append(['Component', 'Parameter Value', 'Details / Gate Structure'])
    for idx, row in df_q.iterrows():
        ws_q.append(list(row.values))
        
    wb.save("tables.xlsx")
    print("Quantum configurations saved to tables.xlsx.")

if __name__ == "__main__":
    main()
