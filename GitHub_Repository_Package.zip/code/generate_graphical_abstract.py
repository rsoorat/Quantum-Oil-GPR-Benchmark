import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
import os

def create_graphical_abstract():
    print("=== Generating High-Resolution Publication Graphical Abstract ===")
    
    os.makedirs("figures", exist_ok=True)
    
    # Create figure with 16:9 widescreen ratio
    fig, ax = plt.subplots(figsize=(16, 9), dpi=300)
    ax.set_xlim(0, 16)
    ax.set_ylim(0, 9)
    ax.axis('off')
    
    # Background styling
    fig.patch.set_facecolor('#F8FAFC')
    
    # Curated Harmonious Palette
    c_primary = '#1E3A8A'   # Deep Academic Navy
    c_secondary = '#2563EB' # Royal Blue
    c_accent = '#D97706'    # Amber Bronze
    c_quantum = '#6B21A8'   # Deep Quantum Purple
    c_dark = '#0F172A'      # Slate 900
    c_card_bg = '#FFFFFF'
    c_border = '#CBD5E1'
    c_green = '#15803D'     # Emerald Green
    c_red = '#B91C1C'       # Crimson Red
    
    # -------------------------------------------------------------
    # 1. HEADER BANNER (Top)
    # -------------------------------------------------------------
    header_box = patches.FancyBboxPatch((0.4, 7.85), 15.2, 0.95, boxstyle="round,pad=0.08",
                                        facecolor=c_primary, edgecolor='#1E40AF', linewidth=1.5)
    ax.add_patch(header_box)
    
    ax.text(8.0, 8.45, "Quantum Kernel Methods for Crude Oil Volatility Forecasting under Geopolitical Risk",
            ha='center', va='center', fontsize=16.5, fontweight='bold', color='white', fontfamily='sans-serif')
    ax.text(8.0, 8.05, "A Controlled Out-of-Sample Benchmark (10-Year Daily Sample 2016–2026, N = 2,473 Trading Days)",
            ha='center', va='center', fontsize=11.5, color='#E2E8F0', fontfamily='sans-serif')

    # -------------------------------------------------------------
    # 2. COLUMN 1: DATA & INFORMATION SET (x: 0.4 to 3.9)
    # -------------------------------------------------------------
    p1 = patches.FancyBboxPatch((0.4, 0.65), 3.5, 7.0, boxstyle="round,pad=0.1",
                                facecolor=c_card_bg, edgecolor=c_border, linewidth=1.2)
    ax.add_patch(p1)
    
    h1 = patches.FancyBboxPatch((0.4, 7.05), 3.5, 0.6, boxstyle="round,pad=0.04",
                                facecolor='#F1F5F9', edgecolor=c_border, linewidth=1.0)
    ax.add_patch(h1)
    ax.text(2.15, 7.35, "1. Empirical Information Set", ha='center', va='center', fontsize=12, fontweight='bold', color=c_dark)
    
    d_items = [
        ("WTI Spot Volatility", "5-Day Rolling Volatility Proxy\nN = 2,473 Clean Trading Days", '#1E3A8A'),
        ("Geopolitical Risk Indices", "Matteo Iacoviello GPRD (News)\nAI-GPR & Oil GPR Subindex", '#B91C1C'),
        ("Cross-Asset Controls", "CBOE VIX, Gold, US Dollar (DXY),\nNatural Gas, Brent, 10Y Yield", '#2563EB'),
        ("Strict Information Horizon", "Zero Look-Ahead: All Features at t-1\nPre-Test Cutoffs (2016–2023)", '#15803D')
    ]
    
    y_pos = 6.4
    for title, desc, col in d_items:
        box = patches.FancyBboxPatch((0.55, y_pos - 1.05), 3.2, 1.15, boxstyle="round,pad=0.06",
                                     facecolor='#F8FAFC', edgecolor=col, linewidth=1.1)
        ax.add_patch(box)
        ax.text(0.70, y_pos - 0.15, title, ha='left', va='top', fontsize=9.5, fontweight='bold', color=col)
        ax.text(0.70, y_pos - 0.45, desc, ha='left', va='top', fontsize=8.2, color='#475569', linespacing=1.25)
        y_pos -= 1.45

    # -------------------------------------------------------------
    # 3. COLUMN 2: MODEL ARCHITECTURES (x: 4.2 to 7.9)
    # -------------------------------------------------------------
    p2 = patches.FancyBboxPatch((4.2, 0.65), 3.7, 7.0, boxstyle="round,pad=0.1",
                                facecolor=c_card_bg, edgecolor=c_border, linewidth=1.2)
    ax.add_patch(p2)
    
    h2 = patches.FancyBboxPatch((4.2, 7.05), 3.7, 0.6, boxstyle="round,pad=0.04",
                                facecolor='#F1F5F9', edgecolor=c_border, linewidth=1.0)
    ax.add_patch(h2)
    ax.text(6.05, 7.35, "2. 14-Specification Benchmark Suite", ha='center', va='center', fontsize=12, fontweight='bold', color=c_dark)
    
    # 4-Qubit Circuit Box (Highlight)
    q_box = patches.FancyBboxPatch((4.35, 4.25), 3.4, 2.65, boxstyle="round,pad=0.08",
                                   facecolor='#FAF5FF', edgecolor=c_quantum, linewidth=1.5)
    ax.add_patch(q_box)
    ax.text(6.05, 6.65, "4-Qubit Quantum Kernel (QSVR)", ha='center', va='center', fontsize=10.5, fontweight='bold', color=c_quantum)
    ax.text(6.05, 6.25, r"$|0\rangle^{\otimes 4} \;\longrightarrow\; \bigotimes R_Y(x_k) \;\longrightarrow\; U_{\mathrm{ent}} \;\longrightarrow\; |\psi(\mathbf{x})\rangle$", ha='center', va='center', fontsize=8.2, fontweight='bold', color='#581C87')
    ax.text(6.05, 5.75, r"Statevector Fidelity: $K_{ij} = |\langle\psi(\mathbf{x}_i)|\psi(\mathbf{x}_j)\rangle|^2$", ha='center', va='center', fontsize=8.2, fontweight='bold', color=c_quantum)
    ax.text(6.05, 5.15, "• 4 Core Features ($t-1$ lagged inputs)\n• Parameterized Unitary Feature Map\n• Distinct Nonlinear Representation", ha='center', va='center', fontsize=8.2, color='#334155', linespacing=1.35)
    ax.text(6.05, 4.50, "Hardware-Efficient Circular CNOT Topology", ha='center', va='center', fontsize=7.6, fontstyle='italic', color='#6B21A8')
    
    # Econometric & Classical ML Models
    m_box = patches.FancyBboxPatch((4.35, 0.80), 3.4, 3.30, boxstyle="round,pad=0.08",
                                   facecolor='#F8FAFC', edgecolor=c_secondary, linewidth=1.1)
    ax.add_patch(m_box)
    ax.text(6.05, 3.85, "12 Classical Models + Persistence", ha='center', va='center', fontsize=10.2, fontweight='bold', color=c_primary)
    
    m_text = [
        ("• Persistence Baseline:", "Lagged 5-day proxy (R²=0.7620)"),
        ("• HAR-RV-type (Corsi 2009):", "Daily, Weekly, Monthly Components"),
        ("• GARCH Suite:", "GARCH(1,1), EGARCH, GJR-GARCH"),
        ("• Support Vector:", "Linear, Polynomial, Matched Tuned RBF"),
        ("• Tree Ensembles:", "Random Forest, XGBoost, LightGBM"),
        ("• Regularized & Neural:", "ElasticNet & 1-Layer PyTorch LSTM")
    ]
    y_m = 3.50
    for b_title, b_desc in m_text:
        ax.text(4.50, y_m, b_title, ha='left', va='center', fontsize=8.0, fontweight='bold', color=c_dark)
        ax.text(4.50, y_m - 0.18, b_desc, ha='left', va='center', fontsize=7.4, color='#64748B')
        y_m -= 0.44

    # -------------------------------------------------------------
    # 4. COLUMN 3: EMPIRICAL BENCHMARK (x: 8.2 to 11.9)
    # -------------------------------------------------------------
    p3 = patches.FancyBboxPatch((8.2, 0.65), 3.7, 7.0, boxstyle="round,pad=0.1",
                                facecolor=c_card_bg, edgecolor=c_border, linewidth=1.2)
    ax.add_patch(p3)
    
    h3 = patches.FancyBboxPatch((8.2, 7.05), 3.7, 0.6, boxstyle="round,pad=0.04",
                                facecolor='#F1F5F9', edgecolor=c_border, linewidth=1.0)
    ax.add_patch(h3)
    ax.text(10.05, 7.35, "3. Out-of-Sample Results", ha='center', va='center', fontsize=12, fontweight='bold', color=c_dark)
    
    # Point Forecasting Table Mini-Card
    res_box = patches.FancyBboxPatch((8.35, 4.05), 3.4, 2.85, boxstyle="round,pad=0.08",
                                     facecolor='#F8FAFC', edgecolor=c_primary, linewidth=1.1)
    ax.add_patch(res_box)
    ax.text(10.05, 6.65, "Point Forecasting (655 Test Days)", ha='center', va='center', fontsize=10.0, fontweight='bold', color=c_primary)
    
    perf_lines = [
        ("HAR-RV-type (Corsi)", "0.6708", "0.7800", '#1E3A8A', True),
        ("SVR-Linear", "0.6717", "0.7794", '#1E3A8A', False),
        ("Persistence Baseline", "0.6811", "0.7731", '#059669', False),
        ("QSVR (4-Qubit)", "0.7007", "0.7600", '#6B21A8', True),
        ("ElasticNet", "0.7017", "0.7593", '#D97706', False),
        ("SVR-RBF (Matched)", "0.7140", "0.7508", '#64748B', False)
    ]
    ax.text(8.50, 6.30, "Model", ha='left', va='center', fontsize=8.0, fontweight='bold', color='#475569')
    ax.text(10.35, 6.30, "RMSE", ha='center', va='center', fontsize=8.0, fontweight='bold', color='#475569')
    ax.text(11.35, 6.30, "R²", ha='center', va='center', fontsize=8.0, fontweight='bold', color='#475569')
    
    y_p = 5.95
    for m_name, rmse_val, r2_val, col_p, is_b in perf_lines:
        font_w = 'bold' if is_b else 'normal'
        ax.text(8.50, y_p, m_name, ha='left', va='center', fontsize=7.6, fontweight=font_w, color=col_p)
        ax.text(10.35, y_p, rmse_val, ha='center', va='center', fontsize=7.6, fontweight=font_w, color=c_dark)
        ax.text(11.35, y_p, r2_val, ha='center', va='center', fontsize=7.6, fontweight=font_w, color=c_dark)
        y_p -= 0.30
        
    # Controlled 4F Box
    c4f_box = patches.FancyBboxPatch((8.35, 0.80), 3.4, 3.10, boxstyle="round,pad=0.08",
                                     facecolor='#FFFBEB', edgecolor='#F59E0B', linewidth=1.1)
    ax.add_patch(c4f_box)
    ax.text(10.05, 3.65, "Controlled 4-Feature Experiment", ha='center', va='center', fontsize=9.8, fontweight='bold', color='#92400E')
    ax.text(10.05, 3.30, "Direct Quantum vs. Classical Kernels:", ha='center', va='center', fontsize=7.8, color='#78350F')
    ax.text(8.50, 2.90, "• QSVR (4F):     RMSE = 0.7007, R² = 0.7600", ha='left', va='center', fontsize=7.6, fontweight='bold', color=c_quantum)
    ax.text(8.50, 2.55, "• SVR-RBF (4F): RMSE = 0.7140, R² = 0.7508", ha='left', va='center', fontsize=7.6, color='#78350F')
    ax.text(8.50, 2.20, "• SVR-Lin (4F):   RMSE = 0.6726, R² = 0.7788", ha='left', va='center', fontsize=7.6, color='#78350F')
    ax.text(10.05, 1.65, "Key Takeaway:\nQSVR is competitive with tuned RBF;\nDM test (p = 0.212) does not reject\nequal out-of-sample accuracy", ha='center', va='center', fontsize=7.4, fontweight='bold', color=c_primary, linespacing=1.2)

    # -------------------------------------------------------------
    # 5. COLUMN 4: RISK & PORTFOLIO UTILITY (x: 12.2 to 15.6)
    # -------------------------------------------------------------
    p4 = patches.FancyBboxPatch((12.2, 0.65), 3.4, 7.0, boxstyle="round,pad=0.1",
                                facecolor=c_card_bg, edgecolor=c_border, linewidth=1.2)
    ax.add_patch(p4)
    
    h4 = patches.FancyBboxPatch((12.2, 7.05), 3.4, 0.6, boxstyle="round,pad=0.04",
                                facecolor='#F1F5F9', edgecolor=c_border, linewidth=1.0)
    ax.add_patch(h4)
    ax.text(13.90, 7.35, "4. Risk & Economic Utility", ha='center', va='center', fontsize=12, fontweight='bold', color=c_dark)
    
    # 95% VaR Card
    var_box = patches.FancyBboxPatch((12.35, 4.05), 3.1, 2.85, boxstyle="round,pad=0.08",
                                     facecolor='#F8FAFC', edgecolor=c_green, linewidth=1.1)
    ax.add_patch(var_box)
    ax.text(13.90, 6.65, "95% Value-at-Risk Backtest", ha='center', va='center', fontsize=10.0, fontweight='bold', color=c_green)
    ax.text(13.90, 6.30, "Model Distributions (N = 655, 2024–2026):", ha='center', va='center', fontsize=7.3, color='#475569')
    
    var_points = [
        ("GARCH(1,1) t:", "32 breaches (4.89%, p=0.897)"),
        ("GJR-GARCH t:", "31 breaches (4.73%, p=0.754)"),
        ("QSVR Frozen t:", "34 breaches (5.19%, p=0.825)"),
        ("QSVR Gaussian:", "51 breaches (7.79%, p=0.002)"),
        ("Christoffersen:", "p = 0.6383 (Indep. Not Rejected)")
    ]
    y_v = 5.95
    for vp_title, vp_val in var_points:
        ax.text(12.50, y_v, vp_title, ha='left', va='center', fontsize=7.5, fontweight='bold', color=c_dark)
        ax.text(12.50, y_v - 0.16, vp_val, ha='left', va='center', fontsize=7.1, color='#64748B')
        y_v -= 0.35
        
    # Portfolio Return Card
    port_box = patches.FancyBboxPatch((12.35, 0.80), 3.1, 3.10, boxstyle="round,pad=0.08",
                                      facecolor='#F8FAFC', edgecolor=c_accent, linewidth=1.1)
    ax.add_patch(port_box)
    ax.text(13.90, 3.65, "Volatility-Targeting Strategy", ha='center', va='center', fontsize=9.8, fontweight='bold', color=c_accent)
    ax.text(13.90, 3.30, "15% Target Vol, 5 bps Cost (2024–2026):", ha='center', va='center', fontsize=7.4, color='#475569')
    
    port_points = [
        ("HAR-RV-type Strategy:", "+16.09% (CAGR 5.91%, Sh 0.298)", '#1E3A8A'),
        ("SVR-Linear:", "+15.08% (CAGR 5.55%, Sh 0.280)", '#1E3A8A'),
        ("QSVR Strategy:", "+14.10% (CAGR 5.20%, Sh 0.268)", '#6B21A8'),
        ("SVR-RBF Strategy:", "+12.41% (CAGR 4.60%, Sh 0.272)", '#64748B'),
        ("Passive Buy & Hold:", "+20.29% (CAGR 7.37%, Sh 0.172)", '#059669')
    ]
    y_pt = 2.95
    for pt_t, pt_v, pt_c in port_points:
        ax.text(12.50, y_pt, pt_t, ha='left', va='center', fontsize=7.6, fontweight='bold', color=pt_c)
        ax.text(12.50, y_pt - 0.15, pt_v, ha='left', va='center', fontsize=7.0, color='#475569')
        y_pt -= 0.33

    # -------------------------------------------------------------
    # 6. CONNECTING ARROWS BETWEEN PANELS
    # -------------------------------------------------------------
    arrow_props = dict(facecolor=c_secondary, edgecolor='none', width=1.5, headwidth=5.5, headlength=5.0)
    ax.annotate('', xy=(4.15, 4.15), xytext=(3.95, 4.15), arrowprops=arrow_props)
    ax.annotate('', xy=(8.15, 4.15), xytext=(7.95, 4.15), arrowprops=arrow_props)
    ax.annotate('', xy=(12.15, 4.15), xytext=(11.95, 4.15), arrowprops=arrow_props)
    
    # -------------------------------------------------------------
    # 7. FOOTER SUMMARY BAR (Bottom)
    # -------------------------------------------------------------
    footer_box = patches.FancyBboxPatch((0.4, 0.08), 15.2, 0.52, boxstyle="round,pad=0.04",
                                        facecolor=c_dark, edgecolor='none')
    ax.add_patch(footer_box)
    ax.text(8.0, 0.36, "Empirical Synthesis: Linear models (HAR-RV, SVR-Lin) dominate point forecasts | 80% overlap confirmed by persistence baseline (R² = 0.762)",
            ha='center', va='center', fontsize=8.0, fontweight='bold', color='#F8FAFC', fontfamily='sans-serif')
    ax.text(8.0, 0.20, "QSVR matches tuned RBF (DM p = 0.212) but shows no quantum advantage | Pre-test Student-t VaR achieves nominal 5% coverage (p = 0.825)",
            ha='center', va='center', fontsize=7.6, color='#CBD5E1', fontfamily='sans-serif')
    
    plt.tight_layout()
    plt.savefig('figures/graphical_abstract.png', dpi=300, bbox_inches='tight')
    plt.savefig('figures/graphical_abstract.pdf', bbox_inches='tight')
    plt.close()
    print("Graphical abstract successfully generated: figures/graphical_abstract.png and figures/graphical_abstract.pdf")

if __name__ == "__main__":
    create_graphical_abstract()
