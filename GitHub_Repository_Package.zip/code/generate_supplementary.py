import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
import openpyxl
import pandas as pd
import numpy as np
import os

def set_cell_background(cell, fill_hex):
    tcPr = cell._element.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), fill_hex)
    tcPr.append(shd)

def set_cell_margins(cell, top=100, bottom=100, left=140, right=140):
    tcPr = cell._element.get_or_add_tcPr()
    tcMar = OxmlElement('w:tcMar')
    for m, val in [('top', top), ('bottom', bottom), ('left', left), ('right', right)]:
        node = OxmlElement(f'w:{m}')
        node.set(qn('w:w'), str(val))
        node.set(qn('w:type'), 'dxa')
        tcMar.append(node)
    tcPr.append(tcMar)

def add_styled_table(doc, headers, data_rows, caption):
    p_cap = doc.add_paragraph()
    p_cap.paragraph_format.space_before = Pt(12)
    p_cap.paragraph_format.space_after = Pt(4)
    p_cap.paragraph_format.keep_with_next = True
    run_cap = p_cap.add_run(caption)
    run_cap.font.name = 'Calibri'
    run_cap.font.size = Pt(11)
    run_cap.font.bold = True
    run_cap.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D)
    
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    
    hdr_cells = table.rows[0].cells
    for i, h in enumerate(headers):
        cell = hdr_cells[i]
        cell.text = str(h)
        set_cell_background(cell, '1F497D')
        set_cell_margins(cell, top=120, bottom=120, left=140, right=140)
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for r in p.runs:
            r.font.name = 'Calibri'
            r.font.size = Pt(9.5)
            r.font.bold = True
            r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
            
    for row_idx, row_vals in enumerate(data_rows):
        row_cells = table.add_row().cells
        is_even = (row_idx % 2 == 0)
        bg_color = 'F2F5F8' if is_even else 'FFFFFF'
        
        for col_idx, val in enumerate(row_vals):
            cell = row_cells[col_idx]
            set_cell_background(cell, bg_color)
            set_cell_margins(cell, top=80, bottom=80, left=120, right=120)
            
            p = cell.paragraphs[0]
            if isinstance(val, (int, float)):
                if isinstance(val, int) or (isinstance(val, float) and val.is_integer()):
                    txt = f"{int(val):,}"
                elif abs(val) < 0.0001 and val != 0:
                    txt = f"{val:.2e}"
                elif abs(val) < 1.0:
                    txt = f"{val:.4f}"
                elif abs(val) < 100.0:
                    txt = f"{val:.4f}"
                else:
                    txt = f"{val:,.2f}"
                align = WD_ALIGN_PARAGRAPH.RIGHT
            else:
                txt = str(val)
                align = WD_ALIGN_PARAGRAPH.LEFT
                
            cell.text = txt
            p = cell.paragraphs[0]
            p.alignment = align
            for r in p.runs:
                r.font.name = 'Calibri'
                r.font.size = Pt(9.5)

def generate_supplementary_tex():
    # Load all 78 DM tests from statistical_results.xlsx or tables.xlsx
    try:
        df_dm_78 = pd.read_excel("statistical_results.xlsx", sheet_name="All_Pairwise_DM")
    except Exception:
        df_dm_78 = pd.read_excel("tables.xlsx", sheet_name="All_Pairwise_DM_FDR")
        
    dm_latex_rows = []
    for idx, row in df_dm_78.iterrows():
        m1 = str(row['Model A']).replace('_', r'\_')
        m2 = str(row['Model B']).replace('_', r'\_')
        stat = f"{float(row['DM Statistic (HLN)']):.4f}"
        p_raw = f"{float(row['Raw p-value']):.4f}" if float(row['Raw p-value']) >= 0.0001 else f"{float(row['Raw p-value']):.2e}"
        p_fdr = f"{float(row['BH-Adjusted p-value']):.4f}" if float(row['BH-Adjusted p-value']) >= 0.0001 else f"{float(row['BH-Adjusted p-value']):.2e}"
        sig = "Yes" if "Yes" in str(row['Significant at FDR q=0.05']) else "No"
        dm_latex_rows.append(f"{m1} & {m2} & {stat} & {p_raw} & {p_fdr} & {sig} \\\\")
        
    dm_table_latex = "\n".join(dm_latex_rows)

    tex_content = r"""\documentclass[11pt,a4paper]{article}

\usepackage[utf8]{inputenc}
\usepackage[margin=1in]{geometry}
\usepackage{amsmath,amssymb,amsfonts,bm}
\usepackage{booktabs,tabularx,array,multirow,longtable}
\usepackage{graphicx}
\usepackage{float}
\usepackage{setspace}
\usepackage{microtype}
\usepackage{natbib}
\usepackage[colorlinks=true,linkcolor=blue,citecolor=blue,urlcolor=blue]{hyperref}
\usepackage{caption}
\usepackage{subcaption}
\usepackage{authblk}

\onehalfspacing

\title{\textbf{Supplementary Online Appendix:\\Quantum Kernel Methods for Crude Oil Volatility Forecasting under Geopolitical Risk: A Controlled Out-of-Sample Benchmark}}

\author[1]{\textbf{Hamood Amur Al Wardi}\thanks{Email: \href{mailto:omaniconsul@gmail.com}{omaniconsul@gmail.com}; ORCID: \href{https://orcid.org/0009-0006-5697-5159}{0009-0006-5697-5159}}}
\author[2]{\textbf{Uvesh Husain}\thanks{Email: \href{mailto:u78.husain@gmail.com}{u78.husain@gmail.com}; ORCID: \href{https://orcid.org/0000-0002-8502-8488}{0000-0002-8502-8488}}}
\author[3,*]{\textbf{Shylaja H N}\thanks{Corresponding author. Email: \href{mailto:shylaja.hn@manipal.edu}{shylaja.hn@manipal.edu}; ORCID: \href{https://orcid.org/0000-0001-9807-8575}{0000-0001-9807-8575}}}
\author[4]{\textbf{Ram Soorat}\thanks{Email: \href{mailto:rsoorat@gmail.com}{rsoorat@gmail.com}; ORCID: \href{https://orcid.org/0000-0001-7875-9197}{0000-0001-7875-9197}}}
\author[5]{\textbf{Priyanka}\thanks{Email: \href{mailto:priyanka292c@gmail.com}{priyanka292c@gmail.com}; ORCID: \href{https://orcid.org/0009-0008-1520-0706}{0009-0008-1520-0706}}}
\author[6]{\textbf{Afzalur Rahman}\thanks{Email: \href{mailto:afzalur.rahman@woxsen.edu.in}{afzalur.rahman@woxsen.edu.in}; ORCID: \href{https://orcid.org/0000-0002-1561-561X}{0000-0002-1561-561X}}}

\affil[1]{\textit{Economics and Business Studies Department, Mazoon College, Muscat, Sultanate of Oman}}
\affil[2]{\textit{Economics and Business Studies Department, Mazoon College, Muscat, Sultanate of Oman}}
\affil[3]{\textit{Manipal Institute of Commerce Finance and Economics, Manipal Academy of Higher Education, Manipal, India}}
\affil[4]{\textit{School of Technology, Woxsen University, Kamkole, Hyderabad 502345, Telangana, India}}
\affil[5]{\textit{Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India}}
\affil[6]{\textit{School of Business, Woxsen University, Kamkole, Hyderabad 502345, Telangana, India}}

\date{\today}

\begin{document}

\maketitle

\tableofcontents
\newpage

\section*{Overview of Supplementary Material}
This online supplementary document provides comprehensive mathematical derivations, extended econometric proofs, hyperparameter search spaces and selected validation parameters, the complete 78-pairwise Diebold-Mariano matrix with Benjamini-Hochberg FDR adjustments, high-resolution circuit specifications, and detailed computational reproducibility protocols supporting the primary manuscript.

\section{Appendix A: Mathematical Foundations of Quantum Kernel Methods}
\label{app:quantum}

\subsection{Statevector Embedding and Hilbert Space Dimensions}
Consider a normalized classical input vector $\mathbf{x} = [x_1, x_2, x_3, x_4]^\top \in [0, \pi]^4$. The 4-qubit quantum state $|\psi(\mathbf{x})\rangle \in \mathbb{C}^{16}$ is initialized in the computational ground state $|0\rangle^{\otimes 4} = |0000\rangle \in \mathbb{C}^{16}$ and transformed via single-qubit Pauli-Y rotation operators:
\begin{equation}
R_Y(\theta) = \exp\left( -i \frac{\theta}{2} Y \right) = \begin{bmatrix} \cos(\theta/2) & -\sin(\theta/2) \\ \sin(\theta/2) & \cos(\theta/2) \end{bmatrix}, \quad Y = \begin{bmatrix} 0 & -i \\ i & 0 \end{bmatrix}
\end{equation}
The tensor-product state prior to entanglement is given by:
\begin{equation}
|\phi(\mathbf{x})\rangle = \bigotimes_{k=1}^4 R_Y(x_k) |0\rangle = \bigotimes_{k=1}^4 \left( \cos(x_k/2) |0\rangle + \sin(x_k/2) |1\rangle \right)
\end{equation}
The circular CNOT entangling layer $U_{\text{ent}}$ applies four sequential two-qubit Controlled-NOT gates:
\begin{equation}
U_{\text{ent}} = \text{CNOT}_{(3,0)} \text{CNOT}_{(2,3)} \text{CNOT}_{(1,2)} \text{CNOT}_{(0,1)}
\end{equation}
where $\text{CNOT}_{(j, k)} |a_j\rangle |b_k\rangle = |a_j\rangle |a_j \oplus b_k\rangle$. The final encoded pure state is $|\psi(\mathbf{x})\rangle = U_{\text{ent}} |\phi(\mathbf{x})\rangle \in \mathbb{C}^{16}$.

\subsection{Quantum Fidelity Kernel and the $d^2 = 256$ Operator Space}
The quantum transition fidelity between two input vectors $\mathbf{x}_i$ and $\mathbf{x}_j$ is evaluated as:
\begin{equation}
K_Q(\mathbf{x}_i, \mathbf{x}_j) = |\langle\psi(\mathbf{x}_i)|\psi(\mathbf{x}_j)\rangle|^2 = \text{Tr}\left( \rho(\mathbf{x}_i) \rho(\mathbf{x}_j) \right)
\end{equation}
where $\rho(\mathbf{x}) = |\psi(\mathbf{x})\rangle\langle\psi(\mathbf{x})| \in \mathbb{C}^{16 \times 16}$ is the density matrix projection operator. 

\noindent \textbf{Proof of Gram Matrix Rank Capability ($>16$):} \\
Let $\mathcal{H}_d$ be the $d$-dimensional Hilbert space with $d = 2^4 = 16$. The density matrices $\rho(\mathbf{x}) = |\psi(\mathbf{x})\rangle\langle\psi(\mathbf{x})|$ belong to the real vector space $\mathrm{Herm}(\mathcal{H}_d)$ of Hermitian operators, equipped with the Hilbert--Schmidt inner product $\langle A, B \rangle_{\text{HS}} = \mathrm{Tr}(A^\dagger B) = \mathrm{Tr}(AB)$. The vector space dimension of $\mathrm{Herm}(\mathcal{H}_d)$ over $\mathbb{R}$ is:
\begin{equation}
\dim_{\mathbb{R}}(\mathrm{Herm}(\mathcal{H}_d)) = d^2 = 16^2 = 256.
\end{equation}
Consequently, when evaluating the empirical Gram matrix $K_Q \in \mathbb{R}^{N \times N}$ on $N=1,570$ training samples, the rank is bounded by $\text{rank}(K_Q) \le \min(N, d^2) = \min(1570, 256) = 256$. In our empirical estimation, $K_Q$ achieves an effective numerical rank of $67$, exceeding the pure statevector dimension ($16$) while remaining strictly bounded by the 256-dimensional operator space.

\subsection{Kernel-Target Alignment Formulation}
Kernel-Target Alignment $A(K, \mathbf{y})$ evaluates the geometric alignment between a kernel Gram matrix $K$ and the continuous regression-target outer-product matrix $T = \mathbf{y}\mathbf{y}^\top$:
\begin{equation}
A(K, \mathbf{y}) = \frac{\langle K, \mathbf{y}\mathbf{y}^\top \rangle_F}{\|K\|_F \|\mathbf{y}\mathbf{y}^\top\|_F} = \frac{\sum_{i=1}^N \sum_{j=1}^N K_{ij} y_i y_j}{\sqrt{\sum_{i=1}^N \sum_{j=1}^N K_{ij}^2} \cdot \sum_{i=1}^N y_i^2}
\end{equation}
Properties:
\begin{enumerate}
    \item $0 \le A(K, \mathbf{y}) \le 1$ for positive semi-definite kernels.
    \item $A(K, \mathbf{y}) = 1$ if and only if $K \propto \mathbf{y}\mathbf{y}^\top$.
    \item Empirical alignment on crude oil volatility: Linear ($0.4753$), Polynomial ($0.4841$), QSVR ($0.3178$), Gaussian RBF ($0.2658$).
\end{enumerate}

\newpage

\section{Appendix B: Econometric Model Derivations and Leverage Asymmetries}
\label{app:econometrics}

\subsection{GARCH(1,1) with Student-$t$ Innovations}
The parametric GARCH(1,1) model is specified as:
\begin{align}
R_t &= \mu + \varepsilon_t, \quad \varepsilon_t = \sigma_t z_t, \quad z_t \sim t(\nu) \\
\sigma_t^2 &= \omega + \alpha \varepsilon_{t-1}^2 + \beta \sigma_{t-1}^2
\end{align}
Stationarity condition requires $\alpha + \beta < 1$. Under maximum likelihood estimation with Student-$t$ innovations, the log-likelihood function is:
\begin{equation}
\ln L = \sum_{t=1}^T \left[ \ln\Gamma\left(\frac{\nu+1}{2}\right) - \ln\Gamma\left(\frac{\nu}{2}\right) - \frac{1}{2}\ln(\pi(\nu-2)\sigma_t^2) - \frac{\nu+1}{2}\ln\left(1 + \frac{(R_t - \mu)^2}{(\nu-2)\sigma_t^2}\right) \right]
\end{equation}
Empirical estimates: $\hat{\omega} = 0.2222$, $\hat{\alpha} = 0.1063$, $\hat{\beta} = 0.8582$ ($\hat{\alpha}+\hat{\beta} = 0.9645$), and $\hat{\nu} = 5.7887$.

\subsection{EGARCH(1,1) Log-Variance Asymmetry}
\citet{nelson1991conditional} formulated EGARCH to guarantee $\sigma_t^2 > 0$ without non-negativity constraints on parameters:
\begin{equation}
\ln(\sigma_t^2) = \omega + \alpha \left( \left| \frac{\varepsilon_{t-1}}{\sigma_{t-1}} \right| - \sqrt{\frac{2}{\pi}} \right) + \gamma \frac{\varepsilon_{t-1}}{\sigma_{t-1}} + \beta \ln(\sigma_{t-1}^2)
\end{equation}
Empirical estimates: $\hat{\omega} = 0.0519$, $\hat{\alpha} = 0.1995$, $\hat{\gamma} = -0.0433$ ($t = -2.6560, p = 0.0079$), $\hat{\beta} = 0.9745$, and $\hat{\nu} = 5.3648$. The significant negative $\gamma$ coefficient implies a stronger response of log conditional variance to negative standardized innovations than to positive innovations of equal magnitude.

\subsection{GJR-GARCH(1,1) Leverage Effect}
\citet{glosten1993relation} introduced threshold asymmetry:
\begin{equation}
\sigma_t^2 = \omega + \left( \alpha + \gamma \mathbb{I}_{(\varepsilon_{t-1} < 0)} \right) \varepsilon_{t-1}^2 + \beta \sigma_{t-1}^2
\end{equation}
Empirical estimates: $\hat{\omega} = 0.2213$, $\hat{\alpha} = 0.0727$, $\hat{\gamma} = 0.0527$ ($t = 2.2154, p = 0.0267$), $\hat{\beta} = 0.8621$, and $\hat{\nu} = 5.7655$. Because $\hat{\gamma} > 0$, negative shocks exert a total variance impact of $\alpha + \gamma = 0.1254$, compared to $\alpha = 0.0727$ for positive shocks.

\subsection{HAR-Type Multi-Component Autoregression (HAR-RV-Type)}
\citet{corsi2009simple} formalized the Heterogeneous Market Hypothesis. Adapting the multi-horizon structure to the daily-return rolling volatility proxy:
\begin{equation}
\text{Vol}_{t,5} = \beta_0 + \beta_d \text{Vol}_{t-1,5} + \beta_w \text{Vol}_{t-1,5}^{(w)} + \beta_m \text{Vol}_{t-1,5}^{(m)} + \varepsilon_t
\end{equation}
where $\text{Vol}_{t-1,5}^{(w)} = \frac{1}{5}\sum_{i=1}^5 \text{Vol}_{t-i,5}$ and $\text{Vol}_{t-1,5}^{(m)} = \frac{1}{22}\sum_{i=1}^{22} \text{Vol}_{t-i,5}$. 
Empirical estimates: $\hat{\beta}_0 = 0.1056$, $\hat{\beta}_d = 1.0350$ ($t = 11.61, p < 0.0001$), $\hat{\beta}_w = -0.2197$ ($t = -1.70, p = 0.090$), $\hat{\beta}_m = 0.1391$ ($t = 1.70, p = 0.089$). Total persistence $\sum \beta = 0.9544$.

\newpage

\section{Appendix C: Hyperparameter Search Spaces and Selected Validation Parameters}
\label{app:ml_grids}

All classical and quantum machine learning hyperparameters were tuned strictly on the 248-day validation split (2023). Parameters not explicitly included in the search grid were fixed a priori at the reported values (e.g., Random Forest min\_samples\_split = 2, min\_samples\_leaf = 2; XGBoost/LightGBM max\_depth = 3; Adam learning rate = 0.001 for PyTorch LSTM).

\begin{table}[htbp]
\centering
\small
\caption{Hyperparameter Search Spaces and Selected Validation Parameters}
\label{tab:app_ml_grids}
\begin{tabularx}{\textwidth}{lp{4.2cm}p{3.5cm}X}
\toprule
\textbf{Model} & \textbf{Search Grid Range} & \textbf{Validation Criterion} & \textbf{Selected Parameters} \\
\midrule
\textbf{ElasticNet} & $\alpha \in [10^{-4}, 1.0]$, $l_1 \in [0.1, 0.9]$ & Minimal Val MSE & $\alpha = 0.01$, $l_1\text{-ratio} = 0.20$ \\
\textbf{SVR-Linear} & $C \in \{0.1, 1.0, 10.0\}$, $\varepsilon \in \{0.01, 0.05, 0.1\}$ & Minimal Val MSE & $C = 1.0$, $\varepsilon = 0.05$ \\
\textbf{SVR-Poly} & Degree $d \in \{2, 3\}$, $C \in \{0.1, 1.0\}$ & Minimal Val MSE & Degree $d = 2$, $C = 1.0$, $\varepsilon = 0.05$ \\
\textbf{SVR-RBF} & $C \in \{0.1, 1.0, 10.0\}$, $\gamma \in \{\text{'scale'}, \text{'auto'}\}$ & Minimal Val MSE & $C = 1.0$, $\varepsilon = 0.05$, $\gamma = \text{'scale'}$ \\
\textbf{Random Forest} & Trees $\in \{50, 100, 200\}$, Depth $\in \{3, 5, 7\}$ & Minimal Val MSE & 100 trees, max depth = 5, min leaf = 2 \\
\textbf{XGBoost} & Trees $\in \{50, 100, 200\}$, $\eta \in \{0.01, 0.05, 0.1\}$ & Minimal Val MSE & 100 trees, $\eta = 0.05$, max depth = 3 \\
\textbf{LightGBM} & Trees $\in \{50, 100, 200\}$, Leaves $\in \{15, 31, 63\}$ & Minimal Val MSE & 100 trees, lr = 0.05, max depth = 3 \\
\textbf{PyTorch LSTM} & Hidden $H \in \{16, 32, 64\}$, Seq $L \in \{3, 5, 10\}$ & Minimal Val MSE & Seq $L = 5$, Hidden $H = 32$, Adam lr = 0.001 \\
\textbf{QSVR (4-Qubit)} & $C \in \{0.1, 1.0, 10.0\}$, $\varepsilon \in \{0.01, 0.05, 0.1\}$, $\lambda \in \{10^{-7}, 10^{-6}, 10^{-5}, 10^{-4}, 10^{-3}, 10^{-2}\}$ & Minimal Val MSE \& Stability & $C = 1.0$, $\varepsilon = 0.05$, ridge $\lambda = 10^{-5}$ \\
\bottomrule
\end{tabularx}
\end{table}

\newpage

\section{Appendix D: Complete 78-Pairwise Diebold-Mariano Matrix with FDR Adjustments}
\label{app:dm_matrix}

Table \ref{tab:app_dm_full} presents the complete 78 pairwise Diebold-Mariano test statistics (Harvey-Leybourne-Newbold corrected) and Benjamini-Hochberg False Discovery Rate adjusted $p$-values across all 13 models evaluated over the 655-day test set ($13 \times 12 / 2 = 78$ pairwise tests).

\begin{small}
\begin{longtable}{llrrrr}
\caption{Complete 78-Pairwise Diebold-Mariano Test Matrix with Harvey-Leybourne-Newbold Corrections and Benjamini-Hochberg FDR Adjustments} \label{tab:app_dm_full} \\
\toprule
\textbf{Model A} & \textbf{Model B} & \textbf{DM Stat (HLN)} & \textbf{Raw $p$-value} & \textbf{BH-Adjusted $p_{\text{FDR}}$} & \textbf{Significant ($q=0.05$)} \\
\midrule
\endfirsthead
\multicolumn{6}{c}{\textit{Table \thetable{} continued from previous page}} \\
\toprule
\textbf{Model A} & \textbf{Model B} & \textbf{DM Stat (HLN)} & \textbf{Raw $p$-value} & \textbf{BH-Adjusted $p_{\text{FDR}}$} & \textbf{Significant ($q=0.05$)} \\
\midrule
\endhead
\midrule
\multicolumn{6}{r}{\textit{Continued on next page}} \\
\bottomrule
\endfoot
\bottomrule
\endlastfoot
""" + dm_table_latex + r"""
\end{longtable}
\end{small}

\newpage

\section{Appendix E: Data Dictionary and Preprocessing Protocol}
\label{app:data}

\subsection{Variable Dictionary and Sources}
\begin{itemize}
    \item \textbf{WTI Crude Oil Spot Price ($P_t$):} Sourced from the Federal Reserve Bank of St. Louis Economic Data repository (FRED, Series \texttt{DCOILWTICO}). Continuous return calculated via $R_t = 100 \times \ln(P_t^{\text{adj}} / P_{t-1}^{\text{adj}})$.
    \item \textbf{Five-Day Rolling Volatility Proxy ($\text{Vol}_{t, 5}$):} 5-day rolling sample standard deviation of daily percentage returns: $\text{Vol}_{t, 5} = \sqrt{\frac{1}{4}\sum_{k=0}^4 (R_{t-k} - \bar{R}_{t, 5})^2}$.
    \item \textbf{Daily Geopolitical Risk (GPRD):} Newspaper text-search index of geopolitical tensions, military threats, and diplomatic escalations \citep{caldara2022measuring}.
    \item \textbf{AI Geopolitical Risk (AI-GPR):} Automated language model classification index of geopolitical threats and acts constructed via Large Language Models parsing global news archives \citep{iacoviello2026ai}.
    \item \textbf{Oil Geopolitical Risk Subindex (GPR\_OIL):} Text-based geopolitical risk subindex constructed via LLM topic extraction specifically capturing military and political threats to petroleum infrastructure and maritime transit bottlenecks.
    \item \textbf{CBOE Volatility Index (VIX):} Model-free implied volatility of S\&P 500 index options.
    \item \textbf{Gold Futures Returns:} Daily percentage change in COMEX Gold prompt futures contract.
    \item \textbf{US Dollar Index (DXY) Returns:} Daily percentage change in the ICE US Dollar Index.
    \item \textbf{Natural Gas Returns:} Daily percentage change in Henry Hub Natural Gas prompt futures.
    \item \textbf{Brent Crude Spot Returns:} Daily percentage change in Europe Brent spot crude oil prices.
    \item \textbf{U.S. 10-Year Treasury Yield (\^{}TNX):} Daily difference in the 10-Year Treasury note yield ($\Delta\text{TNX}_t$).
\end{itemize}

\subsection{Treatment of April 20, 2020 Negative Price}
On April 20, 2020, prompt NYMEX WTI futures expired at $-\$37.63$/barrel and FRED spot closed at $-\$36.98$/barrel. For the baseline interpolation, the negative April 20, 2020 observation was replaced by the arithmetic mean of the immediately adjacent observations from the identical FRED \texttt{DCOILWTICO} series ($P_{2020-04-17} = \$18.31$/bbl and $P_{2020-04-21} = \$8.91$/bbl), yielding an adjusted computational baseline value of $\$13.61$/bbl ($P_{\text{adj}} = [18.31 + 8.91]/2 = \$13.61$). All values were obtained from the same downloaded primary series without substituting cross-market instruments. The interpolation is strictly a computational transformation required because logarithmic returns are undefined at negative prices; it is not treated as an economically observed price. The robustness checks in Supplementary Table 2 demonstrate that the principal model-performance hierarchy remains stable across exclusion and positive-shifted transformations, although individual performance estimates and breach counts vary slightly.

\subsection{Target Volatility Sensitivity Analysis}
Table 3 reports out-of-sample portfolio performance across alternative target volatility budgets $\sigma_{\text{target}} \in \{10\%, 15\%, 20\%\}$ under the baseline execution parameters (leverage cap $w_{\text{max}} = 2.0$, transaction cost $c = 5$ bps, daily rebalancing). Overall performance remains qualitatively similar across the three target-volatility levels: HAR-RV-type has the highest Sharpe ratio at 10\% and 15\% ($0.367$ and $0.298$), while QSVR attains the highest Sharpe ratio at the 20\% target ($0.261$ vs. $0.252$ for HAR-RV-type) alongside positive cumulative net returns ($+9.23\%, +14.10\%, +18.61\%$).

\begin{table}[htbp]
\centering
\small
\caption{Portfolio Performance Sensitivity Across Target Volatilities (5 bps Cost, 2.0x Leverage, Daily Rebalancing)}
\label{tab:target_vol_sens}
\begin{tabular}{lrrrr}
\toprule
\textbf{Target Volatility ($\sigma_{\text{target}}$)} & \textbf{Leading Model (Sharpe)} & \textbf{Leading Model Return (\%)} & \textbf{QSVR Sharpe} & \textbf{QSVR Return (\%)} \\
\midrule
10\% & HAR-RV-type (0.367) & +13.39\% & 0.269 & +9.23\% \\
15\% (Baseline) & HAR-RV-type (0.298) & +16.09\% & 0.268 & +14.10\% \\
20\% & HAR-RV-type (0.252) / QSVR (0.261) & +17.94\% / +18.61\% & 0.261 & +18.61\% \\
\bottomrule
\end{tabular}
\end{table}

\section{Appendix F: Computational Environment, Reproducibility Protocol, and Statistical Inference}
\label{app:code}
All empirical models, quantum simulations, statistical tests, and visual figures were executed in a documented reproducible Python environment:
\begin{itemize}
    \item \textbf{Deterministic Random Seed Initialization:} All stochastic procedures, train-validation-test chronological data splits, neural network weight initializations, tree ensemble subsampling, and quantum statevector simulations were initialized with a fixed random seed of 42 (applied deterministically across NumPy, PyTorch, Scikit-Learn, and PennyLane's \texttt{default.qubit} simulator) to support deterministic reproduction under the documented software and hardware environment.
    \item \textbf{Language \& Runtime:} Python 3.11.9 (x86\_64) on Windows 11 Enterprise.
    \item \textbf{Quantum Circuit Framework:} PennyLane 0.45.1 with \texttt{default.qubit} statevector simulator.
    \item \textbf{Machine Learning \& Econometrics:} Scikit-Learn 1.4.1, Statsmodels 0.14.1, ARCH 6.3.0, PyTorch 2.2.1+cpu, XGBoost 2.0.3, LightGBM 4.3.0.
    \item \textbf{Data Wrangling \& Visualization:} Pandas 2.2.1, NumPy 1.26.4, OpenPyXL 3.1.2, Matplotlib 3.8.3, Seaborn 0.13.2.
    \item \textbf{Open-Access Repository:} All Python code, circuit files, and data tables are available in the project repository at: \url{https://github.com/rsoorat/Quantum-Oil-GPR-Benchmark}.
\end{itemize}

\subsection{Bootstrap Confidence Interval Protocol}
\label{app:bootstrap}
All out-of-sample empirical confidence intervals reported throughout the manuscript and supplementary material (including regime-specific RMSE intervals in Table 17 of the main manuscript and forecast loss distributions) are computed using a circular block bootstrap with $B = 1,000$ resamples and a fixed block length of $b = 10$ trading days (corresponding to two trading weeks, chosen to capture short-term serial dependence in daily volatility) \citep{politis1992circular, lahiri2003resampling}. The circular block structure preserves temporal dependence, autoregressive persistence, and conditional volatility clustering present in the daily forecast loss differentials $\hat{d}_t = L(\hat{e}_{1,t}) - L(\hat{e}_{2,t})$. In each bootstrap iteration, overlapping circular blocks of length $b$ are drawn with replacement to construct pseudo-series of length $N_{\text{test}} = 655$, from which empirical 95\% percentile confidence intervals $[\hat{\theta}_{0.025}^*, \hat{\theta}_{0.975}^*]$ are derived.

\begin{figure*}[htbp]
\centering
\includegraphics[width=\textwidth]{figures/figure_quantum_circuit.png}
\caption{Detailed 4-Qubit Parameterized Quantum Circuit (PQC) Architecture for Quantum Kernel Regression.}
\label{fig:supp_quantum_circuit}
\end{figure*}

\bibliographystyle{apalike}
\bibliography{references}

\end{document}
"""
    with open("supplementary_material.tex", "w", encoding="utf-8") as f:
        f.write(tex_content)
    print("Supplementary Material LaTeX saved with full 78 DM tests: supplementary_material.tex")

def generate_supplementary_docx():
    doc = docx.Document()
    for section in doc.sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)
        
    p_title = doc.add_paragraph()
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r_t = p_title.add_run("Supplementary Online Appendix:\nQuantum Kernel Methods for Crude Oil Volatility Forecasting under Geopolitical Risk: A Controlled Out-of-Sample Benchmark")
    r_t.font.bold = True
    r_t.font.size = Pt(15)
    r_t.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D)
    
    p_auth = doc.add_paragraph()
    p_auth.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r_a1 = p_auth.add_run("Hamood Amur Al Wardi\n")
    r_a1.font.bold = True
    r_a1.font.size = Pt(11)
    p_auth.add_run("Economics and Business Studies Department, Mazoon College, Muscat, Sultanate of Oman\nEmail: omaniconsul@gmail.com | ORCID: 0009-0006-5697-5159\n\n").font.size = Pt(9.5)
    
    r_a2 = p_auth.add_run("Uvesh Husain\n")
    r_a2.font.bold = True
    r_a2.font.size = Pt(11)
    p_auth.add_run("Economics and Business Studies Department, Mazoon College, Muscat, Sultanate of Oman\nEmail: u78.husain@gmail.com | ORCID: 0000-0002-8502-8488\n\n").font.size = Pt(9.5)
    
    r_a3 = p_auth.add_run("Shylaja H N (Corresponding Author)\n")
    r_a3.font.bold = True
    r_a3.font.size = Pt(11)
    p_auth.add_run("Manipal Institute of Commerce Finance and Economics, Manipal Academy of Higher Education, Manipal, India\nEmail: shylaja.hn@manipal.edu | ORCID: 0000-0001-9807-8575\n\n").font.size = Pt(9.5)
    
    r_a4 = p_auth.add_run("Ram Soorat\n")
    r_a4.font.bold = True
    r_a4.font.size = Pt(11)
    p_auth.add_run("School of Technology, Woxsen University, Kamkole, Hyderabad 502345, Telangana, India\nEmail: rsoorat@gmail.com | ORCID: 0000-0001-7875-9197\n\n").font.size = Pt(9.5)
    
    r_a5 = p_auth.add_run("Priyanka\n")
    r_a5.font.bold = True
    r_a5.font.size = Pt(11)
    p_auth.add_run("Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India\nEmail: priyanka292c@gmail.com | ORCID: 0009-0008-1520-0706\n\n").font.size = Pt(9.5)
    
    r_a6 = p_auth.add_run("Afzalur Rahman\n")
    r_a6.font.bold = True
    r_a6.font.size = Pt(11)
    p_auth.add_run("School of Business, Woxsen University, Kamkole, Hyderabad 502345, Telangana, India\nEmail: afzalur.rahman@woxsen.edu.in | ORCID: 0000-0002-1561-561X\n").font.size = Pt(9.5)
    
    doc.add_page_break()
    
    # Appendix A
    p_a = doc.add_paragraph()
    r = p_a.add_run("Appendix A: Mathematical Foundations of Quantum Kernel Methods")
    r.font.bold = True
    r.font.size = Pt(13)
    r.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D)
    
    p_at = doc.add_paragraph()
    p_at.paragraph_format.line_spacing = 1.15
    p_at.add_run("Consider a normalized classical input vector x = [x1, x2, x3, x4]' in [0, pi]^4. The 4-qubit quantum state |psi(x)> in C^16 is initialized in |0000> and transformed via single-qubit Pauli-Y rotation operators R_Y(theta) = exp(-i theta Y / 2) followed by a circular CNOT entangling chain:\n\n")
    p_at.add_run("|psi(x)> = CNOT_(3,0) CNOT_(2,3) CNOT_(1,2) CNOT_(0,1) ( R_Y(x1) x R_Y(x2) x R_Y(x3) x R_Y(x4) ) |0000>\n\n")
    p_at.add_run("The quantum transition fidelity between two samples is evaluated as K_Q(x_i, x_j) = |<psi(x_i)|psi(x_j)>|^2 = Tr(rho(x_i) rho(x_j)), where rho(x) = |psi(x)><psi(x)| is the density matrix projection operator.\n\n")
    p_at.add_run("Proof of Gram Matrix Rank Capability (> 16):\n").font.bold = True
    p_at.add_run("The density operators rho(x) reside in the space of linear Hermitian operators on C^16 equipped with the Hilbert-Schmidt inner product. The dimension of this operator space is d^2 = 16^2 = 256. Thus, for N = 1,570 training samples, the Gram matrix rank is bounded by min(N, 256) = 256. In our empirical estimation, K_Q achieves an empirical rank of 67, exceeding the single-state vector dimension (16) while remaining strictly bounded by the 256-dimensional operator space.\n")
    
    # Appendix B
    p_b = doc.add_paragraph()
    p_b.paragraph_format.space_before = Pt(14)
    r_b = p_b.add_run("Appendix B: Econometric Model Derivations and Leverage Asymmetries")
    r_b.font.bold = True
    r_b.font.size = Pt(13)
    r_b.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D)
    
    p_bt = doc.add_paragraph()
    p_bt.paragraph_format.line_spacing = 1.15
    p_bt.add_run("1. GARCH(1,1): sigma_t^2 = omega + alpha eps_(t-1)^2 + beta sigma_(t-1)^2 with Student-t errors. Estimates: omega = 0.2222, alpha = 0.1063, beta = 0.8582, nu = 5.7887.\n\n")
    p_bt.add_run("2. EGARCH(1,1): ln(sigma_t^2) = omega + alpha (|z_(t-1)| - E|z|) + gamma z_(t-1) + beta ln(sigma_(t-1)^2). Empirical estimates: omega = 0.0519, alpha = 0.1995, gamma = -0.0433 (t = -2.6560, p = 0.0079), beta = 0.9745, nu = 5.3648. The significant negative gamma coefficient indicates an asymmetric leverage response: negative standardized innovations contribute more strongly to log conditional variance than positive innovations of identical magnitude.\n\n")
    p_bt.add_run("3. GJR-GARCH(1,1): sigma_t^2 = omega + (alpha + gamma I_(eps < 0)) eps_(t-1)^2 + beta sigma_(t-1)^2. Estimates: omega = 0.2213, alpha = 0.0727, gamma = 0.0527 (t = 2.2154, p = 0.0267), beta = 0.8621, nu = 5.7655, confirming significant threshold leverage.\n\n")
    p_bt.add_run("4. HAR-RV-type (Corsi 2009 adaptation): Vol_(t,5) = beta_0 + beta_d Vol_(t-1,5) + beta_w Vol_(t-1,5)^(w) + beta_m Vol_(t-1,5)^(m). Estimates: beta_0 = 0.1056, beta_d = 1.0350 (p < 0.0001), beta_w = -0.2197 (p = 0.090), beta_m = 0.1391 (p = 0.089), total persistence = 0.9544.\n")
    
    # Appendix C
    p_c = doc.add_paragraph()
    p_c.paragraph_format.space_before = Pt(14)
    r_c = p_c.add_run("Appendix C: Hyperparameter Search Spaces and Selected Validation Parameters")
    r_c.font.bold = True
    r_c.font.size = Pt(13)
    r_c.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D)
    
    headers_c = ["Model", "Hyperparameter Search Grid", "Optimal Settings Selected"]
    data_c = [
        ["ElasticNet", "alpha in [1e-4, 1.0], l1 in [0.1, 0.9]", "alpha = 0.01, l1_ratio = 0.20"],
        ["SVR-Linear", "C in {0.1, 1.0, 10.0}, eps in {0.01, 0.05, 0.1}", "C = 1.0, epsilon = 0.05"],
        ["SVR-Poly", "Degree d in {2, 3}, C in {0.1, 1.0}", "Degree d = 2, C = 1.0, epsilon = 0.05"],
        ["SVR-RBF", "C in {0.1, 1.0, 10.0}, gamma in {'scale', 'auto'}", "C = 1.0, epsilon = 0.05, gamma = 'scale'"],
        ["Random Forest", "Trees in {50, 100, 200}, Depth in {3, 5, 7}", "100 trees, depth = 5, min leaf = 2"],
        ["XGBoost", "Trees in {50, 100, 200}, lr in {0.01, 0.05, 0.1}", "100 trees, lr = 0.05, depth = 3"],
        ["LightGBM", "Trees in {50, 100, 200}, Leaves in {15, 31, 63}", "100 trees, lr = 0.05, depth = 3"],
        ["PyTorch LSTM", "Hidden in {16, 32, 64}, Seq in {3, 5, 10}", "Sequence L = 5, Hidden H = 32, 1 layer, Adam lr = 0.001"],
        ["QSVR (4-Qubit)", "C in {0.1, 1.0, 10.0}, eps in {0.01, 0.05, 0.1}, lambda in {1e-7, 1e-6, 1e-5, 1e-4, 1e-3, 1e-2}", "C = 1.0, epsilon = 0.05, ridge lambda = 1e-5"]
    ]
    add_styled_table(doc, headers_c, data_c, "Table A1: Complete Machine Learning Hyperparameter Search Spaces and Selected Parameters")
    
    # Appendix D: Complete 78 DM tests
    p_d = doc.add_paragraph()
    p_d.paragraph_format.space_before = Pt(14)
    r_d = p_d.add_run("Appendix D: Complete 78-Pairwise Diebold-Mariano Test Matrix with FDR Adjustments")
    r_d.font.bold = True
    r_d.font.size = Pt(13)
    r_d.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D)
    
    try:
        df_dm_78 = pd.read_excel("statistical_results.xlsx", sheet_name="All_Pairwise_DM")
    except Exception:
        df_dm_78 = pd.read_excel("tables.xlsx", sheet_name="All_Pairwise_DM_FDR")
        
    headers_d = ["Model A", "Model B", "DM Stat (HLN)", "Raw p-value", "BH-Adjusted p_FDR", "Significant (q=0.05)"]
    data_d = []
    for idx, row in df_dm_78.iterrows():
        m1 = str(row['Model A'])
        m2 = str(row['Model B'])
        stat = float(row['DM Statistic (HLN)'])
        p_raw = float(row['Raw p-value'])
        p_fdr = float(row['BH-Adjusted p-value'])
        sig = "Yes" if "Yes" in str(row['Significant at FDR q=0.05']) else "No"
        data_d.append([m1, m2, stat, p_raw, p_fdr, sig])
        
    add_styled_table(doc, headers_d, data_d, "Table A2: Complete 78-Pairwise Diebold-Mariano Tests with Benjamini-Hochberg FDR Corrections")
    
    # Appendix E & F
    p_e = doc.add_paragraph()
    p_e.paragraph_format.space_before = Pt(14)
    r_e = p_e.add_run("Appendix E & F: Data Sources, Software Environment, and Target Volatility Sensitivity")
    r_e.font.bold = True
    r_e.font.size = Pt(13)
    r_e.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D)
    
    headers_tv = ["Target Volatility", "Leading Model (Sharpe)", "Leading Model Return (%)", "QSVR Sharpe", "QSVR Return (%)"]
    data_tv = [
        ["10%", "HAR-RV-type (0.367)", "+13.39%", "0.269", "+9.23%"],
        ["15% (Baseline)", "HAR-RV-type (0.298)", "+16.09%", "0.268", "+14.10%"],
        ["20%", "HAR-RV-type (0.252) / QSVR (0.261)", "+17.94% / +18.61%", "0.261", "+18.61%"]
    ]
    add_styled_table(doc, headers_tv, data_tv, "Table A3: Target Volatility Sensitivity Analysis (5 bps Cost, 2.0x Leverage, Daily Rebalancing)")
    
    p_et = doc.add_paragraph()
    p_et.paragraph_format.line_spacing = 1.15
    p_et.add_run("Data Sources:\n• FRED Series DCOILWTICO (Cushing WTI Spot Price).\n• Iacoviello GPR Daily Recent and AI-GPR Daily Datasets (www.matteoiacoviello.com).\n• Yahoo Finance Cross-Asset Controls (^VIX, GC=F, DX-Y.NYB, NG=F, BZ=F, ^TNX).\n\n")
    p_et.add_run("Software & Hardware Environment:\n• Python 3.11.9, PennyLane 0.45.1, PyTorch 2.2.1, Scikit-Learn 1.4.1, Statsmodels 0.14.1, ARCH 6.3.0, OpenPyXL 3.1.2.\n• Open-Access GitHub Repository: https://github.com/rsoorat/Quantum-Oil-GPR-Benchmark\n")
    
    doc.save("Supplementary_Material.docx")
    print("Supplementary Material Word doc saved with full 78 DM tests: Supplementary_Material.docx")

def main():
    print("=== Generating Fully Synchronized Supplementary Online Appendix ===")
    generate_supplementary_tex()
    generate_supplementary_docx()

if __name__ == "__main__":
    main()
