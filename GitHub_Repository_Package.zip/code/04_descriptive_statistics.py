import pandas as pd
import numpy as np
import yaml
import statsmodels.api as sm
from statsmodels.stats.diagnostic import het_arch
from scipy.stats import skew, kurtosis, jarque_bera
import openpyxl

def main():
    print("=== Step 4: Descriptive Statistics & Econometric Hypothesis Testing (H1) ===")
    
    # Load configuration
    with open("config.yaml", "r") as f:
        config = yaml.safe_load(f)
        
    dataset_path = config['data']['oil_model_dataset_path']
    df = pd.read_csv(dataset_path)
    df['date'] = pd.to_datetime(df['date'])
    
    # Core variables for descriptive statistics
    core_vars = ['WTI', 'WTI_Return', 'Target_Vol', 'GPRD', 'GPR_AI', 'GPR_OIL', 'VIX']
    
    desc_stats = []
    for var in core_vars:
        series = df[var].dropna()
        n = len(series)
        mean_val = series.mean()
        median_val = series.median()
        std_val = series.std()
        min_val = series.min()
        max_val = series.max()
        skew_val = skew(series)
        kurt_val = kurtosis(series, fisher=False) # Pearson definition (normal = 3)
        jb_stat, jb_p = jarque_bera(series)
        
        desc_stats.append({
            'Variable': var,
            'Mean': mean_val,
            'Median': median_val,
            'Std Dev': std_val,
            'Minimum': min_val,
            'Maximum': max_val,
            'Skewness': skew_val,
            'Kurtosis': kurt_val,
            'Jarque-Bera': jb_stat,
            'JB p-value': jb_p
        })
        
    df_desc = pd.DataFrame(desc_stats)
    print("\n--- Descriptive Statistics (Daily Level) ---")
    print(df_desc.to_string(index=False))
    
    # 2. Engle's ARCH-LM Test for Volatility Clustering on WTI Returns
    lm_stat, lm_pvalue, f_stat, f_pvalue = het_arch(df['WTI_Return'])
    print(f"\n--- Engle's ARCH-LM Test ---")
    print(f"LM Statistic: {lm_stat:.4f}, p-value: {lm_pvalue:.4e}")
    print(f"F-Statistic:  {f_stat:.4f}, p-value: {f_pvalue:.4e}")
    
    # 3. Econometric Regression Test for Hypothesis H1 (GPR -> Volatility with HAC Standard Errors)
    # Target_Vol_t = alpha + beta_AR * Target_Vol_{t-1} + beta_GPR * GPRD_{t-1} + beta_Diff * GPRD_Diff_{t-1} + beta_AI * GPR_AI_{t-1} + gamma * VIX_{t-1} + e_t
    X_h1 = df[['Vol_Lag1', 'GPRD_Lag1', 'GPRD_Diff_Lag1', 'GPR_AI_Lag1', 'VIX_Lag1']]
    X_h1 = sm.add_constant(X_h1)
    y_h1 = df['Target_Vol']
    
    # Estimate OLS with Newey-West HAC standard errors (lag=5)
    model_h1 = sm.OLS(y_h1, X_h1).fit(cov_type='HAC', cov_kwds={'maxlags': 5})
    print("\n--- Econometric Regression for Hypothesis H1 (Newey-West HAC SEs) ---")
    print(model_h1.summary())
    
    # Extract H1 regression table
    h1_results = pd.DataFrame({
        'Regressor': model_h1.params.index,
        'Coefficient': model_h1.params.values,
        'HAC Std Error': model_h1.bse.values,
        't-statistic': model_h1.tvalues.values,
        'p-value': model_h1.pvalues.values
    })
    
    # 4. Correlation Matrix
    corr_cols = ['WTI_Return', 'Target_Vol', 'GPRD', 'GPR_AI', 'VIX', 'Gold_Return_Lag1', 'Dollar_Return_Lag1', 'Brent_Return_Lag1']
    df_corr = df[corr_cols].corr(method='pearson')
    print("\n--- Pearson Correlation Matrix ---")
    print(df_corr.round(4))
    
    # 5. Save to tables.xlsx and statistical_results.xlsx
    try:
        wb = openpyxl.load_workbook("tables.xlsx")
    except FileNotFoundError:
        wb = openpyxl.Workbook()
        if 'Sheet' in wb.sheetnames:
            wb.remove(wb['Sheet'])
    
    if 'DescriptiveStats' in wb.sheetnames:
        wb.remove(wb['DescriptiveStats'])
    ws_desc = wb.create_sheet('DescriptiveStats')
    ws_desc.append(['Variable', 'Mean', 'Median', 'Std Dev', 'Minimum', 'Maximum', 'Skewness', 'Kurtosis', 'Jarque-Bera', 'JB p-value'])
    for idx, row in df_desc.iterrows():
        ws_desc.append(list(row.values))
        
    if 'Correlations' in wb.sheetnames:
        wb.remove(wb['Correlations'])
    ws_corr = wb.create_sheet('Correlations')
    ws_corr.append(['Model / Variable'] + list(df_corr.columns))
    for idx, row in df_corr.iterrows():
        ws_corr.append([idx] + list(row.values))
        
    if 'H1_Regression' in wb.sheetnames:
        wb.remove(wb['H1_Regression'])
    ws_h1 = wb.create_sheet('H1_Regression')
    ws_h1.append(['Regressor', 'Coefficient', 'HAC Std Error', 't-statistic', 'p-value'])
    for idx, row in h1_results.iterrows():
        ws_h1.append(list(row.values))
        
    wb.save("tables.xlsx")
    print("\nDescriptive statistics and H1 econometric regression saved to tables.xlsx.")

if __name__ == "__main__":
    main()
