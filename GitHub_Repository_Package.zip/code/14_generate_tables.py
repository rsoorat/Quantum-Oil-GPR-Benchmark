import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
import yaml

def format_excel_sheet(ws, title_text):
    """
    Applies professional styling to an Excel worksheet.
    """
    # Check if sheet is already formatted to prevent duplicate header insertions
    if ws['A1'].value is not None and str(ws['A1'].value).startswith('Table '):
        return
        
    font_title = Font(name='Segoe UI', size=13, bold=True, color='1F497D')
    font_header = Font(name='Segoe UI', size=10, bold=True, color='FFFFFF')
    font_data = Font(name='Segoe UI', size=10)
    
    fill_header = PatternFill(start_color='1F497D', end_color='1F497D', fill_type='solid')
    fill_zebra = PatternFill(start_color='F2F5F8', end_color='F2F5F8', fill_type='solid')
    
    thin_border = Border(
        left=Side(style='thin', color='D9D9D9'),
        right=Side(style='thin', color='D9D9D9'),
        top=Side(style='thin', color='D9D9D9'),
        bottom=Side(style='thin', color='D9D9D9')
    )
    
    align_center = Alignment(horizontal='center', vertical='center')
    align_left = Alignment(horizontal='left', vertical='center')
    align_right = Alignment(horizontal='right', vertical='center')
    
    # Insert Title Block
    ws.insert_rows(1, 2)
    ws['A1'] = title_text
    ws['A1'].font = font_title
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ws.max_column)
    
    # Format Headers (row 3)
    for col in range(1, ws.max_column + 1):
        cell = ws.cell(row=3, column=col)
        cell.font = font_header
        cell.fill = fill_header
        cell.alignment = align_center
        cell.border = thin_border
        
    # Format Data Rows
    for r in range(4, ws.max_row + 1):
        is_even = (r % 2 == 0)
        for col in range(1, ws.max_column + 1):
            cell = ws.cell(row=r, column=col)
            cell.font = font_data
            cell.border = thin_border
            if is_even:
                cell.fill = fill_zebra
                
            val = cell.value
            if isinstance(val, (int, float)):
                cell.alignment = align_right
                if abs(val) < 1.0:
                    cell.number_format = '0.0000'
                elif abs(val) < 100.0:
                    cell.number_format = '0.0000'
                else:
                    cell.number_format = '#,##0.00'
            else:
                cell.alignment = align_left
                
    # Auto-adjust column widths
    for col in ws.columns:
        max_len = 0
        col_letter = openpyxl.utils.get_column_letter(col[0].column)
        for cell in col:
            val = str(cell.value or '')
            if cell.coordinate in ws.merged_cells:
                continue
            if len(val) > max_len:
                max_len = len(val)
        ws.column_dimensions[col_letter].width = max(max_len + 3, 12)

def main():
    print("=== Step 14: Generate and Format Master Tables ===")
    
    try:
        wb = openpyxl.load_workbook("tables.xlsx")
    except FileNotFoundError:
        wb = openpyxl.Workbook()
        if 'Sheet' in wb.sheetnames:
            wb.remove(wb['Sheet'])
            
    # Table 1: Variables Definitions
    if 'VariableDefinitions' in wb.sheetnames:
        wb.remove(wb['VariableDefinitions'])
    ws_v = wb.create_sheet('VariableDefinitions')
    ws_v.append(['Variable Code', 'Variable Description', 'Data Source', 'API Endpoint / Definition'])
    ws_v.append(['WTI', 'WTI Crude Oil Spot Price (USD/bbl)', 'Federal Reserve Bank of St. Louis Economic Data (FRED)', 'DCOILWTICO'])
    ws_v.append(['WTI_Return', 'Daily log returns of adjusted WTI spot', 'Calculated', '100 * ln(P_t / P_{t-1})'])
    ws_v.append(['Target_Vol', '5-day rolling volatility proxy (sample std dev of daily log returns)', 'Calculated', 'sqrt( 1/4 * sum (R_i - mean(R))^2 )'])
    ws_v.append(['HAR_d, HAR_w, HAR_m', 'HAR daily, weekly (5-day), monthly (22-day) volatility', 'Calculated (Corsi 2009)', 'Multi-horizon rolling means'])
    ws_v.append(['GPRD', 'Daily Geopolitical Risk Index', 'Matteo Iacoviello', 'gpr_files/data_gpr_daily_recent.xls'])
    ws_v.append(['GPR_AI', 'AI-based Geopolitical Risk Index', 'Matteo Iacoviello', 'ai_gpr_files/ai_gpr_data_daily.csv'])
    ws_v.append(['GPR_OIL', 'Oil-Specific AI-GPR Subindex', 'Matteo Iacoviello', 'ai_gpr_files/ai_gpr_data_daily.csv'])
    ws_v.append(['VIX', 'CBOE Equity Volatility Index', 'Yahoo Finance', '^VIX'])
    ws_v.append(['Gold', 'Gold COMEX Futures Return', 'Yahoo Finance', 'GC=F'])
    ws_v.append(['DollarIndex', 'US Dollar Index (DXY) Return', 'Yahoo Finance', 'DX-Y.NYB'])
    ws_v.append(['NaturalGas', 'Natural Gas Futures Return', 'Yahoo Finance', 'NG=F'])
    ws_v.append(['BrentCrude', 'Brent Crude Spot/Futures Return', 'Yahoo Finance', 'BZ=F'])
    ws_v.append(['TreasuryYield', 'U.S. 10-Year Treasury Yield Daily Change', 'Yahoo Finance', '^TNX'])
    
    sheet_titles = {
        'VariableDefinitions': 'Table 1: Variable Definitions and Data Sources',
        'SampleSplits': 'Table 2: Chronological Sample Splitting and Partition Details',
        'DescriptiveStats': 'Table 3: Descriptive Statistics for Core Variables (2016–2026)',
        'Correlations': 'Table 4: Pearson Correlation Matrix',
        'H1_Regression': 'Table 5: Econometric Regression of Realized Volatility on Lagged GPR (Newey-West HAC Errors)',
        'EconometricSummary': 'Table 6: GARCH, EGARCH, GJR-GARCH, and HAR-RV Parameter Estimates',
        'MLConfigs': 'Table 7: Machine Learning Benchmark Hyperparameter Configurations',
        'QuantumConfigs': 'Table 8: Quantum Support Vector Regression Architecture Specification',
        'KernelProperties': 'Table 9: Quantum vs. Classical Kernel Properties & Target Alignment',
        'AblationStudy': 'Table 10: Feature Ablation Study across Predictor Subsets',
        'ModelPerformance': 'Table 11: Out-of-Sample Volatility Forecasting Accuracy Metrics',
        'DM_Test_pvalues': 'Table 12: Pairwise Diebold-Mariano Tests for Out-of-Sample Forecasts (MSE Loss)',
        'RegimeAnalysis': 'Table 13: Out-of-Sample Forecasting RMSE across Geopolitical Risk Regimes',
        'RobustnessTests': 'Table 14: Alternative Geopolitical Risk Percentile Threshold Robustness Checks',
        'RiskManagement': 'Table 15: Value-at-Risk (95%) and Expected Shortfall Coverage Backtesting',
        'PortfolioPerformance': 'Table 16: Economic Significance: Volatility-Targeting Portfolio Performance'
    }
    
    for s_name, title in sheet_titles.items():
        if s_name in wb.sheetnames:
            format_excel_sheet(wb[s_name], title)
            
    wb.save("tables.xlsx")
    print("All master tables formatted and saved to tables.xlsx.")

if __name__ == "__main__":
    main()
