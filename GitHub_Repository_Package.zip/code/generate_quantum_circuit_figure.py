"""
generate_quantum_circuit_figure.py
Generates the 4-qubit PennyLane quantum circuit diagram using matplotlib only.
Removes all Qiskit references — the actual model uses PennyLane default.qubit.
"""
import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch


def generate_pennylane_circuit_diagram(output_path="figures/figure_quantum_circuit.png"):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    fig = plt.figure(figsize=(13.5, 6.8), dpi=300)
    fig.patch.set_facecolor('#ffffff')

    # ── Title ──────────────────────────────────────────────────────────────────
    fig.text(0.5, 0.955,
             "PennyLane 4-Qubit Parameterized Quantum Circuit (PQC) & Quantum Kernel Architecture",
             ha='center', va='center', fontsize=13.5, fontweight='bold', color='#0f172a')
    fig.text(0.5, 0.915,
             r"Hardware-Efficient Feature Map: Pauli-$Y$ Rotations $\rightarrow$ Cyclic CNOT Entanglement "
             r"$\rightarrow$ Fidelity Overlap Kernel",
             ha='center', va='center', fontsize=9.5, fontstyle='italic', color='#475569')

    # ── Left panel: circuit diagram (matplotlib, no Qiskit) ───────────────────
    ax = fig.add_axes([0.03, 0.10, 0.62, 0.78])
    ax.set_xlim(0, 10)
    ax.set_ylim(-0.5, 4.5)
    ax.axis('off')
    ax.set_facecolor('#ffffff')

    wire_y = [3.5, 2.5, 1.5, 0.5]
    wire_labels = [
        r"$q_0$: Vol$_{\mathrm{Lag1}}$",
        r"$q_1$: GPRD$_{\mathrm{Lag1}}$",
        r"$q_2$: VIX$_{\mathrm{Lag1}}$",
        r"$q_3$: Ret$_{\mathrm{Lag1}}$",
    ]
    feature_labels = [r"$x_1 \in [0,\pi]$", r"$x_2 \in [0,\pi]$",
                      r"$x_3 \in [0,\pi]$", r"$x_4 \in [0,\pi]$"]

    # Draw qubit wires
    for i, y in enumerate(wire_y):
        ax.plot([0.8, 9.2], [y, y], color='#1e293b', lw=1.4, zorder=1)
        ax.text(0.0, y, wire_labels[i], ha='left', va='center',
                fontsize=8.5, fontweight='bold', color='#1e293b')
        ax.text(0.8, y + 0.25, feature_labels[i], ha='center', va='bottom',
                fontsize=7.2, color='#64748b', fontstyle='italic')

    # Stage labels
    ax.text(2.5, 4.25, "Stage 1: Angle Embedding", ha='center', va='bottom',
            fontsize=8.5, fontweight='bold', color='#1d4ed8')
    ax.text(6.0, 4.25, "Stage 2: Circular CNOT Entanglement", ha='center', va='bottom',
            fontsize=8.5, fontweight='bold', color='#15803d')

    # ── R_Y gates ─────────────────────────────────────────────────────────────
    ry_x = 2.5
    ry_color = '#2563eb'
    for i, y in enumerate(wire_y):
        rect = FancyBboxPatch((ry_x - 0.38, y - 0.28), 0.76, 0.56,
                               boxstyle="round,pad=0.04", fc=ry_color, ec='#1e40af', lw=1.4, zorder=3)
        ax.add_patch(rect)
        ax.text(ry_x, y, r"$R_Y(x_" + str(i + 1) + r")$",
                ha='center', va='center', fontsize=8.2, fontweight='bold', color='white', zorder=4)

    # Barrier
    ax.plot([3.7, 3.7], [-0.0, 4.0], color='#cbd5e1', lw=1.5, ls='--', zorder=2)

    # ── CNOT gates ────────────────────────────────────────────────────────────
    # CNOT(0→1), CNOT(1→2), CNOT(2→3), CNOT(3→0) [circular]
    cnot_positions = [
        (5.0, wire_y[0], wire_y[1]),   # q0→q1
        (6.2, wire_y[1], wire_y[2]),   # q1→q2
        (7.4, wire_y[2], wire_y[3]),   # q2→q3
        (8.2, wire_y[3], wire_y[0]),   # q3→q0 (circular)
    ]
    control_r = 0.12
    target_r = 0.22
    cx_color = '#15803d'
    for cx, cy_ctrl, cy_tgt in cnot_positions:
        # Control (filled dot)
        ax.plot(cx, cy_ctrl, 'o', ms=control_r * 60, color=cx_color, zorder=4)
        # Vertical line
        ax.plot([cx, cx], [min(cy_ctrl, cy_tgt), max(cy_ctrl, cy_tgt)],
                color=cx_color, lw=1.6, zorder=3)
        # Target (circle + cross)
        circle = plt.Circle((cx, cy_tgt), target_r, fc='white', ec=cx_color, lw=1.6, zorder=4)
        ax.add_patch(circle)
        ax.plot([cx - target_r, cx + target_r], [cy_tgt, cy_tgt], color=cx_color, lw=1.2, zorder=5)
        ax.plot([cx, cx], [cy_tgt - target_r, cy_tgt + target_r], color=cx_color, lw=1.2, zorder=5)

    # Barrier
    ax.plot([8.7, 8.7], [-0.0, 4.0], color='#cbd5e1', lw=1.5, ls='--', zorder=2)

    # Measurement boxes
    for y in wire_y:
        rect = FancyBboxPatch((8.78, y - 0.28), 0.36, 0.56,
                               boxstyle="round,pad=0.04", fc='#fef3c7', ec='#d97706', lw=1.2, zorder=3)
        ax.add_patch(rect)
        ax.text(8.96, y, "M", ha='center', va='center',
                fontsize=7.5, fontweight='bold', color='#92400e', zorder=4)

    # Bottom label
    ax.text(5.0, -0.42,
            r"$K_Q(x_i, x_j) = |\langle 0000| U^\dagger(x_i)\, U(x_j)|0000\rangle|^2$  "
            r"$= Tr[\rho(x_i)\,\rho(x_j)]$",
            ha='center', va='center', fontsize=9.0, fontweight='bold', color='#1d4ed8')

    # Implementation note
    ax.text(5.0, -0.85,
            "Implementation: PennyLane v0.45.1 · default.qubit (Python statevector simulation) · "
            r"4 wires · $\lambda=10^{-5}$ Tikhonov regularization",
            ha='center', va='center', fontsize=7.4, color='#64748b', fontstyle='italic')

    # ── Right panel: math/SVR architecture ────────────────────────────────────
    ax_info = fig.add_axes([0.67, 0.10, 0.31, 0.78])
    ax_info.set_facecolor('#ffffff')
    ax_info.axis('off')

    # Card 1: Fidelity / Operator space
    b1 = FancyBboxPatch((0.02, 0.52), 0.96, 0.46,
                         boxstyle="round,pad=0.04", fc='#fefce8', ec='#facc15', lw=1.5, zorder=2)
    ax_info.add_patch(b1)
    ax_info.text(0.50, 0.93, "Quantum Kernel Geometry", ha='center', va='center',
                 fontsize=10.0, fontweight='bold', color='#854d0e')
    ax_info.text(0.50, 0.83,
                 r"$K_Q(x_i, x_j) = Tr[\rho(x_i)\rho(x_j)]$",
                 ha='center', va='center', fontsize=9.0, fontweight='bold', color='#a16207')
    ax_info.text(0.50, 0.66,
                 r"$\bullet\ d=16$ (complex Hilbert space $C^{16}$)" + "\n" +
                 r"$\bullet\ Herm(H_{16})$: real dim $d^2=256$" + "\n" +
                 r"$\bullet$ Gram rank: 67  ($\lambda_i/\lambda_{max}>10^{-10}$)" + "\n" +
                 r"$\bullet$ KTA: 0.3178 (intermediate)" + "\n" +
                 r"$\bullet$ Eff. dim: 1.6868 (low-complexity)",
                 ha='center', va='center', fontsize=7.8, color='#451a03', linespacing=1.45)

    # Card 2: Dual SVR
    b2 = FancyBboxPatch((0.02, 0.02), 0.96, 0.46,
                         boxstyle="round,pad=0.04", fc='#faf5ff', ec='#c084fc', lw=1.5, zorder=2)
    ax_info.add_patch(b2)
    ax_info.text(0.50, 0.43, "SVR Dual Optimization", ha='center', va='center',
                 fontsize=10.0, fontweight='bold', color='#6b21a8')
    ax_info.text(0.50, 0.33,
                 r"$\tilde{K}_Q = K_Q + 10^{-5} I$  (Tikhonov reg.)",
                 ha='center', va='center', fontsize=8.2, fontstyle='italic', color='#7e22ce')
    ax_info.text(0.50, 0.22,
                 r"$\max_{\alpha}\sum_k\alpha_k - " +
                 r"\frac{1}{2}\alpha^T K_Q \alpha$" + "\n" +
                 r"s.t. $\sum\alpha_k y_k=0,\ 0\leq\alpha_k\leq C$",
                 ha='center', va='center', fontsize=8.0, color='#3b0764', linespacing=1.3)
    ax_info.text(0.50, 0.08,
                 r"$\hat{\sigma}_t = \sum_k \alpha_k^* K_Q(x_k, x_t) + b$",
                 ha='center', va='center', fontsize=8.5, fontweight='bold', color='#581c87')

    plt.savefig(output_path, dpi=300, bbox_inches='tight', facecolor='white')
    plt.close('all')
    print(f"PennyLane quantum circuit diagram generated: {output_path}")


if __name__ == "__main__":
    generate_pennylane_circuit_diagram("figures/figure_quantum_circuit.png")
    generate_pennylane_circuit_diagram("figures/figure_13_quantum_circuit.png")
