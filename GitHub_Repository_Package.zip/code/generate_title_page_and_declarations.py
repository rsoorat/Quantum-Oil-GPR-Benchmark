import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
import subprocess
import os
import shutil

def set_cell_border(cell, **kwargs):
    """
    Set cell borders
    kwargs: top, bottom, left, right
    values: dict(val='single', sz='12', color='000000', space='0')
    """
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcBorders = tcPr.first_child_found_in("w:tcBorders")
    if tcBorders is None:
        tcBorders = OxmlElement('w:tcBorders')
        tcPr.append(tcBorders)
    for edge in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        edge_data = kwargs.get(edge)
        if edge_data:
            tag = 'w:{}'.format(edge)
            element = tcBorders.find(qn(tag))
            if element is None:
                element = OxmlElement(tag)
                tcBorders.append(element)
            for key, val in edge_data.items():
                element.set(qn('w:{}'.format(key)), str(val))

def generate_title_page_docx(filename="Title_Page.docx"):
    doc = docx.Document()
    for section in doc.sections:
        section.top_margin = Inches(0.8)
        section.bottom_margin = Inches(0.8)
        section.left_margin = Inches(0.9)
        section.right_margin = Inches(0.9)
        
    # Title
    p_title = doc.add_paragraph()
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_title.paragraph_format.space_before = Pt(6)
    p_title.paragraph_format.space_after = Pt(14)
    p_title.paragraph_format.line_spacing = 1.15
    r_title = p_title.add_run("Quantum Kernel Methods for Crude Oil Volatility Forecasting under Geopolitical Risk: A Controlled Out-of-Sample Benchmark")
    r_title.font.name = 'Calibri'
    r_title.font.size = Pt(18)
    r_title.font.bold = True
    r_title.font.color.rgb = RGBColor(0x00, 0x20, 0x60) # Deep Navy

    # Running Title
    p_run = doc.add_paragraph()
    p_run.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_run.paragraph_format.space_after = Pt(18)
    r_run = p_run.add_run("Running Title: Quantum Kernel Crude Oil Volatility Forecasting")
    r_run.font.name = 'Calibri'
    r_run.font.size = Pt(10.5)
    r_run.font.italic = True
    r_run.font.color.rgb = RGBColor(0x55, 0x55, 0x55)

    # Authors
    p_auth = doc.add_paragraph()
    p_auth.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_auth.paragraph_format.space_after = Pt(12)
    p_auth.paragraph_format.line_spacing = 1.2
    
    authors = [
        ("Hamood Amur Al Wardi", "1", "0009-0006-5697-5159"),
        ("Uvesh Husain", "1", "0000-0002-8502-8488"),
        ("Shylaja H N", "2,*", "0000-0001-9807-8575"),
        ("Ram Soorat", "3", "0000-0001-7875-9197"),
        ("Priyanka", "4", "0009-0008-1520-0706"),
        ("Afzalur Rahman", "5", "0000-0002-1561-561X")
    ]
    
    for i, (name, affil, orcid) in enumerate(authors):
        r_name = p_auth.add_run(name)
        r_name.font.name = 'Calibri'
        r_name.font.size = Pt(11.5)
        r_name.font.bold = True
        
        r_aff = p_auth.add_run(f" {affil}")
        r_aff.font.name = 'Calibri'
        r_aff.font.size = Pt(8.5)
        r_aff.font.superscript = True
        
        if i < len(authors) - 1:
            r_sep = p_auth.add_run(",   ")
            r_sep.font.name = 'Calibri'
            r_sep.font.size = Pt(11)

    # Affiliations
    affiliations = [
        ("1", "Economics and Business Studies Department, Mazoon College, Airport Heights - Seeb, P.O. Box 101, Muscat, P.C. 133, Sultanate of Oman"),
        ("2", "Manipal Institute of Commerce Finance and Economics, Manipal Academy of Higher Education, Madhav Nagar, Manipal, Karnataka 576104, India"),
        ("3", "School of Technology, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad 502345, Telangana, India"),
        ("4", "Department of Physics and Astrophysics, University of Delhi, North Campus, Delhi 110007, India"),
        ("5", "School of Business, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad 502345, Telangana, India")
    ]
    
    p_aff = doc.add_paragraph()
    p_aff.paragraph_format.space_before = Pt(6)
    p_aff.paragraph_format.space_after = Pt(14)
    p_aff.paragraph_format.line_spacing = 1.15
    
    for num, text in affiliations:
        r_num = p_aff.add_run(f"{num} ")
        r_num.font.name = 'Calibri'
        r_num.font.size = Pt(8)
        r_num.font.superscript = True
        
        r_txt = p_aff.add_run(f"{text}\n")
        r_txt.font.name = 'Calibri'
        r_txt.font.size = Pt(9.5)
        r_txt.font.italic = True
        r_txt.font.color.rgb = RGBColor(0x33, 0x33, 0x33)

    # Corresponding Author Box
    p_cor = doc.add_paragraph()
    p_cor.paragraph_format.space_before = Pt(8)
    p_cor.paragraph_format.space_after = Pt(14)
    p_cor.paragraph_format.line_spacing = 1.15
    
    r_cor_hdr = p_cor.add_run("* Corresponding Author:\n")
    r_cor_hdr.font.name = 'Calibri'
    r_cor_hdr.font.size = Pt(10.5)
    r_cor_hdr.font.bold = True
    r_cor_hdr.font.color.rgb = RGBColor(0x00, 0x20, 0x60)
    
    cor_details = (
        "Shylaja H N\n"
        "Manipal Institute of Commerce Finance and Economics\n"
        "Manipal Academy of Higher Education\n"
        "Madhav Nagar, Manipal, Karnataka 576104, India\n"
        "Email: shylaja.hn@manipal.edu | ORCID: 0000-0001-9807-8575\n"
    )
    r_cor_txt = p_cor.add_run(cor_details)
    r_cor_txt.font.name = 'Calibri'
    r_cor_txt.font.size = Pt(9.5)

    # Author Emails & ORCIDs Table
    p_emails = doc.add_paragraph()
    p_emails.paragraph_format.space_before = Pt(4)
    p_emails.paragraph_format.space_after = Pt(12)
    p_emails.paragraph_format.line_spacing = 1.15
    
    r_em_hdr = p_emails.add_run("Author Contact Information & Identifiers:\n")
    r_em_hdr.font.name = 'Calibri'
    r_em_hdr.font.size = Pt(10)
    r_em_hdr.font.bold = True
    
    em_data = (
        "• Hamood Amur Al Wardi: omaniconsul@gmail.com | ORCID: 0009-0006-5697-5159\n"
        "• Uvesh Husain: u78.husain@gmail.com | ORCID: 0000-0002-8502-8488\n"
        "• Shylaja H N (Corresponding): shylaja.hn@manipal.edu | ORCID: 0000-0001-9807-8575\n"
        "• Ram Soorat: rsoorat@gmail.com | ORCID: 0000-0001-7875-9197\n"
        "• Priyanka: priyanka292c@gmail.com | ORCID: 0009-0008-1520-0706\n"
        "• Afzalur Rahman: afzalur.rahman@woxsen.edu.in | ORCID: 0000-0002-1561-561X\n"
    )
    r_em_txt = p_emails.add_run(em_data)
    r_em_txt.font.name = 'Calibri'
    r_em_txt.font.size = Pt(9.0)
    r_em_txt.font.color.rgb = RGBColor(0x44, 0x44, 0x44)

    # Divider
    p_div = doc.add_paragraph()
    p_div.paragraph_format.space_before = Pt(4)
    p_div.paragraph_format.space_after = Pt(8)
    r_div = p_div.add_run("_________________________________________________________________________________")
    r_div.font.color.rgb = RGBColor(0xAA, 0xAA, 0xAA)
    r_div.font.size = Pt(8)

    # Target Journal & Article Type
    p_meta = doc.add_paragraph()
    p_meta.paragraph_format.space_before = Pt(6)
    p_meta.paragraph_format.space_after = Pt(10)
    p_meta.paragraph_format.line_spacing = 1.15
    
    r_meta_t = p_meta.add_run("Submission Details:\n")
    r_meta_t.font.name = 'Calibri'
    r_meta_t.font.size = Pt(10)
    r_meta_t.font.bold = True
    
    meta_info = (
        "• Target Journal: Journal of Commodity Markets (Elsevier, ISSN: 2405-8513)\n"
        "• Article Type: Full Length Article / Original Research Article\n"
        "• Manuscript Length: ~11,000 words (Main text) | 22 Tables | 9 Figures\n"
        "• Data Repository: https://github.com/rsoorat/Quantum-Oil-GPR-Benchmark\n"
    )
    r_meta_val = p_meta.add_run(meta_info)
    r_meta_val.font.name = 'Calibri'
    r_meta_val.font.size = Pt(9.5)

    # Keywords & JEL
    p_kw = doc.add_paragraph()
    p_kw.paragraph_format.space_before = Pt(6)
    p_kw.paragraph_format.space_after = Pt(6)
    p_kw.paragraph_format.line_spacing = 1.15
    
    r_kw_h = p_kw.add_run("Keywords: ")
    r_kw_h.font.bold = True
    r_kw_h.font.size = Pt(9.5)
    r_kw_v = p_kw.add_run("Crude Oil Volatility; Rolling Volatility; Geopolitical Risk; Quantum Machine Learning; Quantum Kernel Regression; HAR-RV-type; Value-at-Risk; Kupiec Test; Christoffersen Test; Forecast Evaluation.\n")
    r_kw_v.font.size = Pt(9.5)

    r_jel_h = p_kw.add_run("JEL Classification: ")
    r_jel_h.font.bold = True
    r_jel_h.font.size = Pt(9.5)
    r_jel_v = p_kw.add_run("C22; C53; C58; G17; Q41; Q47.\n")
    r_jel_v.font.size = Pt(9.5)

    # Funding & Acknowledgments
    p_fund = doc.add_paragraph()
    p_fund.paragraph_format.space_before = Pt(8)
    p_fund.paragraph_format.space_after = Pt(4)
    p_fund.paragraph_format.line_spacing = 1.15
    
    r_fund_h = p_fund.add_run("Funding Statement: ")
    r_fund_h.font.bold = True
    r_fund_h.font.size = Pt(9.5)
    r_fund_v = p_fund.add_run("This research received no specific grant from any funding agency in the public, commercial, or not-for-profit sectors.\n")
    r_fund_v.font.size = Pt(9.5)

    r_coi_h = p_fund.add_run("Declaration of Competing Interest: ")
    r_coi_h.font.bold = True
    r_coi_h.font.size = Pt(9.5)
    r_coi_v = p_fund.add_run("The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.\n")
    r_coi_v.font.size = Pt(9.5)

    doc.save(filename)
    print(f"Title Page DOCX generated: {filename}")


def generate_title_page_tex(filename="Title_Page.tex"):
    tex_content = r"""\documentclass[11pt,a4paper]{article}
\usepackage[top=0.8in,bottom=0.8in,left=0.85in,right=0.85in]{geometry}
\usepackage{amsmath,amssymb}
\usepackage{charter}
\usepackage{xurl}
\usepackage[colorlinks=true,linkcolor=blue,citecolor=blue,urlcolor=blue]{hyperref}
\usepackage{microtype}
\usepackage{setspace}
\usepackage{authblk}

\onehalfspacing

\title{\textbf{\Large Quantum Kernel Methods for Crude Oil Volatility Forecasting under Geopolitical Risk: A Controlled Out-of-Sample Benchmark}\\[0.3em]
\normalsize \textit{Running Title: Quantum Kernel Crude Oil Volatility Forecasting}}

\author[1]{\textbf{Hamood Amur Al Wardi}\thanks{Email: \href{mailto:omaniconsul@gmail.com}{omaniconsul@gmail.com}; ORCID: \href{https://orcid.org/0009-0006-5697-5159}{0009-0006-5697-5159}}}
\author[1]{\textbf{Uvesh Husain}\thanks{Email: \href{mailto:u78.husain@gmail.com}{u78.husain@gmail.com}; ORCID: \href{https://orcid.org/0000-0002-8502-8488}{0000-0002-8502-8488}}}
\author[2,*]{\textbf{Shylaja H N}\thanks{Corresponding author. Email: \href{mailto:shylaja.hn@manipal.edu}{shylaja.hn@manipal.edu}; ORCID: \href{https://orcid.org/0000-0001-9807-8575}{0000-0001-9807-8575}}}
\author[3]{\textbf{Ram Soorat}\thanks{Email: \href{mailto:rsoorat@gmail.com}{rsoorat@gmail.com}; ORCID: \href{https://orcid.org/0000-0001-7875-9197}{0000-0001-7875-9197}}}
\author[4]{\textbf{Priyanka}\thanks{Email: \href{mailto:priyanka292c@gmail.com}{priyanka292c@gmail.com}; ORCID: \href{https://orcid.org/0009-0008-1520-0706}{0009-0008-1520-0706}}}
\author[5]{\textbf{Afzalur Rahman}\thanks{Email: \href{mailto:afzalur.rahman@woxsen.edu.in}{afzalur.rahman@woxsen.edu.in}; ORCID: \href{https://orcid.org/0000-0002-1561-561X}{0000-0002-1561-561X}}}

\affil[1]{\small \textit{Economics and Business Studies Department, Mazoon College, Airport Heights - Seeb, P.O. Box 101, Muscat, P.C. 133, Sultanate of Oman}}
\affil[2]{\small \textit{Manipal Institute of Commerce Finance and Economics, Manipal Academy of Higher Education, Madhav Nagar, Manipal, Karnataka 576104, India}}
\affil[3]{\small \textit{School of Technology, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad 502345, Telangana, India}}
\affil[4]{\small \textit{Department of Physics and Astrophysics, University of Delhi, North Campus, Delhi 110007, India}}
\affil[5]{\small \textit{School of Business, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad 502345, Telangana, India}}

\date{\today}

\begin{document}

\maketitle

\vspace{-0.5em}
\hrule
\vspace{0.8em}

\noindent \textbf{* Corresponding Author Information:}\\
\textbf{Shylaja H N}\\
Manipal Institute of Commerce Finance and Economics, Manipal Academy of Higher Education\\
Madhav Nagar, Manipal, Karnataka 576104, India\\
Email: \href{mailto:shylaja.hn@manipal.edu}{shylaja.hn@manipal.edu} $|$ ORCID: \href{https://orcid.org/0000-0001-9807-8575}{0000-0001-9807-8575}

\vspace{0.8em}
\noindent \textbf{Submission Metadata:}\\
\begin{itemize}\itemsep=0.15em \parsep=0pt \topsep=0.2em \partopsep=0pt
    \item \textbf{Target Journal:} \textit{Journal of Commodity Markets} (Elsevier, ISSN: 2405-8513)
    \item \textbf{Article Type:} Full Length Article / Original Research Article
    \item \textbf{Manuscript Scope:} $\sim$11,000 words (Main text) $|$ 22 Tables $|$ 9 Figures
    \item \textbf{Data \& Code Availability:} \url{https://github.com/rsoorat/Quantum-Oil-GPR-Benchmark}
\end{itemize}

\vspace{0.6em}
\noindent \textbf{Keywords:} Crude Oil Volatility, Rolling Volatility, Geopolitical Risk, Quantum Machine Learning, Quantum Kernel Regression, HAR-RV-type, Value-at-Risk, Kupiec Test, Christoffersen Test, Forecast Evaluation.

\vspace{0.6em}
\noindent \textbf{JEL Classification:} C22, C53, C58, G17, Q41, Q47.

\vspace{0.8em}
\hrule
\vspace{0.8em}

\noindent \textbf{Declaration of Funding:}\\
This research received no specific grant from any funding agency in the public, commercial, or not-for-profit sectors.

\vspace{0.6em}
\noindent \textbf{Declaration of Competing Interest:}\\
The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

\vspace{0.6em}
\noindent \textbf{Declaration of Generative AI in the Writing Process:}\\
During the preparation of this work, the authors used Anthropic Claude and Google DeepMind AI tools in order to assist with code optimization, data processing, and manuscript editing for clarity and formatting. After using these tools, the authors reviewed and edited the content as needed and take full responsibility for the content of the published article.

\end{document}
"""
    with open(filename, "w", encoding="utf-8") as f:
        f.write(tex_content)
    print(f"Title Page TeX generated: {filename}")


def generate_declaration_of_interest_docx(filename="Declaration_of_Interest.docx"):
    doc = docx.Document()
    for section in doc.sections:
        section.top_margin = Inches(0.9)
        section.bottom_margin = Inches(0.9)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)
        
    # Elsevier Header / Heading
    p_hd = doc.add_paragraph()
    p_hd.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_hd.paragraph_format.space_before = Pt(8)
    p_hd.paragraph_format.space_after = Pt(4)
    r_hd = p_hd.add_run("Declaration of Competing Interest / Declaration of Interest Statement")
    r_hd.font.name = 'Calibri'
    r_hd.font.size = Pt(16)
    r_hd.font.bold = True
    r_hd.font.color.rgb = RGBColor(0x00, 0x20, 0x60)

    # Sub-heading
    p_sub = doc.add_paragraph()
    p_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_sub.paragraph_format.space_after = Pt(20)
    r_sub = p_sub.add_run("Submission to: Journal of Commodity Markets (Elsevier, ISSN: 2405-8513)")
    r_sub.font.name = 'Calibri'
    r_sub.font.size = Pt(10.5)
    r_sub.font.italic = True
    r_sub.font.color.rgb = RGBColor(0x55, 0x55, 0x55)

    # Manuscript Details
    p_man = doc.add_paragraph()
    p_man.paragraph_format.space_after = Pt(14)
    p_man.paragraph_format.line_spacing = 1.2
    
    r_m1 = p_man.add_run("Manuscript Title:\n")
    r_m1.font.name = 'Calibri'
    r_m1.font.bold = True
    r_m1.font.size = Pt(11)
    
    r_m2 = p_man.add_run("“Quantum Kernel Methods for Crude Oil Volatility Forecasting under Geopolitical Risk: A Controlled Out-of-Sample Benchmark”\n\n")
    r_m2.font.name = 'Calibri'
    r_m2.font.size = Pt(11)
    r_m2.font.color.rgb = RGBColor(0x00, 0x20, 0x60)

    r_a1 = p_man.add_run("Authors:\n")
    r_a1.font.name = 'Calibri'
    r_a1.font.bold = True
    r_a1.font.size = Pt(11)

    r_a2 = p_man.add_run(
        "1. Hamood Amur Al Wardi (Mazoon College, Muscat, Sultanate of Oman)\n"
        "2. Uvesh Husain (Mazoon College, Muscat, Sultanate of Oman)\n"
        "3. Shylaja H N (Corresponding Author, Manipal Academy of Higher Education, Manipal, India)\n"
        "4. Ram Soorat (Woxsen University, Hyderabad, India)\n"
        "5. Priyanka (University of Delhi, Delhi, India)\n"
        "6. Afzalur Rahman (Woxsen University, Hyderabad, India)\n"
    )
    r_a2.font.name = 'Calibri'
    r_a2.font.size = Pt(10)

    # Divider
    p_div = doc.add_paragraph()
    p_div.paragraph_format.space_before = Pt(6)
    p_div.paragraph_format.space_after = Pt(14)
    r_div = p_div.add_run("_________________________________________________________________________________")
    r_div.font.color.rgb = RGBColor(0xAA, 0xAA, 0xAA)
    r_div.font.size = Pt(8)

    # Formal Elsevier Statement Box
    p_decl = doc.add_paragraph()
    p_decl.paragraph_format.space_before = Pt(8)
    p_decl.paragraph_format.space_after = Pt(16)
    p_decl.paragraph_format.line_spacing = 1.3
    
    r_box_h = p_decl.add_run("Declaration:\n")
    r_box_h.font.name = 'Calibri'
    r_box_h.font.size = Pt(12)
    r_box_h.font.bold = True
    r_box_h.font.color.rgb = RGBColor(0x00, 0x20, 0x60)
    
    r_box_txt = p_decl.add_run(
        "The authors declare that they have no known competing financial interests or personal relationships "
        "that could have appeared to influence the work reported in this paper.\n\n"
        "No funding was received from any public, private, commercial, or non-profit entity for the design, execution, "
        "analysis, interpretation, or writing of this study. All authors have reviewed and approved the submission of "
        "the manuscript to the Journal of Commodity Markets and confirm that no conflicts of interest exist."
    )
    r_box_txt.font.name = 'Calibri'
    r_box_txt.font.size = Pt(11)

    # AI Declaration
    p_ai = doc.add_paragraph()
    p_ai.paragraph_format.space_before = Pt(6)
    p_ai.paragraph_format.space_after = Pt(18)
    p_ai.paragraph_format.line_spacing = 1.2
    
    r_ai_h = p_ai.add_run("Declaration of Generative AI and AI-Assisted Technologies in the Writing Process:\n")
    r_ai_h.font.name = 'Calibri'
    r_ai_h.font.size = Pt(10.5)
    r_ai_h.font.bold = True
    
    r_ai_txt = p_ai.add_run(
        "During the preparation of this work, the authors used Anthropic Claude and Google DeepMind AI tools in order "
        "to assist with code optimization, data processing, and manuscript editing for clarity and formatting. "
        "After using these tools, the authors reviewed and edited the content as needed and take full responsibility "
        "for the content of the published article."
    )
    r_ai_txt.font.name = 'Calibri'
    r_ai_txt.font.size = Pt(10)
    r_ai_txt.font.color.rgb = RGBColor(0x33, 0x33, 0x33)

    # Signature
    p_sig = doc.add_paragraph()
    p_sig.paragraph_format.space_before = Pt(16)
    p_sig.paragraph_format.line_spacing = 1.15
    
    r_sig = p_sig.add_run(
        "Confirmed and signed on behalf of all co-authors:\n\n"
        "Shylaja H N (Corresponding Author)\n"
        "Manipal Institute of Commerce Finance and Economics\n"
        "Manipal Academy of Higher Education, Manipal, Karnataka 576104, India\n"
        "Email: shylaja.hn@manipal.edu\n"
        "Date: September 10, 2026"
    )
    r_sig.font.name = 'Calibri'
    r_sig.font.size = Pt(10)
    r_sig.font.bold = True

    doc.save(filename)
    print(f"Declaration of Interest DOCX generated: {filename}")


def generate_declaration_of_interest_tex(filename="Declaration_of_Interest.tex"):
    tex_content = r"""\documentclass[11pt,a4paper]{article}
\usepackage[top=1.0in,bottom=1.0in,left=1.0in,right=1.0in]{geometry}
\usepackage{charter}
\usepackage{xurl}
\usepackage[colorlinks=true,linkcolor=blue,citecolor=blue,urlcolor=blue]{hyperref}
\usepackage{microtype}
\usepackage{setspace}

\onehalfspacing

\begin{document}

\begin{center}
{\Large \textbf{Declaration of Competing Interest / Declaration of Interest Statement}}\\[0.4em]
{\normalsize \textit{Submission to: Journal of Commodity Markets (Elsevier, ISSN: 2405-8513)}}
\end{center}

\vspace{1.0em}
\noindent \textbf{Manuscript Title:}\\
``Quantum Kernel Methods for Crude Oil Volatility Forecasting under Geopolitical Risk: A Controlled Out-of-Sample Benchmark''

\vspace{0.8em}
\noindent \textbf{Authors:}\\
1. Hamood Amur Al Wardi (Mazoon College, Muscat, Sultanate of Oman)\\
2. Uvesh Husain (Mazoon College, Muscat, Sultanate of Oman)\\
3. Shylaja H N (Corresponding Author, Manipal Academy of Higher Education, Manipal, India)\\
4. Ram Soorat (Woxsen University, Hyderabad, India)\\
5. Priyanka (University of Delhi, Delhi, India)\\
6. Afzalur Rahman (Woxsen University, Hyderabad, India)

\vspace{1.0em}
\hrule
\vspace{1.2em}

\noindent \textbf{\large Declaration:}\\[0.5em]
The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.

\vspace{0.8em}
\noindent No funding was received from any public, private, commercial, or non-profit entity for the design, execution, analysis, interpretation, or writing of this study. All authors have reviewed and approved the submission of the manuscript to the \textit{Journal of Commodity Markets} and confirm that no conflicts of interest exist.

\vspace{1.2em}
\noindent \textbf{Declaration of Generative AI and AI-Assisted Technologies in the Writing Process:}\\[0.4em]
During the preparation of this work, the authors used Anthropic Claude and Google DeepMind AI tools in order to assist with code optimization, data processing, and manuscript editing for clarity and formatting. After using these tools, the authors reviewed and edited the content as needed and take full responsibility for the content of the published article.

\vspace{2.0em}
\noindent \textbf{Confirmed and signed on behalf of all co-authors:}\\[0.8em]
\textbf{Shylaja H N} (Corresponding Author)\\
Manipal Institute of Commerce Finance and Economics\\
Manipal Academy of Higher Education, Manipal, Karnataka 576104, India\\
Email: \href{mailto:shylaja.hn@manipal.edu}{shylaja.hn@manipal.edu}\\
Date: September 10, 2026

\end{document}
"""
    with open(filename, "w", encoding="utf-8") as f:
        f.write(tex_content)
    print(f"Declaration of Interest TeX generated: {filename}")


def compile_tex(tex_filename, pdf_filename):
    print(f"Compiling {tex_filename} with pdflatex...")
    cmd = ["pdflatex", "-interaction=nonstopmode", tex_filename]
    res = subprocess.run(cmd, capture_output=True, text=True)
    if os.path.exists(pdf_filename):
        print(f"Successfully compiled: {pdf_filename}")
    else:
        print(f"Compilation warning/error for {pdf_filename}:\n", res.stderr or res.stdout[:500])


def main():
    script_dir = os.path.dirname(os.path.abspath(__file__))
    paper1_dir = os.path.abspath(os.path.join(script_dir, ".."))
    base_dir = os.path.abspath(os.path.join(paper1_dir, ".."))
    
    # 1. Generate DOCX and TeX in Paper1
    os.chdir(paper1_dir)
    generate_title_page_docx("Title_Page.docx")
    generate_title_page_tex("Title_Page.tex")
    compile_tex("Title_Page.tex", "Title_Page.pdf")
    
    generate_declaration_of_interest_docx("Declaration_of_Interest.docx")
    generate_declaration_of_interest_tex("Declaration_of_Interest.tex")
    compile_tex("Declaration_of_Interest.tex", "Declaration_of_Interest.pdf")
    
    # 2. Copy files to base_dir as well
    for fname in ["Title_Page.docx", "Title_Page.pdf", "Title_Page.tex",
                  "Declaration_of_Interest.docx", "Declaration_of_Interest.pdf", "Declaration_of_Interest.tex"]:
        src = os.path.join(paper1_dir, fname)
        dst = os.path.join(base_dir, fname)
        if os.path.exists(src):
            shutil.copy2(src, dst)
            print(f"Copied {fname} to root directory.")

if __name__ == "__main__":
    main()
