import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
import subprocess
import os

def generate_cover_letter_tex():
    tex_content = r"""\documentclass[10pt,a4paper]{article}
\usepackage[top=0.45in,bottom=0.45in,left=0.65in,right=0.65in]{geometry}
\usepackage{amsmath}
\usepackage{charter}
\usepackage{xurl}
\usepackage[colorlinks=true,linkcolor=blue,citecolor=blue,urlcolor=blue]{hyperref}
\usepackage{microtype}
\usepackage{setspace}

\singlespacing

\begin{document}

\noindent \textbf{Corresponding Author:} \textbf{Shylaja H N} (\href{mailto:shylaja.hn@manipal.edu}{shylaja.hn@manipal.edu}; ORCID: \href{https://orcid.org/0000-0001-9807-8575}{0000-0001-9807-8575}) --- Manipal Institute of Commerce Finance and Economics, Manipal Academy of Higher Education, Manipal, India \\[0.15em]
\noindent \textbf{All Authors (in Manuscript Order):} \\
1. \textbf{Hamood Amur Al Wardi} (Mazoon College, Oman; \href{mailto:omaniconsul@gmail.com}{omaniconsul@gmail.com}; ORCID: \href{https://orcid.org/0009-0006-5697-5159}{0009-0006-5697-5159}) \quad
2. \textbf{Uvesh Husain} (Mazoon College, Oman; \href{mailto:u78.husain@gmail.com}{u78.husain@gmail.com}; ORCID: \href{https://orcid.org/0000-0002-8502-8488}{0000-0002-8502-8488}) \\
3. \textbf{Shylaja H N}* (Corresponding Author, Manipal Academy of Higher Education, India; \href{mailto:shylaja.hn@manipal.edu}{shylaja.hn@manipal.edu}; ORCID: \href{https://orcid.org/0000-0001-9807-8575}{0000-0001-9807-8575}) \quad
4. \textbf{Ram Soorat} (Woxsen University, India; \href{mailto:rsoorat@gmail.com}{rsoorat@gmail.com}; ORCID: \href{https://orcid.org/0000-0001-7875-9197}{0000-0001-7875-9197}) \\
5. \textbf{Priyanka} (University of Delhi, India; \href{mailto:priyanka292c@gmail.com}{priyanka292c@gmail.com}; ORCID: \href{https://orcid.org/0009-0008-1520-0706}{0009-0008-1520-0706}) \quad
6. \textbf{Afzalur Rahman} (Woxsen University, India; \href{mailto:afzalur.rahman@woxsen.edu.in}{afzalur.rahman@woxsen.edu.in}; ORCID: \href{https://orcid.org/0000-0002-1561-561X}{0000-0002-1561-561X})

\vspace{0.15em}
\hrule
\vspace{0.25em}

\noindent September 10, 2026 \hfill \textbf{Subject: Original Research Article Submission}

\vspace{0.2em}

\noindent \textbf{To:} The Editors-in-Chief / Editorial Board, \textit{Journal of Commodity Markets}, Elsevier B.V. (ISSN: 2405-8513)

\vspace{0.2em}

\noindent Dear Editors-in-Chief and Editorial Board Members,

\vspace{0.15em}

\noindent We are pleased to submit our original research manuscript entitled:
\begin{center}
\textbf{``Quantum Kernel Methods for Crude Oil Volatility Forecasting under Geopolitical Risk: A Controlled Out-of-Sample Benchmark''}
\end{center}
for consideration for publication as a Research Article in the \textit{Journal of Commodity Markets} (Elsevier).

\vspace{0.15em}
\noindent \textbf{Aim, Scope \& Major Empirical Contributions:} \\
This study provides a comprehensive controlled out-of-sample benchmark (2016--2026, $N = 2,473$ clean trading days, 655-day test window) evaluating a 4-qubit Parameterized Quantum Circuit (PQC) kernel regression model (QSVR) against twelve classical econometric and machine learning benchmarks (HAR-RV-type, GARCH, EGARCH, GJR-GARCH, ElasticNet, SVR, Random Forest, XGBoost, LightGBM, LSTM):
\begin{itemize}\itemsep=0.03em \parsep=0pt \topsep=0.08em \partopsep=0pt
    \item \textbf{Loss-Dependent Forecasting Hierarchy:} Linear specifications (HAR-RV-type, $\text{RMSE} = 0.6708$; SVR-Linear, $\text{RMSE} = 0.6717$) achieve the lowest point-forecasting RMSE, while tree ensembles excel under asymmetric QLIKE loss (XGBoost, $\text{QLIKE} = 0.1574$). Diebold-Mariano tests with FDR adjustments ($p_{\text{FDR}} = 0.1712$) confirm no statistical point superiority for QSVR over linear/HAR benchmarks.
    \item \textbf{Controlled Quantum Kernel Representation:} On identical 4-feature inputs, the quantum kernel ($\text{RMSE} = 0.7007$) outperforms classical Gaussian RBF ($\text{RMSE} = 0.7140$), providing empirical evidence of a distinct nonlinear kernel representation under controlled identical inputs that differs from RBF geometry, though linear models maintain the lowest point error.
    \item \textbf{Econometric Role of Geopolitical Risk:} In dynamic multivariate HAC regressions (VIF $< 3.0$), lagged GPR is not an incremental daily point predictor ($\beta = 0.0008, p = 0.1544$), functioning primarily as a regime-stratification and stress-testing variable; adding geopolitical-risk variables to the volatility-and-financial-controls specification does not improve out-of-sample RMSE and increases forecast error across all three tested models.
    \item \textbf{Risk Management \& Portfolio Utility:} Tail-risk backtesting reveals a clear distinction between forecast competitiveness and risk calibration: Student-$t$ GARCH specifications provide better calibrated VaR estimates under their model-specific innovation assumptions ($4.73\%$--$4.89\%$ breaches), while EGARCH is overly conservative ($2.90\%$) and QSVR exhibits an elevated exceedance rate ($7.79\%$, Kupiec $p = 0.0024$), highlighting the importance of calibrated innovation distributions when translating volatility forecasts into tail-risk measures. In dynamic volatility targeting, the QSVR strategy achieves a $+14.10\%$ cumulative net return over the test window, compared with $+20.29\%$ for passive WTI buy-and-hold, while substantially reducing volatility and maximum drawdown; HAR-RV-type and SVR-Linear provide strong risk-adjusted performance while avoiding the severe drawdown of passive WTI.
\end{itemize}

\noindent \textbf{Declarations:} The manuscript is original, has not been published, and is not under review elsewhere. All authors have approved submission with no conflicts of interest. No external funding was received for this work. In accordance with the journal's data policies, publicly distributable derived datasets, model specifications, and quantum circuits are openly accessible at \url{https://github.com/rsoorat/Quantum-Oil-GPR-Benchmark}. Underlying market data subject to third-party licensing are available from their original providers or from corresponding author Shylaja H N (\href{mailto:shylaja.hn@manipal.edu}{shylaja.hn@manipal.edu}) where permitted upon reasonable request.

\vspace{0.15em}
\noindent \textbf{Declaration of Generative AI in the Writing Process:} During the preparation of this work, the authors used Anthropic Claude and Google DeepMind AI tools in order to assist with code optimization, data processing, and manuscript editing for clarity and formatting. After using these tools, the authors reviewed and edited the content as needed and take full responsibility for the content of the published article.

\vspace{0.25em}
\noindent Sincerely, \\
\textbf{Shylaja H N} (On behalf of all authors) \\
Manipal Institute of Commerce Finance and Economics, Manipal Academy of Higher Education, Manipal, India \\
Email: \href{mailto:shylaja.hn@manipal.edu}{shylaja.hn@manipal.edu}

\end{document}
"""
    with open("cover_letter.tex", "w", encoding="utf-8") as f:
        f.write(tex_content)
    print("Cover letter LaTeX file generated: cover_letter.tex")

def generate_cover_letter_docx():
    doc = docx.Document()
    for section in doc.sections:
        section.top_margin = Inches(0.65)
        section.bottom_margin = Inches(0.65)
        section.left_margin = Inches(0.75)
        section.right_margin = Inches(0.75)
        
    p_hdr = doc.add_paragraph()
    r = p_hdr.add_run("Corresponding Author:\nShylaja H N\n")
    r.font.bold = True
    r.font.size = Pt(10)
    p_hdr.add_run("Manipal Institute of Commerce Finance and Economics, Manipal Academy of Higher Education, Manipal, India\nEmail: shylaja.hn@manipal.edu | ORCID: 0000-0001-9807-8575\n\n").font.size = Pt(9.0)
    
    r_co = p_hdr.add_run("All Authors (in Manuscript Order):\n")
    r_co.font.bold = True
    r_co.font.size = Pt(9.5)
    p_hdr.add_run("1. Hamood Amur Al Wardi (Mazoon College, Muscat, Sultanate of Oman; omaniconsul@gmail.com; ORCID: 0009-0006-5697-5159)\n"
                  "2. Uvesh Husain (Mazoon College, Muscat, Sultanate of Oman; u78.husain@gmail.com; ORCID: 0000-0002-8502-8488)\n"
                  "3. Shylaja H N* (Corresponding Author, Manipal Academy of Higher Education, Manipal, India; shylaja.hn@manipal.edu; ORCID: 0000-0001-9807-8575)\n"
                  "4. Ram Soorat (Woxsen University, Hyderabad, Telangana, India; rsoorat@gmail.com; ORCID: 0000-0001-7875-9197)\n"
                  "5. Priyanka (University of Delhi, Delhi, India; priyanka292c@gmail.com; ORCID: 0009-0008-1520-0706)\n"
                  "6. Afzalur Rahman (Woxsen University, Hyderabad, Telangana, India; afzalur.rahman@woxsen.edu.in; ORCID: 0000-0002-1561-561X)\n").font.size = Pt(8.5)
    p_hdr.paragraph_format.space_after = Pt(4)
    
    p_date = doc.add_paragraph()
    p_date.add_run("September 10, 2026").font.size = Pt(10)
    p_date.paragraph_format.space_after = Pt(4)
    
    p_to = doc.add_paragraph()
    r_to = p_to.add_run("To:\nThe Editors-in-Chief / Editorial Board\nJournal of Commodity Markets\nElsevier B.V. (ISSN: 2405-8513)\n")
    r_to.font.bold = True
    r_to.font.size = Pt(10)
    p_to.paragraph_format.space_after = Pt(4)
    
    p_subj = doc.add_paragraph()
    r_sub = p_subj.add_run("Subject: Submission of Original Research Article for Peer Review")
    r_sub.font.bold = True
    r_sub.font.size = Pt(10.5)
    r_sub.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D)
    p_subj.paragraph_format.space_after = Pt(4)
    
    p_main = doc.add_paragraph()
    p_main.paragraph_format.line_spacing = 1.15
    p_main.paragraph_format.space_after = Pt(4)
    p_main.add_run("Dear Editors-in-Chief and Editorial Board Members,\n\n"
                   "We are pleased to submit our original research manuscript entitled:\n")
    
    r_title = p_main.add_run("“Quantum Kernel Methods for Crude Oil Volatility Forecasting under Geopolitical Risk: A Controlled Out-of-Sample Benchmark”\n")
    r_title.font.bold = True
    r_title.font.size = Pt(10.5)
    r_title.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D)
    
    p_main.add_run("for consideration for publication as a Research Article in the Journal of Commodity Markets (Elsevier).\n\n"
                   "In accordance with journal submission requirements, all empirical models, econometric baselines, and quantum machine learning specifications adhere strictly to established commodity market econometric standards, including Patton (2011) robust loss functions (MSE, QLIKE), Diebold-Mariano tests with False Discovery Rate controls, formal Value-at-Risk backtesting (Kupiec POF and Christoffersen independence tests), and comprehensive economic utility evaluation under volatility-targeting asset allocation strategies.\n\n")
    
    r_c = p_main.add_run("Aim, Scope & Major Empirical Contributions:\n")
    r_c.font.bold = True
    p_main.add_run("This study provides a comprehensive controlled out-of-sample benchmark (2016–2026, N = 2,473 clean trading days, 655-day test window) evaluating a 4-qubit Parameterized Quantum Circuit (PQC) kernel regression model (QSVR) against twelve classical econometric and machine learning benchmarks (HAR-RV-type, GARCH, EGARCH, GJR-GARCH, ElasticNet, SVR, Random Forest, XGBoost, LightGBM, LSTM):\n"
                   "• Loss-Dependent Forecasting Hierarchy: Linear specifications (HAR-RV-type, RMSE 0.6708; SVR-Linear, RMSE 0.6717) achieve the lowest point-forecasting RMSE, while tree ensembles excel under asymmetric QLIKE loss (XGBoost, QLIKE 0.1574). Diebold-Mariano tests with FDR adjustments (pFDR = 0.1712) confirm no statistical point superiority for QSVR over linear/HAR benchmarks.\n"
                   "• Controlled Quantum Kernel Representation: On identical 4-feature inputs, the quantum kernel (RMSE 0.7007) outperforms classical Gaussian RBF (RMSE 0.7140), providing empirical evidence of a distinct nonlinear kernel representation under controlled identical inputs that differs from RBF geometry, though linear models maintain the lowest point error.\n"
                   "• Econometric Role of Geopolitical Risk: In dynamic multivariate HAC regressions (VIF < 3.0), lagged GPR is not an incremental daily point predictor (beta = 0.0008, p = 0.1544), functioning primarily as a regime-stratification and stress-testing variable; adding geopolitical-risk variables to the volatility-and-financial-controls specification does not improve out-of-sample RMSE and increases forecast error across all three tested models.\n"
                   "• Risk Management & Portfolio Utility: Tail-risk backtesting reveals a clear distinction between forecast competitiveness and risk calibration: Student-t GARCH specifications provide better calibrated VaR estimates under their model-specific innovation assumptions (4.73%-4.89%), while EGARCH is overly conservative (2.90%) and QSVR exhibits an elevated exceedance rate (7.79%, Kupiec p=0.0024), highlighting the importance of calibrated innovation distributions when translating volatility forecasts into tail-risk measures. In dynamic volatility targeting, the QSVR strategy achieves a +14.10% cumulative net return over the test window, compared with +20.29% for passive WTI buy-and-hold, while substantially reducing volatility and maximum drawdown; HAR-RV-type and SVR-Linear provide strong risk-adjusted performance while avoiding the severe drawdown of passive WTI.\n\n")
    
    r_dec = p_main.add_run("Declarations: ")
    r_dec.font.bold = True
    p_main.add_run("The manuscript is original, has not been published, and is not under review elsewhere. All authors have approved submission with no conflicts of interest. No external funding was received for this work. In accordance with the journal's data policies, publicly distributable derived datasets, model specifications, and quantum circuits are openly accessible at https://github.com/rsoorat/Quantum-Oil-GPR-Benchmark. Any underlying market data subject to third-party licensing are available from their original providers or from corresponding author Shylaja H N (shylaja.hn@manipal.edu) where permitted upon reasonable request.\n\n")
    
    r_ai = p_main.add_run("Declaration of Generative AI in the Writing Process: ")
    r_ai.font.bold = True
    p_main.add_run("During the preparation of this work, the authors used Anthropic Claude and Google DeepMind AI tools in order to assist with code optimization, data processing, and manuscript editing for clarity and formatting. After using these tools, the authors reviewed and edited the content as needed and take full responsibility for the content of the published article.\n\n")
    
    p_main.add_run("Sincerely,\n\n")
    r_sig = p_main.add_run("Shylaja H N (On behalf of all authors)\n")
    r_sig.font.bold = True
    p_main.add_run("Manipal Institute of Commerce Finance and Economics, Manipal Academy of Higher Education, Manipal, India\nEmail: shylaja.hn@manipal.edu")
    
    doc.save("Cover_Letter.docx")
    print("Cover letter Word file generated: Cover_Letter.docx")

def main():
    print("=== Generating Journal Submission Cover Letter ===")
    generate_cover_letter_tex()
    generate_cover_letter_docx()

if __name__ == "__main__":
    main()
