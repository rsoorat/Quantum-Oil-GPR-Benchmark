import re, sys

sys.stdout.reconfigure(encoding='utf-8')

with open('references.bib', 'r', encoding='utf-8') as f:
    content = f.read()

# Match entries
raw_entries = re.split(r'\n@', '\n' + content)

print(f"Total raw chunks: {len(raw_entries)}")

for chunk in raw_entries:
    if not chunk.strip():
        continue
    m = re.match(r'(\w+)\s*\{\s*([^,]+),', chunk.strip())
    if m:
        etype = m.group(1)
        key = m.group(2)
        chunk_lower = chunk.lower()
        if any(term in chunk_lower for term in ['arxiv', 'ssrn', 'working paper', 'preprint', 'howpublished', 'note', 'techreport']):
            print(f"[{etype.upper()}] Key: {key}")
            # extract title
            t_m = re.search(r'title\s*=\s*\{([^}]+)\}', chunk, re.IGNORECASE)
            title = t_m.group(1) if t_m else "N/A"
            j_m = re.search(r'(journal|booktitle|institution|howpublished)\s*=\s*\{([^}]+)\}', chunk, re.IGNORECASE)
            journal = j_m.group(2) if j_m else "N/A"
            doi_m = re.search(r'(doi|url)\s*=\s*\{([^}]+)\}', chunk, re.IGNORECASE)
            doi = doi_m.group(2) if doi_m else "N/A"
            print(f"   Title: {title}")
            print(f"   Source: {journal}")
            print(f"   DOI/URL: {doi}")
            print("-" * 50)
