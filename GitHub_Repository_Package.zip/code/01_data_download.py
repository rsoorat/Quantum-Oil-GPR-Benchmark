import os
import urllib.request
import requests
import pandas as pd
import io
import yfinance as yf
import yaml

def main():
    print("=== Step 1: Data Download ===")
    
    # Load configuration
    with open("config.yaml", "r") as f:
        config = yaml.safe_load(f)
        
    start_date = config['data']['start_date']
    end_date = config['data']['end_date']
    
    # Create directories if they do not exist
    os.makedirs("data", exist_ok=True)
    os.makedirs("figures", exist_ok=True)
    os.makedirs("code", exist_ok=True)
    
    # 1. Download WTI Crude Oil Price
    api_key = os.environ.get("ALPHAVANTAGE_API_KEY")
    wti_downloaded = False
    
    if api_key:
        print("Alpha Vantage API Key found. Attempting to download WTI data...")
        url = f"https://www.alphavantage.co/query?function=WTI&interval=daily&apikey={api_key}&datatype=csv"
        try:
            r = requests.get(url, timeout=15)
            if r.status_code == 200 and "Error Message" not in r.text and "Information" not in r.text:
                # Save raw Alpha Vantage response
                with open(config['data']['raw_wti_path'], "w") as f_wti:
                    f_wti.write(r.text)
                print("Successfully downloaded WTI data from Alpha Vantage.")
                wti_downloaded = True
            else:
                print("Alpha Vantage API response was invalid or limited. Falling back to local data.")
                print(r.text[:200])
        except Exception as e:
            print(f"Alpha Vantage API download failed: {e}. Falling back to local data.")
            
    if not wti_downloaded:
        print("Using local WTI dataset alfredgraph.csv...")
        local_path = "../alfredgraph.csv"
        if os.path.exists(local_path):
            df_local = pd.read_csv(local_path)
            # Reformat local data to match Alpha Vantage columns (date, value)
            df_wti = df_local[['observation_date', 'DCOILWTICO_20260819']].copy()
            df_wti.columns = ['date', 'value']
            df_wti.to_csv(config['data']['raw_wti_path'], index=False)
            print(f"Formatted local WTI dataset saved to {config['data']['raw_wti_path']}.")
        else:
            raise FileNotFoundError("Local alfredgraph.csv file not found!")
            
    # 2. Download Daily Geopolitical Risk Index (GPR)
    print("Downloading daily GPR data from Matteo Iacoviello's site...")
    gpr_url = "https://www.matteoiacoviello.com/gpr_files/data_gpr_daily_recent.xls"
    gpr_raw_path = "data/raw_gpr_daily.xls"
    try:
        r_gpr = requests.get(gpr_url, timeout=30)
        with open(gpr_raw_path, "wb") as f_gpr:
            f_gpr.write(r_gpr.content)
        print(f"Successfully downloaded daily GPR and saved to {gpr_raw_path}.")
    except Exception as e:
        print(f"Failed to download GPR data: {e}")
        
    # 3. Download Daily AI-GPR Index
    print("Downloading daily AI-GPR data from Matteo Iacoviello's site...")
    ai_gpr_url = "https://www.matteoiacoviello.com/ai_gpr_files/ai_gpr_data_daily.csv"
    ai_gpr_raw_path = "data/raw_ai_gpr_daily.csv"
    try:
        r_ai = requests.get(ai_gpr_url, timeout=30)
        with open(ai_gpr_raw_path, "w", encoding='utf-8') as f_ai:
            f_ai.write(r_ai.text)
        print(f"Successfully downloaded daily AI-GPR and saved to {ai_gpr_raw_path}.")
    except Exception as e:
        print(f"Failed to download AI-GPR data: {e}")
        
    # 4. Download Control Variables from Yahoo Finance
    print("Downloading control variables from Yahoo Finance...")
    tickers = {
        '^VIX': 'VIX',
        'GC=F': 'Gold',
        'DX-Y.NYB': 'DollarIndex',
        'NG=F': 'NaturalGas',
        'BZ=F': 'BrentCrude',
        '^TNX': 'TreasuryYield'
    }
    
    try:
        df_controls = yf.download(list(tickers.keys()), start=start_date, end=end_date, progress=False)
        # Select Close price only
        df_close = df_controls['Close'].copy()
        # Rename columns to human readable
        df_close = df_close.rename(columns=tickers)
        # Save raw controls
        df_close.to_csv("data/raw_controls.csv")
        print("Successfully downloaded control variables from Yahoo Finance.")
        print(f"Controls shape: {df_close.shape}")
    except Exception as e:
        print(f"Failed to download control variables: {e}")

if __name__ == "__main__":
    main()
