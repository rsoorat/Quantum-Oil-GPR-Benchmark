import re, sys, urllib.request, json, time

sys.stdout.reconfigure(encoding='utf-8')

# 1. Parse cited keys in manuscript
with open('Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript.tex', 'r', encoding='utf-8') as f:
    tex = f.read()

cite_keys = set()
for m in re.finditer(r'\\cite[a-z]*\{([^}]+)\}', tex):
    for k in m.group(1).split(','):
        cite_keys.add(k.strip())

# 2. Parse references.bib
with open('references.bib', 'r', encoding='utf-8') as f:
    bib = f.read()

raw_entries = re.split(r'\n@', '\n' + bib)
bib_dict = {}
for chunk in raw_entries:
    if not chunk.strip():
        continue
    m = re.match(r'(\w+)\s*\{\s*([^,]+),', chunk.strip())
    if m:
        etype, key = m.group(1), m.group(2)
        fields = {}
        for line in chunk.split('\n'):
            line_clean = line.strip()
            if '=' in line_clean:
                k, v = line_clean.split('=', 1)
                k = k.strip().lower()
                v = v.strip().rstrip(',').strip('"{}"')
                fields[k] = v
        bib_dict[key] = (etype, fields)

print(f"Total cited keys in manuscript: {len(cite_keys)}")
print("=" * 80)

# Check all cited keys
for idx, key in enumerate(sorted(list(cite_keys)), 1):
    if key not in bib_dict:
        print(f"ERROR: Missing key {key}")
        continue
    etype, fields = bib_dict[key]
    author = fields.get('author', 'N/A')
    year = fields.get('year', 'N/A')
    title = fields.get('title', 'N/A')
    journal = fields.get('journal', fields.get('booktitle', fields.get('publisher', fields.get('howpublished', 'N/A'))))
    volume = fields.get('volume', '')
    pages = fields.get('pages', '')
    doi = fields.get('doi', fields.get('url', 'N/A'))
    
    print(f"{idx:2d}. [{key}] ({year})")
    print(f"    Author:  {author}")
    print(f"    Title:   {title}")
    print(f"    Journal: {journal} (Vol: {volume}, Pages: {pages})")
    print(f"    DOI/URL: {doi}")
    print("-" * 80)
