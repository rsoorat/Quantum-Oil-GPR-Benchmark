import pandas as pd
import numpy as np
import yaml
import openpyxl
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import statsmodels.api as sm
from arch import arch_model
import sys
import os
import importlib

# Add current folder to sys.path
script_dir = os.path.abspath(os.path.dirname(__file__))
if script_dir not in sys.path:
    sys.path.append(script_dir)

classical_ml = importlib.import_module("06_classical_ml")
lstm_model = importlib.import_module("07_lstm_model")
quantum_model = importlib.import_module("08_quantum_model")

FEATURES = classical_ml.FEATURES
train_elastic_net = classical_ml.train_elastic_net
train_svr_kernels = classical_ml.train_svr_kernels
train_random_forest = classical_ml.train_random_forest
train_xgboost = classical_ml.train_xgboost
train_lightgbm = classical_ml.train_lightgbm

train_lstm = lstm_model.train_lstm
predict_lstm = lstm_model.predict_lstm

train_qsvr = quantum_model.train_qsvr
predict_qsvr = quantum_model.predict_qsvr
benchmark_kernels = quantum_model.benchmark_kernels

def main():
    print("=== Step 9: Chronological Out-of-Sample Volatility Forecasting & Ablation Study ===")
    
    # Load configuration
    with open("config.yaml", "r") as f:
        config = yaml.safe_load(f)
        
    dataset_path = config['data']['oil_model_dataset_path']
    df = pd.read_csv(dataset_path)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    
    n_total = len(df)
    print(f"Full empirical dataset length: {n_total} trading days ({df['date'].min().strftime('%Y-%m-%d')} to {df['date'].max().strftime('%Y-%m-%d')})")
    
    # Transparent Chronological Splits
    # Training: 2016-08-18 to 2022-12-31 (~65%)
    # Validation: 2023-01-01 to 2023-12-31 (~15%)
    # Out-of-Sample Test: 2024-01-01 to 2026-08-18 (~20%, N ~ 650+ trading days)
    date_train_end = pd.to_datetime("2022-12-31")
    date_val_end = pd.to_datetime("2023-12-31")
    
    df_train = df[df['date'] <= date_train_end].reset_index(drop=True)
    df_val = df[(df['date'] > date_train_end) & (df['date'] <= date_val_end)].reset_index(drop=True)
    df_test = df[df['date'] > date_val_end].reset_index(drop=True)
    
    # Fallback if dates mismatch
    if len(df_test) < 100:
        n_train = int(n_total * 0.65)
        n_val = int(n_total * 0.15)
        df_train = df.iloc[:n_train].reset_index(drop=True)
        df_val = df.iloc[n_train:n_train+n_val].reset_index(drop=True)
        df_test = df.iloc[n_train+n_val:].reset_index(drop=True)
        
    print(f"\n--- Chronological Sample Splitting ---")
    print(f"Training Period:   {df_train['date'].min().strftime('%Y-%m-%d')} to {df_train['date'].max().strftime('%Y-%m-%d')} (N={len(df_train)})")
    print(f"Validation Period: {df_val['date'].min().strftime('%Y-%m-%d')} to {df_val['date'].max().strftime('%Y-%m-%d')} (N={len(df_val)})")
    print(f"Out-of-Sample Test:{df_test['date'].min().strftime('%Y-%m-%d')} to {df_test['date'].max().strftime('%Y-%m-%d')} (N={len(df_test)})")
    
    # Feature matrices
    X_train, y_train = df_train[FEATURES], df_train['Target_Vol'].values
    X_val, y_val = df_val[FEATURES], df_val['Target_Vol'].values
    X_test, y_test = df_test[FEATURES], df_test['Target_Vol'].values
    
    predictions = {
        'date': df_test['date'],
        'Actual_Vol': y_test
    }
    
    # 1. HAR-RV (Corsi, 2009)
    print("\n1. Fitting HAR-RV Benchmark...")
    X_train_val = pd.concat([X_train, X_val]).reset_index(drop=True)
    y_train_val = np.concatenate([y_train, y_val])
    
    har_train_X = sm.add_constant(X_train_val[['HAR_d_Lag1', 'HAR_w_Lag1', 'HAR_m_Lag1']])
    har_test_X = sm.add_constant(X_test[['HAR_d_Lag1', 'HAR_w_Lag1', 'HAR_m_Lag1']])
    har_model = sm.OLS(y_train_val, har_train_X).fit(cov_type='HAC', cov_kwds={'maxlags': 5})
    predictions['HAR_RV_Forecast'] = har_model.predict(har_test_X)
    
    # 2. Econometric Benchmarks (GARCH, EGARCH, GJR-GARCH)
    print("\n2. Fitting Econometric GARCH Benchmarks...")
    df_train_val = pd.concat([df_train, df_val]).reset_index(drop=True)
    ret_train_val = df_train_val['WTI_Return'].values
    ret_test = df_test['WTI_Return'].values
    
    # GARCH(1,1)
    garch_mod = arch_model(ret_train_val, vol='Garch', p=1, q=1, dist='studentst', rescale=False)
    garch_res = garch_mod.fit(disp='off')
    omega, alpha, beta = garch_res.params['omega'], garch_res.params['alpha[1]'], garch_res.params['beta[1]']
    curr_vol2 = garch_res.conditional_volatility[-1] ** 2
    curr_ret2 = ret_train_val[-1] ** 2
    garch_preds = []
    for r in ret_test:
        next_vol2 = omega + alpha * curr_ret2 + beta * curr_vol2
        garch_preds.append(np.sqrt(next_vol2))
        curr_vol2 = next_vol2
        curr_ret2 = r ** 2
    predictions['GARCH_Forecast'] = np.array(garch_preds)
    
    # EGARCH(1,1)
    egarch_mod = arch_model(ret_train_val, vol='EGarch', p=1, q=1, dist='studentst', rescale=False)
    egarch_res = egarch_mod.fit(disp='off')
    eg_omega, eg_alpha, eg_beta = egarch_res.params['omega'], egarch_res.params['alpha[1]'], egarch_res.params['beta[1]']
    curr_ln_vol2 = np.log(egarch_res.conditional_volatility[-1] ** 2)
    egarch_preds = []
    for r in ret_test:
        std_resid = r / np.sqrt(np.exp(curr_ln_vol2))
        next_ln_vol2 = eg_omega + eg_beta * curr_ln_vol2 + eg_alpha * (np.abs(std_resid) - np.sqrt(2/np.pi))
        egarch_preds.append(np.sqrt(np.exp(next_ln_vol2)))
        curr_ln_vol2 = next_ln_vol2
    predictions['EGARCH_Forecast'] = np.array(egarch_preds)
    
    # GJR-GARCH(1,1)
    gjr_mod = arch_model(ret_train_val, vol='Garch', p=1, o=1, q=1, dist='studentst', rescale=False)
    gjr_res = gjr_mod.fit(disp='off')
    gjr_omega, gjr_alpha, gjr_gamma, gjr_beta = gjr_res.params['omega'], gjr_res.params['alpha[1]'], gjr_res.params['gamma[1]'], gjr_res.params['beta[1]']
    curr_vol2 = gjr_res.conditional_volatility[-1] ** 2
    curr_ret = ret_train_val[-1]
    gjr_preds = []
    for r in ret_test:
        dummy = 1.0 if curr_ret < 0 else 0.0
        next_vol2 = gjr_omega + (gjr_alpha + gjr_gamma * dummy) * (curr_ret**2) + gjr_beta * curr_vol2
        gjr_preds.append(np.sqrt(next_vol2))
        curr_vol2 = next_vol2
        curr_ret = r
    predictions['GJR_Forecast'] = np.array(gjr_preds)
    
    # 3. Classical Machine Learning Models
    print("\n3. Fitting Machine Learning Models...")
    # ElasticNet
    en_model, en_scaler, en_params = train_elastic_net(X_train, y_train, X_val, y_val)
    X_test_scaled = en_scaler.transform(X_test)
    predictions['ElasticNet_Forecast'] = en_model.predict(X_test_scaled)
    
    # SVR Kernels (Linear, Poly, RBF)
    svr_models, svr_scaler = train_svr_kernels(X_train, y_train, X_val, y_val)
    X_test_svr = svr_scaler.transform(X_test)
    predictions['SVR_Linear_Forecast'] = svr_models['linear'].predict(X_test_svr)
    predictions['SVR_Poly_Forecast'] = svr_models['poly'].predict(X_test_svr)
    predictions['SVR_RBF_Forecast'] = svr_models['rbf'].predict(X_test_svr)
    
    # Random Forest, XGBoost, LightGBM
    rf_model, rf_scaler, _ = train_random_forest(X_train, y_train, X_val, y_val)
    predictions['RF_Forecast'] = rf_model.predict(rf_scaler.transform(X_test))
    
    xgb_model, xgb_scaler, _ = train_xgboost(X_train, y_train, X_val, y_val)
    predictions['XGBoost_Forecast'] = xgb_model.predict(xgb_scaler.transform(X_test))
    
    lgb_model, lgb_scaler, _ = train_lightgbm(X_train, y_train, X_val, y_val)
    predictions['LightGBM_Forecast'] = lgb_model.predict(lgb_scaler.transform(X_test))
    
    # 4. PyTorch LSTM
    print("\n4. Fitting Deep Learning LSTM...")
    lstm_net, lstm_scaler, seq_len = train_lstm(X_train, y_train, X_val, y_val, seq_length=5, epochs=35)
    X_val_last = X_val.iloc[-(seq_len-1):]
    X_test_with_context = pd.concat([X_val_last, X_test]).reset_index(drop=True)
    predictions['LSTM_Forecast'] = predict_lstm(lstm_net, lstm_scaler, X_test_with_context, seq_len)
    
    # 5. Quantum Support Vector Regression (QSVR)
    print("\n5. Fitting Quantum Support Vector Regression (QSVR)...")
    qsvr_model, qsvr_scaler, states_train = train_qsvr(X_train, y_train, X_val, y_val)
    predictions['QSVR_Forecast'] = predict_qsvr(qsvr_model, qsvr_scaler, states_train, X_test)
    
    # 6. Save Predictions
    df_preds = pd.DataFrame(predictions)
    df_preds.to_csv("data/oil_model_predictions.csv", index=False)
    print("\nOut-of-sample predictions successfully saved to data/oil_model_predictions.csv.")
    
    # 7. Compute Quantum vs Classical Kernel Properties Benchmark Table
    print("\n6. Benchmarking Kernel Alignment, Effective Dimension, and Properties...")
    X_train_scaled_q = qsvr_scaler.transform(X_train[quantum_model.QUANTUM_FEATURES].values)
    df_kernel_bench = benchmark_kernels(X_train_scaled_q, y_train)
    print(df_kernel_bench.to_string(index=False))
    
    # 8. Feature Ablation Study
    # Subset A: Volatility Lags / HAR only
    # Subset B: Volatility Lags + Financial Market Controls
    # Subset C: Full (Volatility + Controls + Geopolitical Risk)
    print("\n7. Executing Feature Ablation Study across Model Classes...")
    ablation_results = []
    
    subsets = {
        'Vol_Only': ['Vol_Lag1', 'Vol_Lag2', 'HAR_d_Lag1', 'HAR_w_Lag1', 'HAR_m_Lag1'],
        'Vol_Controls': ['Vol_Lag1', 'Vol_Lag2', 'HAR_d_Lag1', 'HAR_w_Lag1', 'HAR_m_Lag1', 'VIX_Lag1', 'VIX_Diff_Lag1', 'Gold_Return_Lag1', 'Dollar_Return_Lag1', 'Gas_Return_Lag1', 'Brent_Return_Lag1', 'Treasury_Diff_Lag1'],
        'Full_GPR': FEATURES
    }
    
    for sub_name, feat_list in subsets.items():
        # ElasticNet on subset
        en_s, scaler_s, _ = train_elastic_net(X_train[feat_list], y_train, X_val[feat_list], y_val)
        pred_en = en_s.predict(scaler_s.transform(X_test[feat_list]))
        rmse_en = np.sqrt(mean_squared_error(y_test, pred_en))
        r2_en = r2_score(y_test, pred_en)
        
        # XGBoost on subset
        xgb_s, scaler_s, _ = train_xgboost(X_train[feat_list], y_train, X_val[feat_list], y_val)
        pred_xgb = xgb_s.predict(scaler_s.transform(X_test[feat_list]))
        rmse_xgb = np.sqrt(mean_squared_error(y_test, pred_xgb))
        r2_xgb = r2_score(y_test, pred_xgb)
        
        # SVR RBF on subset
        svr_s, scaler_s = train_svr_kernels(X_train[feat_list], y_train, X_val[feat_list], y_val)
        pred_svr = svr_s['rbf'].predict(scaler_s.transform(X_test[feat_list]))
        rmse_svr = np.sqrt(mean_squared_error(y_test, pred_svr))
        r2_svr = r2_score(y_test, pred_svr)
        
        ablation_results.append({
            'Feature Set': sub_name,
            'ElasticNet RMSE': rmse_en,
            'ElasticNet R2': r2_en,
            'XGBoost RMSE': rmse_xgb,
            'XGBoost R2': r2_xgb,
            'SVR-RBF RMSE': rmse_svr,
            'SVR-RBF R2': r2_svr
        })
        
    df_ablation = pd.DataFrame(ablation_results)
    print("\n--- Ablation Study Results ---")
    print(df_ablation.to_string(index=False))
    
    # Save splits, kernel benchmarks, and ablation to tables.xlsx
    try:
        wb = openpyxl.load_workbook("tables.xlsx")
    except FileNotFoundError:
        wb = openpyxl.Workbook()
        if 'Sheet' in wb.sheetnames:
            wb.remove(wb['Sheet'])
    
    # Splits Table
    if 'SampleSplits' in wb.sheetnames:
        wb.remove('SampleSplits')
    ws_sp = wb.create_sheet('SampleSplits')
    ws_sp.append(['Dataset Partition', 'Start Date', 'End Date', 'Observations (Trading Days)', 'Percentage'])
    ws_sp.append(['Full Clean Dataset', df['date'].min().strftime('%Y-%m-%d'), df['date'].max().strftime('%Y-%m-%d'), len(df), '100.0%'])
    ws_sp.append(['Training Set', df_train['date'].min().strftime('%Y-%m-%d'), df_train['date'].max().strftime('%Y-%m-%d'), len(df_train), f"{len(df_train)/len(df)*100:.1f}%"])
    ws_sp.append(['Validation Set', df_val['date'].min().strftime('%Y-%m-%d'), df_val['date'].max().strftime('%Y-%m-%d'), len(df_val), f"{len(df_val)/len(df)*100:.1f}%"])
    ws_sp.append(['Out-of-Sample Test', df_test['date'].min().strftime('%Y-%m-%d'), df_test['date'].max().strftime('%Y-%m-%d'), len(df_test), f"{len(df_test)/len(df)*100:.1f}%"])
    
    # Kernel Benchmark Table
    if 'KernelProperties' in wb.sheetnames:
        wb.remove('KernelProperties')
    ws_kb = wb.create_sheet('KernelProperties')
    ws_kb.append(['Kernel Architecture', 'Kernel-Target Alignment', 'Effective Dimension', 'Matrix Rank', 'Condition Number'])
    for idx, row in df_kernel_bench.iterrows():
        ws_kb.append(list(row.values))
        
    # Ablation Table
    if 'AblationStudy' in wb.sheetnames:
        wb.remove('AblationStudy')
    ws_ab = wb.create_sheet('AblationStudy')
    ws_ab.append(['Feature Set', 'ElasticNet RMSE', 'ElasticNet R^2', 'XGBoost RMSE', 'XGBoost R^2', 'SVR-RBF RMSE', 'SVR-RBF R^2'])
    for idx, row in df_ablation.iterrows():
        ws_ab.append(list(row.values))
        
    wb.save("tables.xlsx")
    print("\nSample splits, kernel properties, and ablation tables saved to tables.xlsx.")

if __name__ == "__main__":
    main()
