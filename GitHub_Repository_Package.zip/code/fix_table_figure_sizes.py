import re, sys

sys.stdout.reconfigure(encoding='utf-8')

with open('Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript.tex', 'r', encoding='utf-8') as f:
    content = f.read()

# 1. Replace all \begin{table*} and \end{table*} with \begin{table} and \end{table}
content = content.replace('\\begin{table*}', '\\begin{table}')
content = content.replace('\\end{table*}', '\\end{table}')

# 2. Replace all \begin{figure*} and \end{figure*} with \begin{figure} and \end{figure}
content = content.replace('\\begin{figure*}', '\\begin{figure}')
content = content.replace('\\end{figure*}', '\\end{figure}')

# 3. For tables that are NOT wide (less than 8 columns), remove \resizebox{\textwidth}{!}{% ... }
# List of table labels to remove resizebox from:
# tab:neg_sens (7 cols)
# tab:econometric (6 cols)
# tab:kernel_props (5 cols)
# tab:qreg_sens (5 cols)
# tab:info_set (4 cols)
# tab:ablation (7 cols)
# tab:controlled_4f (6 cols)
# tab:dm_tests (6 cols)
# tab:regimes (4 cols)
# tab:robustness (5 cols)

remove_resize_labels = [
    'tab:neg_sens',
    'tab:econometric',
    'tab:kernel_props',
    'tab:qreg_sens',
    'tab:info_set',
    'tab:ablation',
    'tab:controlled_4f',
    'tab:dm_tests',
    'tab:regimes',
    'tab:robustness'
]

for lbl in remove_resize_labels:
    # Pattern: \label{lbl}\s*\\resizebox\{\\textwidth\}\{!\}[\{%]*\s*(\\begin\{tabular\}.*?\\end\{tabular\})\s*[\}%]*
    pattern = rf'(\\label\{{{lbl}\}}\s*)\\resizebox\{{\\textwidth\}}\{{!\}}\{{%?\s*(\\begin\{{tabular\}}.*?\\end\{{tabular\}})\s*%?\}}'
    
    def repl(m):
        label_part = m.group(1)
        tab_part = m.group(2)
        return f"{label_part}\\setlength{{\\tabcolsep}}{{8pt}}\n{tab_part}"
        
    content = re.sub(pattern, repl, content, flags=re.DOTALL)

# Also ensure tab:h1_reg and tab:perf have \setlength{\tabcolsep}{10pt}
content = re.sub(r'(\\label\{tab:h1_reg\}\s*)(\\begin\{tabular\})', r'\1\\setlength{\\tabcolsep}{10pt}\n\2', content)
content = re.sub(r'(\\label\{tab:perf\}\s*)(\\begin\{tabular\})', r'\1\\setlength{\\tabcolsep}{10pt}\n\2', content)

# 4. Standardize figure widths
content = re.sub(r'\\includegraphics\[width=[0-9\.]+\\textwidth\]\{figures/figure_quantum_circuit\.png\}', r'\\includegraphics[width=0.90\\textwidth]{figures/figure_quantum_circuit.png}', content)
content = re.sub(r'\\includegraphics\[width=[0-9\.]+\\textwidth\]\{figures/figure_07_gpr_regimes\.png\}', r'\\includegraphics[width=0.75\\textwidth]{figures/figure_07_gpr_regimes.png}', content)
content = re.sub(r'\\includegraphics\[width=[0-9\.]+\\textwidth\]\{figures/figure_08_actual_vs_predicted\.png\}', r'\\includegraphics[width=0.88\\textwidth]{figures/figure_08_actual_vs_predicted.png}', content)
content = re.sub(r'\\includegraphics\[width=[0-9\.]+\\textwidth\]\{figures/figure_09_model_comparison\.png\}', r'\\includegraphics[width=0.85\\textwidth]{figures/figure_09_model_comparison.png}', content)
content = re.sub(r'\\includegraphics\[width=[0-9\.]+\\textwidth\]\{figures/figure_10_regime_comparison\.png\}', r'\\includegraphics[width=0.85\\textwidth]{figures/figure_10_regime_comparison.png}', content)
content = re.sub(r'\\includegraphics\[width=[0-9\.]+\\textwidth\]\{figures/figure_11_shap\.png\}', r'\\includegraphics[width=0.85\\textwidth]{figures/figure_11_shap.png}', content)
content = re.sub(r'\\includegraphics\[width=[0-9\.]+\\textwidth\]\{figures/figure_12_economic_performance\.png\}', r'\\includegraphics[width=0.88\\textwidth]{figures/figure_12_economic_performance.png}', content)

with open('Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript.tex', 'w', encoding='utf-8') as f:
    f.write(content)

print("Manuscript tables and figures standardized for single-column article publication layout.")
