import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import qn, nsdecls
import openpyxl
import os
import re
from PIL import Image

def set_cell_background(cell, fill_hex):
    tcPr = cell._element.get_or_add_tcPr()
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), fill_hex)
    tcPr.append(shd)

def set_cell_margins(cell, top=100, bottom=100, left=140, right=140):
    tcPr = cell._element.get_or_add_tcPr()
    tcMar = OxmlElement('w:tcMar')
    for m, val in [('top', top), ('bottom', bottom), ('left', left), ('right', right)]:
        node = OxmlElement(f'w:{m}')
        node.set(qn('w:w'), str(val))
        node.set(qn('w:type'), 'dxa')
        tcMar.append(node)
    tcPr.append(tcMar)

def parse_and_add_runs(p, text, default_font="Calibri", default_size=Pt(11), default_color=None, bold_all=False, italic_all=False):
    """
    Parses tagged text with:
      ^sup{...} -> superscript run
      _sub{...} -> subscript run
      *it{...}  -> italic run
      **bold{...} -> bold run
      *bi{...}  -> bold italic run
    and adds runs to paragraph p with the specified font attributes.
    """
    pattern = re.compile(r'(\*\*bold\{.*?\}|\*bi\{.*?\}|\*it\{.*?\}|\^sup\{.*?\}|_sub\{.*?\})')
    tokens = pattern.split(text)
    
    for token in tokens:
        if not token:
            continue
        if token.startswith('^sup{') and token.endswith('}'):
            content = token[5:-1]
            r = p.add_run(content)
            r.font.name = default_font
            r.font.size = default_size
            r.font.superscript = True
            if default_color:
                r.font.color.rgb = default_color
            if bold_all:
                r.font.bold = True
            if italic_all:
                r.font.italic = True
        elif token.startswith('_sub{') and token.endswith('}'):
            content = token[5:-1]
            r = p.add_run(content)
            r.font.name = default_font
            r.font.size = default_size
            r.font.subscript = True
            if default_color:
                r.font.color.rgb = default_color
            if bold_all:
                r.font.bold = True
            if italic_all:
                r.font.italic = True
        elif token.startswith('*it{') and token.endswith('}'):
            content = token[4:-1]
            r = p.add_run(content)
            r.font.name = default_font
            r.font.size = default_size
            r.font.italic = True
            if default_color:
                r.font.color.rgb = default_color
            if bold_all:
                r.font.bold = True
        elif token.startswith('**bold{') and token.endswith('}'):
            content = token[7:-1]
            r = p.add_run(content)
            r.font.name = default_font
            r.font.size = default_size
            r.font.bold = True
            if default_color:
                r.font.color.rgb = default_color
            if italic_all:
                r.font.italic = True
        elif token.startswith('*bi{') and token.endswith('}'):
            content = token[4:-1]
            r = p.add_run(content)
            r.font.name = default_font
            r.font.size = default_size
            r.font.bold = True
            r.font.italic = True
            if default_color:
                r.font.color.rgb = default_color
        else:
            r = p.add_run(token)
            r.font.name = default_font
            r.font.size = default_size
            if bold_all:
                r.font.bold = True
            if italic_all:
                r.font.italic = True
            if default_color:
                r.font.color.rgb = default_color

def format_math_markup(text):
    """
    Transforms raw academic mathematical text, variables, Greek letters,
    subscripts, superscripts, and symbols into tag format for parse_and_add_runs.
    """
    if not text:
        return text
    t = text
    
    # Mathematical variables with subscripts/superscripts
    # R2 -> R^sup{2}
    t = re.sub(r'(?<=[(\s,])R2(?=[\s,;.)]|$)', '*it{R}^sup{2}', t)
    t = re.sub(r'^R2(?=[\s,;.)]|$)', '*it{R}^sup{2}', t)
    t = re.sub(r'Out-of-Sample R2', 'Out-of-Sample *it{R}^sup{2}', t)
    t = re.sub(r'\bAdj R2\b', 'Adj *it{R}^sup{2}', t)
    
    # Statistical symbols and metrics
    t = re.sub(r'\bpFDR\s*=\s*', '*it{p}_sub{FDR} = ', t)
    t = re.sub(r'\bpFDR\b', '*it{p}_sub{FDR}', t)
    
    # Greek letters with parameters
    t = re.sub(r'\bbeta\s*=\s*', '*it{β} = ', t)
    t = re.sub(r'\bbeta\s*>\s*', '*it{β} > ', t)
    t = re.sub(r'\bbeta\s*<\s*', '*it{β} < ', t)
    t = re.sub(r'\bbeta_(\w+)', r'*it{β}_sub{\1}', t)
    
    t = re.sub(r'\bgamma\s*!=\s*0', '*it{γ} ≠ 0', t)
    t = re.sub(r'\bgamma\s*=\s*', '*it{γ} = ', t)
    t = re.sub(r'\bgamma\s*>\s*', '*it{γ} > ', t)
    t = re.sub(r'\bgamma\s*<\s*', '*it{γ} < ', t)
    
    t = re.sub(r'\blambda\s*=\s*1e-5', '*it{λ} = 10^sup{-5}', t)
    t = re.sub(r'\blambda\s+in\s+\[1e-7,\s*1e-1\]', '*it{λ} ∈ [10^sup{-7}, 10^sup{-1}]', t)
    t = re.sub(r'\blambda\*I\b', '*it{λ} *it{I}', t)
    t = re.sub(r'\blambda\b(?=\s+in\s+\[)', '*it{λ}', t)
    
    t = re.sub(r'\bsigma_target\s+in\s+\{10%,\s*15%,\s*20%\}', '*it{σ}_sub{target} ∈ {10%, 15%, 20%}', t)
    t = re.sub(r'\bsigma_target\b', '*it{σ}_sub{target}', t)
    t = re.sub(r'\\hat\{\\sigma\}_t\^\{\\text\{ann\}\}', '*it{σ̂}_sub{t}^sup{ann}', t)
    t = re.sub(r'\\hat\{\\sigma\}_t\^ann', '*it{σ̂}_sub{t}^sup{ann}', t)
    t = re.sub(r'\\hat\{\\sigma\}_t', '*it{σ̂}_sub{t}', t)
    t = re.sub(r'\\hat\{\\sigma\}', '*it{σ̂}', t)
    t = re.sub(r'\\hat\{V\}_t\s*=\s*\\hat\{\\sigma\}_t\^2', '*it{V̂}_sub{t} = *it{σ̂}_sub{t}^sup{2}', t)
    t = re.sub(r'\\hat\{V\}_t', '*it{V̂}_sub{t}', t)
    t = re.sub(r'V_t\^\{obs\}\s*=\s*Vol_\{t,5\}\^2', '*it{V}_sub{t}^sup{obs} = Vol_sub{t,5}^sup{2}', t)
    t = re.sub(r'V_t\^\{obs\}', '*it{V}_sub{t}^sup{obs}', t)
    t = re.sub(r'Vol_\{t,5\}\^2', 'Vol_sub{t,5}^sup{2}', t)
    
    t = re.sub(r'\bw_max\s*=\s*', '*it{w}_sub{max} = ', t)
    t = re.sub(r'\bw_max\b', '*it{w}_sub{max}', t)
    t = re.sub(r'\bw_t\b', '*it{w}_sub{t}', t)
    
    # Hilbert space and dimension
    t = re.sub(r'\bd=16\b', '*it{d} = 16', t)
    t = re.sub(r'\bd\^2\s*=\s*256\b', '*it{d}^sup{2} = 256', t)
    t = re.sub(r'Herm\(H_16\)', 'Herm(*it{ℋ}_sub{16})', t)
    t = re.sub(r'\|\<0000\|\s*U†\(xi\)\s*U\(xj\)\s*\|0000\>\|\^2', '|⟨0000| *it{U}^sup{†}(*it{x}_sub{i}) *it{U}(*it{x}_sub{j}) |0000⟩|^sup{2}', t)
    t = re.sub(r'K_reg\s*=\s*KQ\s*\+\s*lambda\*I', '*it{K}_sub{reg} = *it{K}_sub{Q} + *it{λ} *it{I}', t)
    t = re.sub(r'\bK_reg\b', '*it{K}_sub{reg}', t)
    t = re.sub(r'\bKQ\b', '*it{K}_sub{Q}', t)
    t = re.sub(r'\bx1\s*=\s*Vol_Lag1,\s*x2\s*=\s*GPRD_Lag1,\s*x3\s*=\s*VIX_Lag1,\s*x4\s*=\s*Return_Lag1',
               '*it{x}_sub{1} = Vol_Lag1, *it{x}_sub{2} = GPRD_Lag1, *it{x}_sub{3} = VIX_Lag1, *it{x}_sub{4} = Return_Lag1', t)
    t = re.sub(r'Ry\(xk\)', '*it{R}_sub{Y}(*it{x}_sub{k})', t)
    t = re.sub(r'\|0000>', '|0000⟩', t)
    t = re.sub(r'<0000\|', '⟨0000|', t)
    t = re.sub(r'A\(K,\s*y\)', '*it{𝒜}(*it{K}, *it{y})', t)
    
    # Student-t
    t = re.sub(r'Student-t\b', 'Student-*it{t}', t)
    
    # Kupiec & Christoffersen
    t = re.sub(r'Kupiec\s+p\s*=\s*', 'Kupiec *it{p} = ', t)
    t = re.sub(r'Christoffersen\s+p\s*=\s*', 'Christoffersen *it{p} = ', t)
    
    # Test statistics and p-values
    t = re.sub(r'(?<=[(\s,;])t\s*=\s*(-?\d+\.\d+)', r'*it{t} = \1', t)
    t = re.sub(r'(?<=[(\s,;])p\s*=\s*(\d+\.\d+)', r'*it{p} = \1', t)
    t = re.sub(r'(?<=[(\s,;])p\s*<\s*(\d+\.\d+)', r'*it{p} < \1', t)
    t = re.sub(r'(?<=[(\s,;])p\s*>\s*(\d+\.\d+)', r'*it{p} > \1', t)
    t = re.sub(r'(?<=[(\s,;])r\s*=\s*(-?\d+\.\d+)', r'*it{r} = \1', t)
    
    # N sample sizes
    t = re.sub(r'\bN\s*=\s*([0-9,]+)', r'*it{N} = \1', t)
    t = re.sub(r'\(N=([0-9,]+)\)', r'(*it{N} = \1)', t)
    
    # Time variable t
    t = re.sub(r'\bat day t\b', 'at day *it{t}', t)
    
    # Scientific notation in tables/text (e.g. 1e-7 -> 10^-7, 9.01e-06 -> 9.01 × 10^-6)
    t = re.sub(r'\b1e-([0-9]+)\b', r'10^sup{-\1}', t)
    t = re.sub(r'\b(\d+\.\d+)[eE]-0*([0-9]+)\b', r'\1 × 10^sup{-\2}', t)
    
    # Critical values and quantum circuit notation
    t = re.sub(r'z_0\.95\s*=\s*1\.64485', '*it{z}_sub{0.95} = 1.64485', t)
    t = re.sub(r'\bU_ent\b', '*it{U}_sub{ent}', t)
    t = re.sub(r'CNOT_\((\d+,\d+)\)', r'CNOT_sub{(\1)}', t)
    t = re.sub(r'(\\sqrt\{252\}|sqrt\(252\))', '√252', t)
    t = re.sub(r'R_Y\(θ\)\s*=\s*exp\(-i θ Y / 2\)', '*it{R}_sub{Y}(*it{θ}) = exp(−*it{i} *it{θ} *it{Y} / 2)', t)
    t = re.sub(r'\bR_cum\b', '*it{R}_sub{cum}', t)
    t = re.sub(r'\bN_test\b', '*it{N}_sub{test}', t)
    t = re.sub(r'\bR_port,\s*t\b', '*it{R}_sub{port, t}', t)
    t = re.sub(r'\bR_t\b', '*it{R}_sub{t}', t)
    t = re.sub(r'\bDelta\s*GPRD\b', 'ΔGPRD', t)
    t = re.sub(r'\\Delta\s*GPRD', 'ΔGPRD', t)
    t = re.sub(r'\bc\s*=\s*0\.05\b', '*it{c} = 0.05', t)
    t = re.sub(r'\bQLIKE_t\b', 'QLIKE_sub{t}', t)

    return t

def add_equation(doc, omml_body, eq_num_str):
    """
    Creates a borderless 1-row table with centered OMML equation and right-aligned equation number.
    """
    table = doc.add_table(rows=1, cols=2)
    table.autofit = False
    table.columns[0].width = Inches(5.9)
    table.columns[1].width = Inches(0.6)
    
    tblPr = table._element.xpath('w:tblPr')
    if tblPr:
        tblBorders = parse_xml(r'''
            <w:tblBorders %s>
                <w:top w:val="none"/>
                <w:left w:val="none"/>
                <w:bottom w:val="none"/>
                <w:right w:val="none"/>
                <w:insideH w:val="none"/>
                <w:insideV w:val="none"/>
            </w:tblBorders>
        ''' % nsdecls('w'))
        tblPr[0].append(tblBorders)
        
    cell_eq = table.cell(0, 0)
    cell_num = table.cell(0, 1)
    
    p_eq = cell_eq.paragraphs[0]
    p_eq.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_eq.paragraph_format.space_before = Pt(4)
    p_eq.paragraph_format.space_after = Pt(4)
    
    omml_xml = f'''<m:oMath xmlns:m="http://schemas.openxmlformats.org/officeDocument/2006/math">{omml_body}</m:oMath>'''
    omath = parse_xml(omml_xml)
    p_eq._p.append(omath)
    
    p_num = cell_num.paragraphs[0]
    p_num.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p_num.paragraph_format.space_before = Pt(4)
    p_num.paragraph_format.space_after = Pt(4)
    r_num = p_num.add_run(eq_num_str)
    r_num.font.name = 'Cambria Math'
    r_num.font.size = Pt(11)
    r_num.font.color.rgb = RGBColor(0x33, 0x33, 0x33)

EQUATIONS = {
    # Eq 1: R_t = 100 \times \ln(P_t^{adj} / P_{t-1}^{adj})
    1: '''
<m:sSub><m:e><m:r><m:t>R</m:t></m:r></m:e><m:sub><m:r><m:t>t</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> = 100 × ln</m:t></m:r>
<m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:e>
  <m:f>
    <m:num><m:sSubSup><m:e><m:r><m:t>P</m:t></m:r></m:e><m:sub><m:r><m:t>t</m:t></m:r></m:sub><m:sup><m:r><m:t>adj</m:t></m:r></m:sup></m:sSubSup></m:num>
    <m:den><m:sSubSup><m:e><m:r><m:t>P</m:t></m:r></m:e><m:sub><m:r><m:t>t−1</m:t></m:r></m:sub><m:sup><m:r><m:t>adj</m:t></m:r></m:sup></m:sSubSup></m:den>
  </m:f>
</m:e></m:d>
''',

    # Eq 2: Vol_{t,5} = alpha + beta_1 Vol_{t-1,5} + beta_2 GPRD_{t-1} + beta_3 \Delta GPRD_{t-1} + beta_4 GPR_AI_{t-1} + \gamma VIX_{t-1} + \varepsilon_t
    2: '''
<m:sSub><m:e><m:r><m:t>Vol</m:t></m:r></m:e><m:sub><m:r><m:t>t,5</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> = α + </m:t></m:r>
<m:sSub><m:e><m:r><m:t>β</m:t></m:r></m:e><m:sub><m:r><m:t>1</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> </m:t></m:r>
<m:sSub><m:e><m:r><m:t>Vol</m:t></m:r></m:e><m:sub><m:r><m:t>t−1,5</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> + </m:t></m:r>
<m:sSub><m:e><m:r><m:t>β</m:t></m:r></m:e><m:sub><m:r><m:t>2</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> </m:t></m:r>
<m:sSub><m:e><m:r><m:t>GPRD</m:t></m:r></m:e><m:sub><m:r><m:t>t−1</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> + </m:t></m:r>
<m:sSub><m:e><m:r><m:t>β</m:t></m:r></m:e><m:sub><m:r><m:t>3</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> Δ</m:t></m:r>
<m:sSub><m:e><m:r><m:t>GPRD</m:t></m:r></m:e><m:sub><m:r><m:t>t−1</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> + </m:t></m:r>
<m:sSub><m:e><m:r><m:t>β</m:t></m:r></m:e><m:sub><m:r><m:t>4</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> </m:t></m:r>
<m:sSub><m:e><m:r><m:t>GPR_AI</m:t></m:r></m:e><m:sub><m:r><m:t>t−1</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> + γ </m:t></m:r>
<m:sSub><m:e><m:r><m:t>VIX</m:t></m:r></m:e><m:sub><m:r><m:t>t−1</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> + </m:t></m:r>
<m:sSub><m:e><m:r><m:t>ε</m:t></m:r></m:e><m:sub><m:r><m:t>t</m:t></m:r></m:sub></m:sSub>
''',

    # Eq 3: GARCH(1,1): \sigma_t^2 = \omega + \alpha \varepsilon_{t-1}^2 + \beta \sigma_{t-1}^2
    3: '''
<m:r><m:t>GARCH(1,1):   </m:t></m:r>
<m:sSubSup><m:e><m:r><m:t>σ</m:t></m:r></m:e><m:sub><m:r><m:t>t</m:t></m:r></m:sub><m:sup><m:r><m:t>2</m:t></m:r></m:sup></m:sSubSup>
<m:r><m:t> = ω + α </m:t></m:r>
<m:sSubSup><m:e><m:r><m:t>ε</m:t></m:r></m:e><m:sub><m:r><m:t>t−1</m:t></m:r></m:sub><m:sup><m:r><m:t>2</m:t></m:r></m:sup></m:sSubSup>
<m:r><m:t> + β </m:t></m:r>
<m:sSubSup><m:e><m:r><m:t>σ</m:t></m:r></m:e><m:sub><m:r><m:t>t−1</m:t></m:r></m:sub><m:sup><m:r><m:t>2</m:t></m:r></m:sup></m:sSubSup>
''',

    # Eq 4: EGARCH(1,1): \ln(\sigma_t^2) = \omega + \alpha ( |\varepsilon_{t-1}/\sigma_{t-1}| - \sqrt{2/\pi} ) + \gamma (\varepsilon_{t-1}/\sigma_{t-1}) + \beta \ln(\sigma_{t-1}^2)
    4: '''
<m:r><m:t>EGARCH(1,1):   ln</m:t></m:r>
<m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:e>
  <m:sSubSup><m:e><m:r><m:t>σ</m:t></m:r></m:e><m:sub><m:r><m:t>t</m:t></m:r></m:sub><m:sup><m:r><m:t>2</m:t></m:r></m:sup></m:sSubSup>
</m:e></m:d>
<m:r><m:t> = ω + α </m:t></m:r>
<m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:e>
  <m:d><m:dPr><m:begChr m:val="|"/><m:endChr m:val="|"/></m:dPr><m:e>
    <m:f><m:num><m:sSub><m:e><m:r><m:t>ε</m:t></m:r></m:e><m:sub><m:r><m:t>t−1</m:t></m:r></m:sub></m:sSub></m:num><m:den><m:sSub><m:e><m:r><m:t>σ</m:t></m:r></m:e><m:sub><m:r><m:t>t−1</m:t></m:r></m:sub></m:sSub></m:den></m:f>
  </m:e></m:d>
  <m:r><m:t> − </m:t></m:r>
  <m:rad><m:radPr><m:degHide m:val="1"/></m:radPr><m:deg/><m:e><m:f><m:num><m:r><m:t>2</m:t></m:r></m:num><m:den><m:r><m:t>π</m:t></m:r></m:den></m:f></m:e></m:rad>
</m:e></m:d>
<m:r><m:t> + γ </m:t></m:r>
<m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:e>
  <m:f><m:num><m:sSub><m:e><m:r><m:t>ε</m:t></m:r></m:e><m:sub><m:r><m:t>t−1</m:t></m:r></m:sub></m:sSub></m:num><m:den><m:sSub><m:e><m:r><m:t>σ</m:t></m:r></m:e><m:sub><m:r><m:t>t−1</m:t></m:r></m:sub></m:sSub></m:den></m:f>
</m:e></m:d>
<m:r><m:t> + β ln</m:t></m:r>
<m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:e>
  <m:sSubSup><m:e><m:r><m:t>σ</m:t></m:r></m:e><m:sub><m:r><m:t>t−1</m:t></m:r></m:sub><m:sup><m:r><m:t>2</m:t></m:r></m:sup></m:sSubSup>
</m:e></m:d>
''',

    # Eq 5: GJR-GARCH(1,1): \sigma_t^2 = \omega + ( \alpha + \gamma \mathbb{I}_{(\varepsilon_{t-1} < 0)} ) \varepsilon_{t-1}^2 + \beta \sigma_{t-1}^2
    5: '''
<m:r><m:t>GJR-GARCH(1,1):   </m:t></m:r>
<m:sSubSup><m:e><m:r><m:t>σ</m:t></m:r></m:e><m:sub><m:r><m:t>t</m:t></m:r></m:sub><m:sup><m:r><m:t>2</m:t></m:r></m:sup></m:sSubSup>
<m:r><m:t> = ω + </m:t></m:r>
<m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:e>
  <m:r><m:t>α + γ </m:t></m:r>
  <m:sSub><m:e><m:r><m:t>𝕀</m:t></m:r></m:e><m:sub><m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:e><m:sSub><m:e><m:r><m:t>ε</m:t></m:r></m:e><m:sub><m:r><m:t>t−1</m:t></m:r></m:sub></m:sSub><m:r><m:t> &lt; 0</m:t></m:r></m:e></m:d></m:sub></m:sSub>
</m:e></m:d>
<m:r><m:t> </m:t></m:r>
<m:sSubSup><m:e><m:r><m:t>ε</m:t></m:r></m:e><m:sub><m:r><m:t>t−1</m:t></m:r></m:sub><m:sup><m:r><m:t>2</m:t></m:r></m:sup></m:sSubSup>
<m:r><m:t> + β </m:t></m:r>
<m:sSubSup><m:e><m:r><m:t>σ</m:t></m:r></m:e><m:sub><m:r><m:t>t−1</m:t></m:r></m:sub><m:sup><m:r><m:t>2</m:t></m:r></m:sup></m:sSubSup>
''',

    # Eq 6: HAR-RV: RV_t = \beta_0 + \beta_d RV_{t-1} + \beta_w RV_{t-1}^{(w)} + \beta_m RV_{t-1}^{(m)} + \varepsilon_t
    6: '''
<m:r><m:t>HAR-RV:   </m:t></m:r>
<m:sSub><m:e><m:r><m:t>RV</m:t></m:r></m:e><m:sub><m:r><m:t>t</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> = </m:t></m:r>
<m:sSub><m:e><m:r><m:t>β</m:t></m:r></m:e><m:sub><m:r><m:t>0</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> + </m:t></m:r>
<m:sSub><m:e><m:r><m:t>β</m:t></m:r></m:e><m:sub><m:r><m:t>d</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> </m:t></m:r>
<m:sSub><m:e><m:r><m:t>RV</m:t></m:r></m:e><m:sub><m:r><m:t>t−1</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> + </m:t></m:r>
<m:sSub><m:e><m:r><m:t>β</m:t></m:r></m:e><m:sub><m:r><m:t>w</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> </m:t></m:r>
<m:sSubSup><m:e><m:r><m:t>RV</m:t></m:r></m:e><m:sub><m:r><m:t>t−1</m:t></m:r></m:sub><m:sup><m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:e><m:r><m:t>w</m:t></m:r></m:e></m:d></m:sup></m:sSubSup>
<m:r><m:t> + </m:t></m:r>
<m:sSub><m:e><m:r><m:t>β</m:t></m:r></m:e><m:sub><m:r><m:t>m</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> </m:t></m:r>
<m:sSubSup><m:e><m:r><m:t>RV</m:t></m:r></m:e><m:sub><m:r><m:t>t−1</m:t></m:r></m:sub><m:sup><m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:e><m:r><m:t>m</m:t></m:r></m:e></m:d></m:sup></m:sSubSup>
<m:r><m:t> + </m:t></m:r>
<m:sSub><m:e><m:r><m:t>ε</m:t></m:r></m:e><m:sub><m:r><m:t>t</m:t></m:r></m:sub></m:sSub>
''',

    # Eq 7: U(x) = U_{ent} ( \bigotimes_{k=1}^4 R_Y(x_k) )
    7: '''
<m:r><m:t>U(</m:t></m:r>
<m:r><m:rPr><m:b/></m:rPr><m:t>x</m:t></m:r>
<m:r><m:t>) = </m:t></m:r>
<m:sSub><m:e><m:r><m:t>U</m:t></m:r></m:e><m:sub><m:r><m:t>ent</m:t></m:r></m:sub></m:sSub>
<m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:e>
  <m:nary><m:naryPr><m:chr m:val="⨂"/><m:limLoc m:val="undOvr"/></m:naryPr><m:sub><m:r><m:t>k=1</m:t></m:r></m:sub><m:sup><m:r><m:t>4</m:t></m:r></m:sup><m:e>
    <m:sSub><m:e><m:r><m:t>R</m:t></m:r></m:e><m:sub><m:r><m:t>Y</m:t></m:r></m:sub></m:sSub>
    <m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:e><m:sSub><m:e><m:r><m:t>x</m:t></m:r></m:e><m:sub><m:r><m:t>k</m:t></m:r></m:sub></m:sSub></m:e></m:d>
  </m:e></m:nary>
</m:e></m:d>
''',

    # Eq 8: K_Q(x_i, x_j) = |<0000| U^\dagger(x_i) U(x_j) |0000>|^2
    8: '''
<m:sSub><m:e><m:r><m:t>K</m:t></m:r></m:e><m:sub><m:r><m:t>Q</m:t></m:r></m:sub></m:sSub>
<m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:e>
  <m:sSub><m:e><m:r><m:rPr><m:b/></m:rPr><m:t>x</m:t></m:r></m:e><m:sub><m:r><m:t>i</m:t></m:r></m:sub></m:sSub>
  <m:r><m:t>, </m:t></m:r>
  <m:sSub><m:e><m:r><m:rPr><m:b/></m:rPr><m:t>x</m:t></m:r></m:e><m:sub><m:r><m:t>j</m:t></m:r></m:sub></m:sSub>
</m:e></m:d>
<m:r><m:t> = </m:t></m:r>
<m:sSup><m:e>
  <m:d><m:dPr><m:begChr m:val="|"/><m:endChr m:val="|"/></m:dPr><m:e>
    <m:r><m:t>⟨0000| </m:t></m:r>
    <m:sSup><m:e><m:r><m:t>U</m:t></m:r></m:e><m:sup><m:r><m:t>†</m:t></m:r></m:sup></m:sSup>
    <m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:e><m:sSub><m:e><m:r><m:rPr><m:b/></m:rPr><m:t>x</m:t></m:r></m:e><m:sub><m:r><m:t>i</m:t></m:r></m:sub></m:sSub></m:e></m:d>
    <m:r><m:t> U</m:t></m:r>
    <m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:e><m:sSub><m:e><m:r><m:rPr><m:b/></m:rPr><m:t>x</m:t></m:r></m:e><m:sub><m:r><m:t>j</m:t></m:r></m:sub></m:sSub></m:e></m:d>
    <m:r><m:t> |0000⟩</m:t></m:r>
  </m:e></m:d>
</m:e><m:sup><m:r><m:t>2</m:t></m:r></m:sup></m:sSup>
''',

    # Eq 9: K_{reg} = K_Q + \lambda I
    9: '''
<m:sSub><m:e><m:r><m:t>K</m:t></m:r></m:e><m:sub><m:r><m:t>reg</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> = </m:t></m:r>
<m:sSub><m:e><m:r><m:t>K</m:t></m:r></m:e><m:sub><m:r><m:t>Q</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> + λ I</m:t></m:r>
''',

    # Eq 10: RV_{t,5} = \sqrt{ \frac{1}{4} \sum_{k=0}^4 (R_{t-k} - \bar{R}_{t,5})^2 }
    10: '''
<m:sSub><m:e><m:r><m:t>RV</m:t></m:r></m:e><m:sub><m:r><m:t>t,5</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> = </m:t></m:r>
<m:rad><m:radPr><m:degHide m:val="1"/></m:radPr><m:deg/><m:e>
  <m:f><m:num><m:r><m:t>1</m:t></m:r></m:num><m:den><m:r><m:t>4</m:t></m:r></m:den></m:f>
  <m:nary><m:naryPr><m:chr m:val="∑"/><m:limLoc m:val="undOvr"/></m:naryPr><m:sub><m:r><m:t>k=0</m:t></m:r></m:sub><m:sup><m:r><m:t>4</m:t></m:r></m:sup><m:e>
    <m:sSup><m:e>
      <m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:e>
        <m:sSub><m:e><m:r><m:t>R</m:t></m:r></m:e><m:sub><m:r><m:t>t−k</m:t></m:r></m:sub></m:sSub>
        <m:r><m:t> − </m:t></m:r>
        <m:sSub><m:e><m:r><m:t>R̄</m:t></m:r></m:e><m:sub><m:r><m:t>t,5</m:t></m:r></m:sub></m:sSub>
      </m:e></m:d>
    </m:e><m:sup><m:r><m:t>2</m:t></m:r></m:sup></m:sSup>
  </m:e></m:nary>
</m:e></m:rad>
''',

    # Eq 11: VaR_{0.95, t}^{GARCH} = \hat{\mu} + \hat{\sigma}_t ( -t_{\hat{\nu}}^{-1}(0.05) \sqrt{(\hat{\nu}-2)/\hat{\nu}} )
    11: '''
<m:sSubSup><m:e><m:r><m:t>VaR</m:t></m:r></m:e><m:sub><m:r><m:t>0.95, t</m:t></m:r></m:sub><m:sup><m:r><m:t>GARCH</m:t></m:r></m:sup></m:sSubSup>
<m:r><m:t> = μ̂ + </m:t></m:r>
<m:sSub><m:e><m:r><m:t>σ̂</m:t></m:r></m:e><m:sub><m:r><m:t>t</m:t></m:r></m:sub></m:sSub>
<m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:e>
  <m:r><m:t>− </m:t></m:r>
  <m:sSubSup><m:e><m:r><m:t>t</m:t></m:r></m:e><m:sub><m:r><m:t>ν̂</m:t></m:r></m:sub><m:sup><m:r><m:t>−1</m:t></m:r></m:sup></m:sSubSup>
  <m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:e><m:r><m:t>0.05</m:t></m:r></m:e></m:d>
  <m:rad><m:radPr><m:degHide m:val="1"/></m:radPr><m:deg/><m:e>
    <m:f><m:num><m:r><m:t>ν̂ − 2</m:t></m:r></m:num><m:den><m:r><m:t>ν̂</m:t></m:r></m:den></m:f>
  </m:e></m:rad>
</m:e></m:d>
''',

    # Eq 12: VaR_{0.95, t}^{ML} = 1.64485 \times \hat{\sigma}_t
    12: '''
<m:sSubSup><m:e><m:r><m:t>VaR</m:t></m:r></m:e><m:sub><m:r><m:t>0.95, t</m:t></m:r></m:sub><m:sup><m:r><m:t>ML</m:t></m:r></m:sup></m:sSubSup>
<m:r><m:t> = 1.64485 × </m:t></m:r>
<m:sSub><m:e><m:r><m:t>σ̂</m:t></m:r></m:e><m:sub><m:r><m:t>t</m:t></m:r></m:sub></m:sSub>
''',

    # Eq 13: QLIKE_t = V_t^{obs} / \hat{V}_t - \ln(V_t^{obs} / \hat{V}_t) - 1
    13: '''
<m:sSub><m:e><m:r><m:t>QLIKE</m:t></m:r></m:e><m:sub><m:r><m:t>t</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> = </m:t></m:r>
<m:f>
  <m:num><m:sSubSup><m:e><m:r><m:t>V</m:t></m:r></m:e><m:sub><m:r><m:t>t</m:t></m:r></m:sub><m:sup><m:r><m:t>obs</m:t></m:r></m:sup></m:sSubSup></m:num>
  <m:den><m:sSub><m:e><m:r><m:t>V̂</m:t></m:r></m:e><m:sub><m:r><m:t>t</m:t></m:r></m:sub></m:sSub></m:den>
</m:f>
<m:r><m:t> − ln</m:t></m:r>
<m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:e>
  <m:f>
    <m:num><m:sSubSup><m:e><m:r><m:t>V</m:t></m:r></m:e><m:sub><m:r><m:t>t</m:t></m:r></m:sub><m:sup><m:r><m:t>obs</m:t></m:r></m:sup></m:sSubSup></m:num>
    <m:den><m:sSub><m:e><m:r><m:t>V̂</m:t></m:r></m:e><m:sub><m:r><m:t>t</m:t></m:r></m:sub></m:sSub></m:den>
  </m:f>
</m:e></m:d>
<m:r><m:t> − 1</m:t></m:r>
''',

    # Eq 14: w_t = \min( \sigma_{target} / \hat{\sigma}_t^{ann}, w_{max} ), \quad R_{port, t} = w_t R_t - c |w_t - w_{t-1}|
    14: '''
<m:sSub><m:e><m:r><m:t>w</m:t></m:r></m:e><m:sub><m:r><m:t>t</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> = min</m:t></m:r>
<m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:e>
  <m:f>
    <m:num><m:sSub><m:e><m:r><m:t>σ</m:t></m:r></m:e><m:sub><m:r><m:t>target</m:t></m:r></m:sub></m:sSub></m:num>
    <m:den><m:sSubSup><m:e><m:r><m:t>σ̂</m:t></m:r></m:e><m:sub><m:r><m:t>t</m:t></m:r></m:sub><m:sup><m:r><m:t>ann</m:t></m:r></m:sup></m:sSubSup></m:den>
  </m:f>
  <m:r><m:t>, </m:t></m:r>
  <m:sSub><m:e><m:r><m:t>w</m:t></m:r></m:e><m:sub><m:r><m:t>max</m:t></m:r></m:sub></m:sSub>
</m:e></m:d>
<m:r><m:t>,        </m:t></m:r>
<m:sSub><m:e><m:r><m:t>R</m:t></m:r></m:e><m:sub><m:r><m:t>port, t</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> = </m:t></m:r>
<m:sSub><m:e><m:r><m:t>w</m:t></m:r></m:e><m:sub><m:r><m:t>t</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> </m:t></m:r>
<m:sSub><m:e><m:r><m:t>R</m:t></m:r></m:e><m:sub><m:r><m:t>t</m:t></m:r></m:sub></m:sSub>
<m:r><m:t> − c · </m:t></m:r>
<m:d><m:dPr><m:begChr m:val="|"/><m:endChr m:val="|"/></m:dPr><m:e>
  <m:sSub><m:e><m:r><m:t>w</m:t></m:r></m:e><m:sub><m:r><m:t>t</m:t></m:r></m:sub></m:sSub>
  <m:r><m:t> − </m:t></m:r>
  <m:sSub><m:e><m:r><m:t>w</m:t></m:r></m:e><m:sub><m:r><m:t>t−1</m:t></m:r></m:sub></m:sSub>
</m:e></m:d>
''',

    # Eq 15: CAGR = ( 1 + R_{cum}/100 )^{252 / N_{test}} - 1
    15: '''
<m:r><m:t>CAGR = </m:t></m:r>
<m:sSup>
  <m:e>
    <m:d><m:dPr><m:begChr m:val="("/><m:endChr m:val=")"/></m:dPr><m:e>
      <m:r><m:t>1 + </m:t></m:r>
      <m:f>
        <m:num><m:sSub><m:e><m:r><m:t>R</m:t></m:r></m:e><m:sub><m:r><m:t>cum</m:t></m:r></m:sub></m:sSub></m:num>
        <m:den><m:r><m:t>100</m:t></m:r></m:den>
      </m:f>
    </m:e></m:d>
  </m:e>
  <m:sup>
    <m:f>
      <m:num><m:r><m:t>252</m:t></m:r></m:num>
      <m:den><m:sSub><m:e><m:r><m:t>N</m:t></m:r></m:e><m:sub><m:r><m:t>test</m:t></m:r></m:sub></m:sSub></m:den>
    </m:f>
  </m:sup>
</m:sSup>
<m:r><m:t> − 1</m:t></m:r>
'''
}

def add_styled_excel_table(doc, wb, sheet_name, caption):
    if sheet_name not in wb.sheetnames:
        return
    ws = wb[sheet_name]
    all_rows = list(ws.iter_rows(values_only=True))
    if not all_rows:
        return
        
    if len(all_rows) > 2 and all_rows[0][0] and str(all_rows[0][0]).startswith("Table "):
        headers = list(all_rows[2])
        data_rows = all_rows[3:]
    else:
        headers = list(all_rows[0])
        data_rows = all_rows[1:]
        
    if headers and (headers[0] is None or str(headers[0]).strip() == '' or str(headers[0]).lower() == 'nan'):
        headers[0] = 'Model / Variable'
        
    p_cap = doc.add_paragraph()
    p_cap.paragraph_format.space_before = Pt(12)
    p_cap.paragraph_format.space_after = Pt(4)
    p_cap.paragraph_format.keep_with_next = True
    run_cap = p_cap.add_run(caption)
    run_cap.font.name = 'Calibri'
    run_cap.font.size = Pt(11)
    run_cap.font.bold = True
    run_cap.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D)
    
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    
    hdr_cells = table.rows[0].cells
    for i, h in enumerate(headers):
        h_str = "" if h is None else str(h)
        cell = hdr_cells[i]
        set_cell_background(cell, '1F497D')
        set_cell_margins(cell, top=120, bottom=120, left=140, right=140)
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        formatted_h = format_math_markup(h_str)
        parse_and_add_runs(p, formatted_h, default_font='Calibri', default_size=Pt(9.5), default_color=RGBColor(0xFF, 0xFF, 0xFF), bold_all=True)
            
    for row_idx, row_vals in enumerate(data_rows):
        row_cells = table.add_row().cells
        is_even = (row_idx % 2 == 0)
        bg_color = 'F2F5F8' if is_even else 'FFFFFF'
        
        for col_idx, val in enumerate(row_vals):
            cell = row_cells[col_idx]
            set_cell_background(cell, bg_color)
            set_cell_margins(cell, top=80, bottom=80, left=120, right=120)
            
            p = cell.paragraphs[0]
            col_name = str(headers[col_idx]) if col_idx < len(headers) and headers[col_idx] is not None else ""
            
            if val is None or str(val).strip().lower() == 'nan':
                txt = "--"
                align = WD_ALIGN_PARAGRAPH.CENTER
            elif isinstance(val, (int, float)):
                if isinstance(val, int) or (isinstance(val, float) and val.is_integer() and col_name in ['Observations', '95% VaR Breaches', 'Breaches', 'Observations (Trading Days)', 'QSVR 95% VaR Breaches', 'VaR Breaches', 'Matrix Rank']):
                    txt = f"{int(val):,}"
                    align = WD_ALIGN_PARAGRAPH.RIGHT
                elif abs(val) < 0.0001 and val != 0:
                    txt = f"{val:.2e}"
                    align = WD_ALIGN_PARAGRAPH.RIGHT
                elif abs(val) < 1.0:
                    txt = f"{val:.4f}"
                    align = WD_ALIGN_PARAGRAPH.RIGHT
                elif abs(val) < 100.0:
                    txt = f"{val:.4f}"
                    align = WD_ALIGN_PARAGRAPH.RIGHT
                else:
                    txt = f"{val:,.2f}"
                    align = WD_ALIGN_PARAGRAPH.RIGHT
            else:
                txt = str(val)
                align = WD_ALIGN_PARAGRAPH.LEFT
                
            p.alignment = align
            formatted_txt = format_math_markup(txt)
            parse_and_add_runs(p, formatted_txt, default_font='Calibri', default_size=Pt(9.5))
                
    p_sp = doc.add_paragraph()
    p_sp.paragraph_format.space_before = Pt(0)
    p_sp.paragraph_format.space_after = Pt(6)

def add_styled_table(doc, headers, data_rows, caption):
    p_cap = doc.add_paragraph()
    p_cap.paragraph_format.space_before = Pt(12)
    p_cap.paragraph_format.space_after = Pt(4)
    p_cap.paragraph_format.keep_with_next = True
    run_cap = p_cap.add_run(caption)
    run_cap.font.name = 'Calibri'
    run_cap.font.size = Pt(11)
    run_cap.font.bold = True
    run_cap.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D)
    
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    
    hdr_cells = table.rows[0].cells
    for i, h in enumerate(headers):
        cell = hdr_cells[i]
        set_cell_background(cell, '1F497D')
        set_cell_margins(cell, top=120, bottom=120, left=140, right=140)
        p = cell.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        formatted_h = format_math_markup(str(h))
        parse_and_add_runs(p, formatted_h, default_font='Calibri', default_size=Pt(9.5), default_color=RGBColor(0xFF, 0xFF, 0xFF), bold_all=True)
            
    for row_idx, row_vals in enumerate(data_rows):
        row_cells = table.add_row().cells
        is_even = (row_idx % 2 == 0)
        bg_color = 'F2F5F8' if is_even else 'FFFFFF'
        
        for col_idx, val in enumerate(row_vals):
            cell = row_cells[col_idx]
            set_cell_background(cell, bg_color)
            set_cell_margins(cell, top=80, bottom=80, left=120, right=120)
            p = cell.paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT
            formatted_txt = format_math_markup(str(val))
            parse_and_add_runs(p, formatted_txt, default_font='Calibri', default_size=Pt(9.5))
                
    p_sp = doc.add_paragraph()
    p_sp.paragraph_format.space_before = Pt(0)
    p_sp.paragraph_format.space_after = Pt(6)

def add_figure_to_docx(doc, image_path, caption, width_inches=6.2):
    if not os.path.exists(image_path):
        print(f"Warning: image path not found: {image_path}")
        return
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.keep_with_next = True
    run = p.add_run()
    run.add_picture(image_path, width=Inches(width_inches))
    
    p_cap = doc.add_paragraph()
    p_cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_cap.paragraph_format.space_before = Pt(2)
    p_cap.paragraph_format.space_after = Pt(14)
    run_cap = p_cap.add_run(caption)
    run_cap.font.name = 'Calibri'
    run_cap.font.size = Pt(9.5)
    run_cap.font.italic = True
    run_cap.font.color.rgb = RGBColor(0x33, 0x33, 0x33)

def add_heading_1(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(18)
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.keep_with_next = True
    run = p.add_run(text)
    run.font.name = 'Calibri'
    run.font.size = Pt(14)
    run.font.bold = True
    run.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D)

def add_heading_2(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(14)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.keep_with_next = True
    run = p.add_run(text)
    run.font.name = 'Calibri'
    run.font.size = Pt(12)
    run.font.bold = True
    run.font.color.rgb = RGBColor(0x2E, 0x75, 0xB6)

def add_body_p(doc, text):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.line_spacing = 1.15
    formatted_text = format_math_markup(text)
    parse_and_add_runs(p, formatted_text, default_font='Calibri', default_size=Pt(11))

def build_composite_panels():
    fig1_panel = "figures/figure_01_market_dynamics_panel.png"
    fig2_panel = "figures/figure_02_comovement_correlation_panel.png"
    
    if not os.path.exists(fig1_panel) or not os.path.exists(fig2_panel):
        imgs1 = [Image.open(f"figures/{f}") for f in [
            "figure_01_wti_price.png", "figure_02_wti_returns.png",
            "figure_03_wti_volatility.png", "figure_04_gpr.png"
        ]]
        w1 = max(im.width for im in imgs1)
        h1 = max(im.height for im in imgs1)
        r1 = [im.resize((w1, h1), Image.Resampling.LANCZOS) for im in imgs1]
        c1 = Image.new('RGB', (w1 * 2, h1 * 2), (255, 255, 255))
        c1.paste(r1[0], (0, 0))
        c1.paste(r1[1], (w1, 0))
        c1.paste(r1[2], (0, h1))
        c1.paste(r1[3], (w1, h1))
        c1.save(fig1_panel, dpi=(300, 300))
        
        imgs2 = [Image.open(f"figures/{f}") for f in [
            "figure_05_gpr_oil_volatility.png", "figure_06_correlation.png"
        ]]
        w2 = max(im.width for im in imgs2)
        h2 = max(im.height for im in imgs2)
        r2 = [im.resize((w2, h2), Image.Resampling.LANCZOS) for im in imgs2]
        c2 = Image.new('RGB', (w2 * 2, h2), (255, 255, 255))
        c2.paste(r2[0], (0, 0))
        c2.paste(r2[1], (w2, 0))
        c2.save(fig2_panel, dpi=(300, 300))

def main():
    print("=== Generating Full Academic Word Document (.docx) for Journal of Commodity Markets ===")
    build_composite_panels()
    
    doc = docx.Document()
    
    for section in doc.sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)
        
    wb = openpyxl.load_workbook("tables.xlsx")
    
    # Title Block
    p_title = doc.add_paragraph()
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_title.paragraph_format.space_before = Pt(18)
    p_title.paragraph_format.space_after = Pt(12)
    t_run = p_title.add_run("Quantum Kernel Methods for Crude Oil Volatility Forecasting under Geopolitical Risk: A Controlled Out-of-Sample Benchmark")
    t_run.font.name = 'Calibri'
    t_run.font.size = Pt(17)
    t_run.font.bold = True
    t_run.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D)
    
    # Authors - Ordered exactly per journal submission requirements:
    # 1. Hamood Amur Al Wardi
    # 2. Uvesh Husain
    # 3. Shylaja H N (Corresponding Author)
    # 4. Ram Soorat
    # 5. Priyanka
    # 6. Afzalur Rahman
    p_auth = doc.add_paragraph()
    p_auth.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_auth.paragraph_format.space_after = Pt(14)
    
    r1 = p_auth.add_run("Hamood Amur Al Wardi\n")
    r1.font.bold = True
    r1.font.size = Pt(11)
    p_auth.add_run("Economics and Business Studies Department, Mazoon College, Muscat, Sultanate of Oman\nEmail: omaniconsul@gmail.com | ORCID: 0009-0006-5697-5159\n\n").font.size = Pt(9.5)
    
    r2 = p_auth.add_run("Uvesh Husain\n")
    r2.font.bold = True
    r2.font.size = Pt(11)
    p_auth.add_run("Economics and Business Studies Department, Mazoon College, Muscat, Sultanate of Oman\nEmail: u78.husain@gmail.com | ORCID: 0000-0002-8502-8488\n\n").font.size = Pt(9.5)
    
    r3 = p_auth.add_run("Shylaja H N (Corresponding Author)\n")
    r3.font.bold = True
    r3.font.size = Pt(11)
    p_auth.add_run("Manipal Institute of Commerce Finance and Economics, Manipal Academy of Higher Education, Manipal, India\nEmail: shylaja.hn@manipal.edu | ORCID: 0000-0001-9807-8575\n\n").font.size = Pt(9.5)
    
    r4 = p_auth.add_run("Ram Soorat\n")
    r4.font.bold = True
    r4.font.size = Pt(11)
    p_auth.add_run("School of Technology, Woxsen University, Kamkole, Hyderabad 502345, Telangana, India\nEmail: rsoorat@gmail.com | ORCID: 0000-0001-7875-9197\n\n").font.size = Pt(9.5)
    
    r5 = p_auth.add_run("Priyanka\n")
    r5.font.bold = True
    r5.font.size = Pt(11)
    p_auth.add_run("Department of Physics and Astrophysics, University of Delhi, Delhi 110007, India\nEmail: priyanka292c@gmail.com | ORCID: 0009-0008-1520-0706\n\n").font.size = Pt(9.5)
    
    r6 = p_auth.add_run("Afzalur Rahman\n")
    r6.font.bold = True
    r6.font.size = Pt(11)
    p_auth.add_run("School of Business, Woxsen University, Kamkole, Hyderabad 502345, Telangana, India\nEmail: afzalur.rahman@woxsen.edu.in | ORCID: 0000-0002-1561-561X\n").font.size = Pt(9.5)
    
    doc.add_page_break()
    
    # Abstract
    add_heading_1(doc, "Abstract")
    add_body_p(doc, "Forecasting crude oil volatility under geopolitical uncertainty is vital for energy asset pricing, macro-risk surveillance, and financial hedging. This study presents a comprehensive out-of-sample empirical benchmark comparing a 4-qubit Parameterized Quantum Circuit (PQC) kernel regression model (QSVR) against twelve classical benchmark models (yielding thirteen models in total)---including a Heterogeneous Autoregressive rolling-volatility model (HAR-RV-type, Corsi, 2009), GARCH(1,1), EGARCH(1,1), and GJR-GARCH(1,1)---as well as classical machine learning regressors (ElasticNet, Linear/Poly/RBF SVR, Random Forest, XGBoost, LightGBM, and PyTorch LSTM).")
    add_body_p(doc, "Using a ten-year daily dataset (2016--2026, N = 2,473 clean trading days) incorporating daily newspaper-based Geopolitical Risk (GPRD), AI-based Geopolitical Risk (AI-GPR), and cross-asset macroeconomic controls, models produce one-day-ahead forecasts of a five-day rolling volatility proxy observed at day t (rather than five-day-ahead forecasts of future volatility) and are evaluated across a 655-day out-of-sample window (2024--2026). Our empirical results establish five core findings:")
    add_body_p(doc, "(1) Multi-component autoregressive models (HAR-RV-type, RMSE = 0.6708, R2 = 0.7800) and regularized linear shrinkage (SVR-Linear, RMSE = 0.6717; ElasticNet, RMSE = 0.7017) achieve the lowest point-forecasting RMSE under symmetric loss, whereas tree ensembles achieve the lowest asymmetric variance-penalizing loss (XGBoost, QLIKE = 0.1574).")
    add_body_p(doc, "(2) In a controlled 4-feature experiment where quantum and classical kernel machines operate on identical inputs, the 4-qubit quantum kernel (RMSE = 0.7007, R2 = 0.7600) outperforms classical Gaussian RBF kernel regression (RMSE = 0.7140, R2 = 0.7508), providing empirical evidence of a distinct nonlinear representation under the controlled identical-input setting that is competitive with, and statistically improves upon, the matched Gaussian RBF specification in this controlled setting, though linear models still maintain the lowest point error.")
    add_body_p(doc, "(3) While the 4-qubit quantum kernel achieves competitive point accuracy, pairwise Diebold-Mariano tests with Benjamini-Hochberg False Discovery Rate (FDR) adjustments confirm that quantum kernel simulation on classical hardware does not offer statistically significant point-forecast superiority over strong linear benchmarks (pFDR = 0.1712), reframing the contribution as an empirical kernel representation study rather than a computational quantum advantage.")
    add_body_p(doc, "(4) In the full multivariate econometric specification with Newey-West HAC standard errors, lagged daily GPR does not retain statistical significance (beta = 0.0008, t = 1.4243, p = 0.1544; Variance Inflation Factors < 3.0) after controlling for volatility persistence (beta = 0.8860, t = 22.35, p < 0.0001) and equity market volatility (VIX, beta = 0.0250, t = 3.68, p = 0.0002); in XGBoost, the lagged volatility feature accounts for 96.56% of normalized permutation importance, while GPR variables receive relatively small individual importance weights, suggesting that GPR may be more informative for regime stratification and stress-period analysis than for incremental daily point forecasting.")
    add_body_p(doc, "(5) In formal 95% Value-at-Risk (VaR) backtesting with model-consistent innovation distributions, parametric Student-t GARCH(1,1) and GJR-GARCH models achieve near-nominal unconditional coverage (4.73%--4.89% breaches, passing Kupiec POF tests with p > 0.75), whereas EGARCH is overly conservative (2.90% breaches, Kupiec p = 0.0077) and QSVR is under-calibrated (7.79% breaches, Kupiec p = 0.0024) despite providing no statistical evidence against the temporal independence null hypothesis in Christoffersen tests (p = 0.5904).")
    
    p_kw = doc.add_paragraph()
    p_kw.paragraph_format.space_before = Pt(8)
    p_kw.paragraph_format.space_after = Pt(4)
    r_kwh = p_kw.add_run("Keywords: ")
    r_kwh.bold = True
    p_kw.add_run("Crude Oil Volatility, Rolling Volatility, Geopolitical Risk, Quantum Machine Learning, Quantum Kernel Regression, HAR-RV-type, Value-at-Risk, Kupiec Test, Christoffersen Test, Forecast Evaluation.")
    
    p_jel = doc.add_paragraph()
    p_jel.paragraph_format.space_before = Pt(0)
    p_jel.paragraph_format.space_after = Pt(12)
    r_jelh = p_jel.add_run("JEL Classification: ")
    r_jelh.bold = True
    p_jel.add_run("C22, C53, C58, G17, Q41, Q47.")
    
    doc.add_page_break()
    
    # 1. Introduction
    add_heading_1(doc, "1. Introduction")
    add_body_p(doc, "Crude oil is the cornerstone of global industrial production, transportation networks, and petrochemical supply chains. Consequently, unexpected disruptions and violent price swings in crude oil markets transmit profound shocks throughout the global macroeconomy, influencing sovereign inflation trajectories, monetary policy decisions, and international equity market stability (Hamilton, 2003). As demonstrated in structural macroeconomic analyses, energy price fluctuations reflect a complex combination of global demand shifts, precautionary stockpiling, and supply shocks (Kilian, 2009; Baumeister & Kilian, 2016). Furthermore, structural transmission mechanisms highlight that the economic impact of crude oil supply disruptions exhibits pronounced macroeconomic asymmetries (Balke et al., 2002). In recent years, escalating geopolitical tensions---spanning the 2022--2026 Russia-Ukraine war, maritime transit disruptions in the Red Sea, and heightened Middle Eastern conflicts---have severely amplified crude oil price instability and risk transmission across international financial systems (Mignon & Saadaoui, 2024; Abdelmalek & Khemakhem, 2026). Predicting crude oil volatility accurately, while incorporating cross-market information from global benchmarks, is therefore a fundamental objective for energy risk managers, derivatives trading desks, and macroeconomic surveillance authorities (Alqahtani et al., 2020; Alqahtani & Klein, 2021).")
    add_body_p(doc, "In energy econometrics, conditional variance modeling has traditionally relied on Generalized Autoregressive Conditional Heteroskedasticity (GARCH) specifications (Engle, 1982; Bollerslev, 1986). Subsequent developments introduced asymmetric news impact curves to capture leverage effects (Nelson, 1991; Engle & Ng, 1993), alongside threshold formulations such as GJR-GARCH (Glosten et al., 1993). In comprehensive empirical benchmarks, standard low-order GARCH models have demonstrated strong forecasting performance against competing specifications (Hansen & Lunde, 2005). Foundational volatility modeling established that financial asset and commodity returns exhibit prominent volatility clustering, long-memory persistence, and conditional heteroskedasticity (Bollerslev et al., 1992; Ding et al., 1993). While standard econometric frameworks capture these empirical properties, they often struggle when processing high-dimensional, multi-source exogenous signals---such as real-time textual geopolitical risk indices and cross-asset macroeconomic controls---without encountering parameter proliferation and in-sample overfitting (Smales, 2021; Bouoiyour et al., 2019). Furthermore, modern text analytics has rapidly evolved from keyword-based frequency metrics (Baker et al., 2016; Caldara & Iacoviello, 2022) to advanced Large Language Model (LLM) semantic extractions (Iacoviello et al., 2026), creating rich multidimensional data streams whose dynamic predictive contribution remains an active empirical debate (Jin et al., 2023; Li et al., 2023).")
    add_body_p(doc, "In parallel, the intersection of quantum information science and statistical computation has produced Quantum Machine Learning (QML) as an active area of empirical investigation for high-dimensional pattern recognition (Biamonte et al., 2017). Comprehensive surveys and taxonomies have examined quantum computing applications across risk analysis, derivative pricing, and financial time-series modeling (Herman et al., 2023; Egger et al., 2020; Orús et al., 2019; Peral-García et al., 2024; Doosti et al., 2026). Empirical applications have emerged in quantum kernel estimation (Havlíček et al., 2019; Schuld & Killoran, 2019; Anai et al., 2024), expressive quantum architectures (Abbas et al., 2021; Jerbi et al., 2023), and financial time-series tasks (Ranilla-Cortina et al., 2026). In particular, Parameterized Quantum Circuit (PQC) kernel methods map classical input data into high-dimensional Hilbert spaces via non-linear unitary operations, computing inner-product kernel matrices through quantum state fidelity overlaps (Huang et al., 2021; Cerezo et al., 2021; Dinuț et al., 2026).")
    add_body_p(doc, "A secondary finding of this study is that geopolitical risk indices contribute primarily to regime stratification rather than incremental daily point forecasting: in the XGBoost specification, the lagged volatility feature accounts for 96.56% of normalized permutation importance, while GPR variables do not achieve statistical significance in the full dynamic specification (p > 0.15). The central empirical question motivating this paper is therefore: Does a quantum-kernel representation provide incremental forecasting or economic value in crude oil volatility forecasting when geopolitical risk and financial controls are considered?")
    add_body_p(doc, "This paper presents a controlled out-of-sample empirical benchmark comparing a 4-qubit PennyLane Quantum Support Vector Regression (QSVR) model against twelve classical econometric and machine learning benchmarks across a 10-year daily historical sample (2016--2026, N = 2,473 clean trading days) with an explicit 655-day test window (2024--2026). Replication code, PennyLane quantum circuit implementations, and publicly distributable derived empirical datasets are openly accessible at https://github.com/rsoorat/Quantum-Oil-GPR-Benchmark.")
    
    # 2. Literature Review
    add_heading_1(doc, "2. Literature Review")
    add_heading_2(doc, "2.1 Crude Oil Volatility Dynamics and Geopolitical Risk")
    add_body_p(doc, "Geopolitical tensions and policy uncertainty have emerged as vital determinants of global commodity market dynamics. Following the development of text-based economic policy uncertainty indices (Baker et al., 2016), Caldara and Iacoviello (2022) introduced daily and monthly Geopolitical Risk (GPR) indices based on automated newspaper article counts, showing that geopolitical escalations trigger sharp contractions in macroeconomic investment and substantial surges in commodity market volatility. To address keyword-matching limitations, Iacoviello et al. (2026) recently introduced the Artificial Intelligence Geopolitical Risk (AI-GPR) index, leveraging Large Language Models to evaluate nuanced semantic context and isolate energy supply threat channels (GPR_OIL).")
    add_body_p(doc, "A rapidly expanding literature investigates the transmission mechanisms of geopolitical shocks to energy markets. Jin et al. (2023) document substantial dynamic risk spillovers between geopolitical uncertainty and energy commodities across varying time frequencies. Li et al. (2023) and Gong and Xu (2022) reveal that while geopolitical shocks transmit rapidly through crude oil markets via precautionary demand and supply fear channels, their out-of-sample predictive stability varies considerably over time. Furthermore, Bouri (2023) demonstrates that crude oil implied volatility acts as a primary transmission conduit linking geopolitical risk to broader financial sectors during major regional conflicts.")
    add_body_p(doc, "Recent empirical studies highlight that the market impact of geopolitical risk is highly heterogeneous and non-linear, documenting heterogeneous and time-varying spillover effects across commodity and energy markets, particularly during periods of heightened geopolitical stress (Smales, 2021; Bouoiyour et al., 2019). Mignon and Saadaoui (2024) find that political tensions and geopolitical risks serve as complementary causal drivers of crude oil price shocks, with political relationships shaping demand expectations while geopolitical threats influence supply disruption fears. Lee et al. (2024) document non-linear threshold dynamics, wherein geopolitical risks generate asymmetric pressures depending on the underlying macro-energy regime. Evaluating predictive content directly, empirical investigations establish that geopolitical indicators enhance crude oil volatility forecasting predominantly during high-stress market regimes (Laubsch et al., 2024; Bouri et al., 2026). Expanding this insight across market quantiles, Bouri et al. (2026) show that frequency connectedness between geopolitical risk and crude oil volatility peaks under extreme tail-market conditions, motivating flexible non-linear and regime-sensitive modeling frameworks (Alqahtani & Klein, 2021; Laubsch et al., 2024).")
    
    add_heading_2(doc, "2.2 Econometric Volatility Modeling and Realized Volatility")
    add_body_p(doc, "In financial econometrics, conditional heteroskedasticity is conventionally modeled through ARCH and GARCH frameworks (Engle, 1982; Bollerslev, 1986), with asymmetric leverage dynamics captured by EGARCH (Nelson, 1991) and GJR-GARCH (Glosten et al., 1993). With the availability of continuous intra-day price feeds, realized volatility emerged as a non-parametric, model-free estimator of integrated variance (Andersen et al., 2003). To bridge multi-scale temporal dynamics, Corsi (2009) formulated the Heterogeneous Autoregressive framework. While originally formulated for high-frequency realized volatility (HAR-RV), the multi-horizon structure can be adapted to daily-return rolling volatility proxies (Laubsch et al., 2024). For rigorous forecast comparison, Patton (2011) establishes important conditions under which MSE and QLIKE are robust loss functions for volatility forecast evaluation against noisy proxies, while Diebold and Mariano (1995) and Harvey et al. (1997) established standard predictive accuracy tests.")
    
    add_heading_2(doc, "2.3 Machine Learning and Quantum Methods in Financial Modeling")
    add_body_p(doc, "The integration of machine learning into financial economics has expanded significantly. Support Vector Regression provides a robust margin-based framework for non-linear time-series modeling (Vapnik, 1995). Penalized shrinkage methods such as Lasso (Tibshirani, 1996) and ElasticNet (Zou & Hastie, 2005) enforce parameter sparsity and stability under collinearity. Tree-based ensemble methods, including Random Forests (Breiman, 2001), XGBoost (Chen & Guestrin, 2016), and LightGBM (Ke et al., 2017), capture complex non-linear interactions and structural breaks. Recurrent neural architectures such as Long Short-Term Memory (LSTM) networks capture sequential dependencies (Hochreiter & Schmidhuber, 1997).")
    add_body_p(doc, "In parallel, Quantum Machine Learning investigates whether quantum computational mechanics can enhance statistical pattern recognition (Biamonte et al., 2017). In the NISQ era, Parameterized Quantum Circuits serve as hybrid quantum-classical learning architectures (Cerezo et al., 2021). Havlíček et al. (2019) and Schuld and Killoran (2019) established that supervised QML can be naturally represented as kernel estimation in quantum Hilbert spaces. Extending beyond simple feature embeddings, Jerbi et al. (2023) demonstrated that linear quantum models and data re-uploading circuits provide distinct inductive biases and expressive capacities relative to classical kernel methods. Theoretical investigations have analyzed the expressive capacity and power of data in quantum learning (Huang et al., 2021; Abbas et al., 2021). Using open-source differentiable quantum frameworks like PennyLane (Bergholm et al., 2018), this study conducts a transparent and rigorous controlled empirical evaluation of quantum-kernel representation methods in crude oil volatility modeling (Liu et al., 2020).")
    
    # 3. Theoretical Framework
    add_heading_1(doc, "3. Theoretical Framework, Hypotheses, and Research Question")
    add_body_p(doc, "Building on the econometric and quantum machine learning literature, we formulate four formal testable hypotheses (H1, H2, and tail-risk components H5a and H5b under the Value-at-Risk evaluation framework H5), one comparative research question (RQ3), and one complementary descriptive quantum-kernel diagnostic (D1):")
    add_body_p(doc, "H1 (Geopolitical Risk Incremental Significance): We test whether lagged daily geopolitical risk indices (GPRD, AI-GPR) exert a statistically significant positive effect (beta > 0, p < 0.05) on the 5-day rolling volatility proxy in a dynamic econometric specification after controlling for persistence with Newey-West HAC standard errors.")
    add_body_p(doc, "H2 (Asymmetric Return Innovation Dynamics): Asymmetric volatility specifications will exhibit statistically significant responses to return innovations (gamma != 0, p < 0.05). In GJR-GARCH, leverage implies gamma > 0, whereas in Nelson's (1991) EGARCH, asymmetry implies gamma < 0, with both formulations testing whether negative crude oil return shocks generate greater volatility surges than positive shocks of identical magnitude.")
    add_body_p(doc, "RQ3 (Comparative Forecasting Performance): How does quantum kernel regression compare with econometric, linear, and nonlinear machine-learning benchmarks in out-of-sample crude oil volatility forecasting under identical information sets?")
    add_body_p(doc, "Quantum Geometry Diagnostic (D1): As a complementary descriptive diagnostic rather than a formal inferential hypothesis, we analyze Kernel-Target Alignment A(K, y), Gram matrix effective dimension, numerical rank, and condition number for each kernel to characterize quantum-versus-classical representational geometry in finite samples.")
    add_body_p(doc, "H5a (Violation Independence): VaR violations exhibit no statistically significant temporal dependence, satisfying the Christoffersen independence test null hypothesis (p > 0.05).")
    add_body_p(doc, "H5b (Unconditional Coverage): The model achieves statistically adequate 95% VaR unconditional coverage, failing to reject the Kupiec proportion of failures null hypothesis (p > 0.05). A model that fails unconditional coverage cannot be considered well-calibrated for risk management, even if the independence null is not rejected.")
    
    # 4. Data and Variables
    add_heading_1(doc, "4. Data, Variables, and Descriptive Statistics")
    add_body_p(doc, "Our empirical dataset covers a ten-year historical span from August 18, 2016, to August 18, 2026. Following an initial 22-trading-day initialization window required to construct monthly rolling components for HAR-RV-type and lagged predictors, the final clean dataset comprises N = 2,473 daily trading observations (September 27, 2016 to August 18, 2026).")
    add_body_p(doc, "The primary dependent variable is the 5-day rolling volatility proxy (calculated as the sample standard deviation of daily percentage log returns) of WTI crude oil spot returns obtained directly from the Federal Reserve Bank of St. Louis Economic Data repository (FRED, Series DCOILWTICO, reflecting the U.S. Energy Information Administration Cushing spot price series). Daily percentage log returns are calculated continuously across the full sample:")
    
    # Equation 1: Daily log returns
    add_equation(doc, EQUATIONS[1], "(1)")
    
    add_body_p(doc, "The raw FRED DCOILWTICO series contains an extraordinary negative price observation of -$36.98/barrel on April 20, 2020, which coincided with the historic settlement collapse of prompt May 2020 NYMEX WTI futures at -$37.63/barrel due to Cushing storage exhaustion. Because logarithmic returns are undefined for non-positive prices, we evaluate three transparent computational transformations of this observation for log-return construction: baseline continuous linear interpolation, observation exclusion, and shifted-price transformation. For the baseline interpolation, the negative April 20, 2020 observation was replaced by the arithmetic mean of the immediately adjacent observations from the identical FRED DCOILWTICO series (April 17, 2020: $18.31/bbl and April 21, 2020: $8.91/bbl), yielding an adjusted computational baseline value of $13.61/bbl. Crucially, all values used in the negative-price transformation were taken directly from the same downloaded primary series used to construct returns; no adjacent observations from different contract months or unrelated futures series were substituted. We emphasize that interpolation is strictly a computational transformation used for continuous log-return construction, rather than an attempt to economically reconstruct a real physical transaction price. Sensitivity analysis in Table 2 confirms that substantive forecasting rankings remain stable across all three treatments.")
    add_styled_excel_table(doc, wb, 'NegativePriceSensitivity', "Table 2: Sensitivity Analysis: Treatment of April 20, 2020 WTI Negative Price Event")
    
    add_body_p(doc, "All feature-scaling and min-max normalization parameters were estimated exclusively using the training data (2016--2022) and then applied unchanged to validation and test observations.")
    add_body_p(doc, "To capture geopolitical risk, we incorporate daily newspaper-based Geopolitical Risk (GPRD) indices and daily Artificial Intelligence Geopolitical Risk (AI-GPR) indices constructed by Matteo Iacoviello (Caldara & Iacoviello, 2022; Iacoviello & Tong, 2026). We include the aggregate GPRD index, the AI-GPR index, and the oil-specific AI geopolitical risk subindex (GPR_OIL). Unlike traditional dictionary-based or keyword-matching text methods that rely on static keyword frequencies, the AI-GPR framework developed by Iacoviello and Tong (2026) leverages modern Large Language Models (LLMs) and transformer-based Natural Language Processing (NLP) architectures to analyze global news archives. By assessing complete contextual syntax and semantic nuance, the LLM classifier differentiates rhetorical posturing from actionable military threats, bilateral conflicts, and geopolitical hostilities. In addition, the oil-specific AI subindex (GPR_OIL) isolates text passages directly mentioning petroleum infrastructure, naval transit chokepoints (such as the Strait of Hormuz, Bab el-Mandeb, and the Suez Canal), pipeline networks, and OPEC+ geopolitical negotiations.")
    add_body_p(doc, "Table 1 summarizes the empirical variables, descriptions, measurement units, and data sources.")
    
    add_styled_excel_table(doc, wb, 'VariableDefinitions', "Table 1: Variable Definitions and Empirical Data Sources")
    
    add_body_p(doc, "Chronological sample splitting details (N = 2,473 trading days) partitioned into training (2016–2022), validation (2023), and out-of-sample test (2024–2026) sets are reported in Table 3.")
    add_styled_excel_table(doc, wb, 'SampleSplits', "Table 3: Chronological Sample Splitting Details (2016–2026, N = 2,473 Trading Days)")
    
    add_body_p(doc, "Table 4 presents the descriptive statistics for core volatility and exogenous risk variables across the 2016–2026 sample period.")
    add_styled_excel_table(doc, wb, 'DescriptiveStats', "Table 4: Descriptive Statistics for Core Volatility and Exogenous Risk Variables")
    
    # Detailed in-text narrative referencing Figure 1 (A-D)
    add_body_p(doc, "Figure 1 illustrates the ten-year empirical dynamics of the crude oil market and geopolitical risk indicators across four comprehensive panels (Panels A–D). Specifically, Figure 1(A) displays the daily spot price trajectory of WTI crude oil, highlighting the collapse into negative territory in April 2020 during the COVID-19 pandemic demand shock, followed by the rapid commodity super-cycle rally that peaked above $120/bbl following the February 2022 Russian invasion of Ukraine. Figure 1(B) plots the corresponding daily percentage log returns of WTI crude oil, illustrating severe return dispersion and volatility clustering where tranquil trading regimes are periodically interrupted by violent return shocks. Figure 1(C) details the primary target variable of this investigation: the 5-day rolling volatility proxy, which captures acute localized standard deviation surges reaching up to 33.86% annualized equivalent. Figure 1(D) exhibits the daily newspaper-based Geopolitical Risk index (GPRD) alongside the Large Language Model-based Artificial Intelligence Geopolitical Risk index (AI-GPR), documenting sharp geopolitical escalations during the 2022 Russia-Ukraine war, the 2023–2024 Middle Eastern hostilities, and Red Sea maritime transit crises.")
    
    # Embed Figure 1 immediately after its narrative discussion
    add_figure_to_docx(doc, "figures/figure_01_market_dynamics_panel.png", 
                       "Figure 1: WTI Crude Oil Market Dynamics and Geopolitical Risk Indices (2016–2026, N = 2,473). (A) Daily Spot Price, (B) Percentage Daily Log Returns, (C) 5-Day Rolling Volatility Proxy, (D) Daily Geopolitical Risk Indices (GPRD and AI-GPR).", 
                       width_inches=6.5)
    
    # Detailed in-text narrative referencing Figure 2 (A-B)
    add_body_p(doc, "Figure 2 depicts the bivariate co-movement and cross-asset correlation structure governing the empirical dataset across two panels (Panels A–B). As demonstrated in Figure 2(A), the dynamic co-movement between the 5-day rolling volatility proxy and the daily geopolitical risk index reveals that while major systemic geopolitical escalations coincide with prominent volatility surges, localized headline risk spikes frequently occur during tranquil market regimes without transmitting sustained volatility into crude oil pricing. Figure 2(B) presents the Pearson correlation heatmap across all core predictors and controls, documenting strong positive co-movement between crude oil rolling volatility and equity market implied volatility (VIX, r = 0.5547) and Brent volatility, alongside a modest positive unconditional correlation with daily GPR (r = 0.0715). Multicollinearity diagnostics confirm that Variance Inflation Factors (VIF) remain well below 3.0 across all variables (GPRD = 2.96, AI-GPR = 2.52, Vol_Lag1 = 1.47, VIX = 1.45), indicating that collinearity does not compromise the stability of coefficient estimates.")
    
    # Embed Figure 2 immediately after its narrative discussion
    add_figure_to_docx(doc, "figures/figure_02_comovement_correlation_panel.png", 
                       "Figure 2: Geopolitical Risk Co-movement and Correlation Structure. (A) Co-movement between 5-Day Rolling Volatility Proxy and Geopolitical Risk, (B) Pearson Correlation Heatmap across Predictor Variables.", 
                       width_inches=6.5)
    
    add_body_p(doc, "Table 5 reports the Pearson correlation matrix across all core predictor variables and cross-asset financial controls.")
    add_styled_excel_table(doc, wb, 'Correlations', "Table 5: Pearson Correlation Matrix across Core Predictor Variables")
    
    add_body_p(doc, "To formally test Hypothesis H1, Table 6 reports the multivariate OLS regression of the 5-day rolling volatility proxy on lagged geopolitical risk indices with Newey-West HAC standard errors (5 lags):")
    
    # Equation 2: Dynamic OLS regression
    add_equation(doc, EQUATIONS[2], "(2)")
    
    add_styled_excel_table(doc, wb, 'H1_Regression', "Table 6: Multivariate Econometric OLS Regression of 5-Day Rolling Volatility Proxy on Lagged GPR (Testing H1)")
    
    # 5. Methodology
    add_heading_1(doc, "5. Econometric, Machine Learning, and Quantum Methodology")
    add_body_p(doc, "Our empirical methodology systematically benchmarks classical econometrics against modern Artificial Intelligence (AI) and Quantum Artificial Intelligence (QAI) paradigms under a strictly controlled out-of-sample framework. Specifically, the model space spans three distinct algorithmic tiers: (i) classical parametric and semi-parametric econometric specifications (GARCH, EGARCH, GJR-GARCH, and the Heterogeneous Autoregressive model of Realized Volatility, HAR-RV-type); (ii) classical Artificial Intelligence and machine learning architectures, including regularized linear shrinkage (ElasticNet), kernel Support Vector Machines (Linear, Polynomial, and Gaussian RBF SVR), tree-based gradient boosting and ensemble learning (Random Forest, XGBoost, and LightGBM), and deep recurrent neural networks (PyTorch Long Short-Term Memory, LSTM); and (iii) Quantum Artificial Intelligence, instantiated via a 4-qubit Parameterized Quantum Circuit (PQC) kernel machine operating in an exponentially expanded Hilbert feature space. By evaluating all AI, ML, and econometric baselines over an identical chronological information horizon, we ensure fair and transparent attribution of predictive performance across linear, nonlinear classical AI, and quantum kernel representations.")
    add_body_p(doc, "We benchmark four econometric specifications (GARCH, EGARCH, GJR-GARCH, HAR-RV-type), six classical ML algorithms (ElasticNet, Linear/Poly/RBF SVR, Random Forest, XGBoost, LightGBM), deep learning PyTorch LSTM, and the 4-qubit PennyLane QSVR model.")
    add_body_p(doc, "We estimate three parametric GARCH-family specifications under standardized Student-t innovation distributions alongside Corsi's (2009) HAR-RV framework:")
    
    # Equations 3, 4, 5, 6: Volatility specifications
    add_equation(doc, EQUATIONS[3], "(3)")
    add_equation(doc, EQUATIONS[4], "(4)")
    add_equation(doc, EQUATIONS[5], "(5)")
    add_equation(doc, EQUATIONS[6], "(6)")
    
    add_body_p(doc, "where 𝕀_(·) is an indicator function. In GJR-GARCH, the asymmetric leverage parameter is positive and statistically significant (gamma = 0.0527, t = 2.2154, p = 0.0267). In EGARCH, the asymmetric leverage parameter is negative and statistically significant (gamma = -0.0433, t = -2.6560, p = 0.0079), confirming that negative return shocks generate larger surges in conditional log-variance than positive shocks of identical magnitude, supporting Hypothesis H2 for both asymmetric specifications.")
    add_body_p(doc, "Table 7 summarizes baseline econometric parameter estimates across the four conditional volatility specifications.")
    add_styled_excel_table(doc, wb, 'EconometricSummary', "Table 7: Econometric Baseline Parameter Estimates: GARCH(1,1), EGARCH(1,1), GJR-GARCH(1,1), and HAR-RV-type")
    
    add_body_p(doc, "All machine learning hyperparameters were optimized strictly on the 248-day validation partition (2023). Table 8 details the validation hyperparameter configurations.")
    add_styled_excel_table(doc, wb, 'MLConfigs', "Table 8: Classical Machine Learning Benchmark Hyperparameter Configurations")
    
    # Detailed in-text narrative referencing Figure 3
    add_body_p(doc, "Figure 3 details the architecture of the 4-qubit Parameterized Quantum Circuit (PQC) used for feature mapping and quantum kernel fidelity estimation. As shown in Figure 3, four ex ante selected normalized financial features (x1 = Vol_Lag1, x2 = GPRD_Lag1, x3 = VIX_Lag1, x4 = Return_Lag1) are mapped onto four qubits via single-qubit Pauli-Y rotation gates Ry(xk) applied to the initial ground state |0000>:")
    
    # Equation 7: Feature map unitary
    add_equation(doc, EQUATIONS[7], "(7)")
    
    add_body_p(doc, "where R_Y(θ) = exp(-i θ Y / 2) and U_ent = CNOT_(3,0) CNOT_(2,3) CNOT_(1,2) CNOT_(0,1) implements circular entanglement (Havlíček et al., 2019; Schuld & Killoran, 2019). The quantum transition fidelity between quantum state representations, defined by the absolute squared inner product, evaluates the Gram kernel matrix KQ:")
    
    # Equation 8: Quantum transition fidelity
    add_equation(doc, EQUATIONS[8], "(8)")
    
    add_body_p(doc, "To ensure strict positive definiteness and numerical regularity in the dual quadratic programming solver, a Tikhonov ridge regularization term is added to the Gram matrix:")
    
    # Equation 9: Tikhonov regularization
    add_equation(doc, EQUATIONS[9], "(9)")
    
    add_body_p(doc, "with lambda = 1e-5.")
    
    # Embed Figure 3 immediately after its narrative discussion
    add_figure_to_docx(doc, "figures/figure_quantum_circuit.png", 
                       "Figure 3: 4-Qubit Parameterized Quantum Circuit (PQC) Architecture for Feature Mapping and Quantum Kernel Fidelity Estimation.", 
                       width_inches=6.5)
    
    add_body_p(doc, "Table 9 details the quantum circuit architecture, gate decomposition, and simulation parameters.")
    add_styled_excel_table(doc, wb, 'QuantumConfigs', "Table 9: Quantum Support Vector Regression Architecture Specification")
    
    add_body_p(doc, "Table 10 reports the geometric properties, effective dimension, numerical rank, and kernel-target alignment of quantum and classical kernels.")
    add_styled_excel_table(doc, wb, 'KernelProperties', "Table 10: Quantum vs. Classical Kernel Geometric Properties and Target Alignment")
    
    add_body_p(doc, "Table 11 reports the numerical stability and Tikhonov ridge regularization sensitivity analysis for the quantum Gram matrix across regularization parameters lambda in [1e-7, 1e-1].")
    add_styled_excel_table(doc, wb, 'QuantumRegSensitivity', "Table 11: Numerical Stability and Tikhonov Ridge Regularization Sensitivity Analysis for QSVR Gram Matrix")
    
    add_body_p(doc, "Quantum Kernel Rank: The empirical quantum Gram matrix achieves an effective numerical rank of 67, exceeding the single-state Hilbert space dimension d=16 because the fidelity kernel acts on density operators residing in the d^2 = 256-dimensional space of Hermitian operators (see Supplementary Appendix A for mathematical derivations). This rank reflects a distinct finite-sample geometric structure rather than inherent predictive superiority: Gaussian RBF achieves a higher rank (239) yet performs worse out-of-sample, whereas regularized linear models (rank 4) achieve the lowest point error.")
    add_body_p(doc, "Forecasting Timeline & Horizon: The models produce one-day-ahead forecasts of a five-day rolling volatility proxy observed at day t, rather than five-day-ahead forecasts of future volatility. Under local conditional stationarity over the 5-day rolling window, the rolling volatility proxy forecast acts as an estimator of the daily conditional standard deviation scale:")
    
    # Equation 10: 5-day rolling volatility proxy
    add_equation(doc, EQUATIONS[10], "(10)")
    
    add_body_p(doc, "For Student-t GARCH models, the 95% 1-day Value-at-Risk is calculated using the exact model-consistent Student-t quantile:")
    
    # Equation 11: Student-t GARCH VaR
    add_equation(doc, EQUATIONS[11], "(11)")
    
    add_body_p(doc, "For regression and machine learning models minimizing mean squared error (MSE loss), point forecasts are converted to 95% VaR using the standard empirical Gaussian critical value z_0.95 = 1.64485:")
    
    # Equation 12: Gaussian / ML VaR
    add_equation(doc, EQUATIONS[12], "(12)")
    
    add_body_p(doc, "Statistical Loss Functions: Forecast accuracy is evaluated using Root Mean Squared Error (RMSE), Mean Absolute Error (MAE), and Quasi-Likelihood (QLIKE) loss:")
    
    # Equation 13: QLIKE loss
    add_equation(doc, EQUATIONS[13], "(13)")
    
    add_body_p(doc, "where V_t^{obs} = Vol_{t,5}^2 is the squared 5-day rolling volatility proxy and \\hat{V}_t = \\hat{\\sigma}_t^2 is the squared volatility forecast. Because the target is a standard deviation proxy rather than variance, both observed and predicted volatilities are squared before computing QLIKE, ensuring consistent ranking under asymmetric variance-penalizing loss (Patton, 2011).")
    
    # 6. Empirical Results
    add_heading_1(doc, "6. Empirical Forecasting Results and Ablation Analysis")
    add_body_p(doc, "Table 12 reports the feature ablation study across three predictor subsets. Volatility persistence (Subset 1) accounts for the vast majority of point accuracy. Table 13 reports the controlled 4-feature experiment, where QSVR (RMSE = 0.7007, R2 = 0.7600) achieves lower RMSE than classical Gaussian SVR-RBF (RMSE = 0.7140, R2 = 0.7508) on identical 4-dimensional inputs, although SVR-RBF remains slightly better under asymmetric QLIKE loss (0.1709 vs. 0.1734), while linear models maintain the lowest point errors. Importantly, the controlled RBF comparison uses the same four-feature input set as QSVR and is therefore distinct from the full-feature SVR-RBF benchmark (RMSE = 0.9202) reported in Table 14, where high-dimensional macroeconomic inputs impair kernel generalization.")
    add_styled_excel_table(doc, wb, 'AblationStudy', "Table 12: Feature Ablation Study across Predictor Subsets")
    add_styled_excel_table(doc, wb, 'Controlled4FBenchmark', "Table 13: Controlled 4-Feature Benchmark: Direct Comparison of Quantum vs. Classical Machine Learning on Identical Information Set")
    
    add_body_p(doc, "Table 14 and Table 15 report out-of-sample performance metrics and Diebold-Mariano tests across the 655-day test set. HAR-RV-type (RMSE = 0.6708, R2 = 0.7800) and SVR-Linear (RMSE = 0.6717) achieve the best point forecasts under symmetric RMSE loss, while tree ensembles lead under asymmetric QLIKE loss. QSVR achieves competitive accuracy (RMSE = 0.7007, R2 = 0.7600, QLIKE = 0.1734), matching ElasticNet (pFDR = 0.9604) and HAR-RV-type (pFDR = 0.1712) without statistically significant point differences.")
    
    add_styled_excel_table(doc, wb, 'ModelPerformance', "Table 14: Out-of-Sample Volatility Forecasting Accuracy Metrics Comparison (2024–2026 Test Window, N=655)")
    add_styled_excel_table(doc, wb, 'Key_DM_FDR_Comparisons', "Table 15: Pairwise Diebold-Mariano Predictive Accuracy Tests with HLN Corrections and Benjamini-Hochberg FDR Adjustments")
    
    # Detailed in-text narrative referencing Figure 4 & Figure 5
    add_body_p(doc, "Figure 4 compares the out-of-sample volatility forecast trajectories generated by leading models against the actual 5-day rolling volatility proxy across the 655-day test window (January 2024 to August 2026). As visually documented in Figure 4, all leading models track the primary volatility shifts during the test period. The linear models (HAR-RV-type and SVR-Linear) follow high-frequency volatility movements closely, whereas the 4-qubit QSVR model generates a smooth, highly stable prediction path that captures the underlying conditional variance scale without suffering from destabilizing out-of-sample overreactions.")
    
    # Embed Figure 4 immediately after its narrative discussion
    add_figure_to_docx(doc, "figures/figure_08_actual_vs_predicted.png", 
                       "Figure 4: Out-of-Sample Volatility Forecasts vs. 5-Day Rolling Volatility Proxy (2024–2026 Test Window).", 
                       width_inches=6.2)
    
    add_body_p(doc, "Figure 5 provides a comprehensive visual ranking of out-of-sample Root Mean Squared Error (RMSE) across all thirteen evaluated specifications on the held-out test sample. The graphical hierarchy in Figure 5 clearly confirms that parsimonious linear models (HAR-RV-type, RMSE = 0.6708; SVR-Linear, RMSE = 0.6717; ElasticNet, RMSE = 0.7017) achieve the highest point-forecasting precision under symmetric quadratic loss. The 4-qubit QSVR model (RMSE = 0.7007) demonstrates strong competitiveness against both classical tree ensembles (Random Forest, RMSE = 0.7160; LightGBM, RMSE = 0.7554) and parametric GARCH specifications (GARCH, RMSE = 0.8054), while high-dimensional classical RBF-SVR incurs substantial error (RMSE = 0.9202) due to feature over-parameterization.")
    
    # Embed Figure 5 immediately after its narrative discussion
    add_figure_to_docx(doc, "figures/figure_09_model_comparison.png", 
                       "Figure 5: Out-of-Sample Root Mean Squared Error (RMSE) Model Comparison across All Evaluated Specifications.", 
                       width_inches=6.0)
    
    # 7. Regime & Robustness
    add_heading_1(doc, "7. Geopolitical Risk Regime Analysis and Robustness Checks")
    add_body_p(doc, "Regime thresholds were estimated strictly on the pre-test sample (2016--2023, N = 1,818: Median = 106.77, 75th percentile = 140.53) and held fixed out-of-sample. Table 16 and Table 17 evaluate performance across Low (N=80), Medium (N=162), and High GPR (N=413) regimes, with 95% bootstrap confidence intervals. HAR-RV-type (RMSE = 0.7529) and SVR-Linear (RMSE = 0.7534) remain strongest in the high-GPR regime, while QSVR (RMSE = 0.7872) remains competitive.")
    
    # Detailed in-text narrative referencing Figure 6 & Figure 7
    add_body_p(doc, "Figure 6 illustrates the distribution of out-of-sample test set trading days across the three pre-determined geopolitical risk regimes (Low GPR = 80 days, Medium GPR = 162 days, High GPR = 413 days). The heavy concentration of observations in the High GPR regime (63.05% of the test window) reflects the heightened geopolitical turbulence characterizing 2024–2026, driven by protracted hostilities in Eastern Europe and the Middle East.")
    
    # Embed Figure 6 immediately after its narrative discussion
    add_figure_to_docx(doc, "figures/figure_07_gpr_regimes.png", 
                       "Figure 6: Out-of-Sample Test Set Trading Days across Geopolitical Risk Regimes (N = 655: Low = 80, Medium = 162, High = 413).", 
                       width_inches=5.5)
    
    add_body_p(doc, "Figure 7 displays the forecasting RMSE across Low, Medium, and High geopolitical risk regimes for representative models (HAR-RV-type, GARCH, ElasticNet, SVR-RBF, XGBoost, and QSVR). As shown in Figure 7, forecasting error increases substantially across all specifications during the High GPR regime, demonstrating that headline geopolitical risk introduces considerable unpredictable noise into daily returns. Nevertheless, HAR-RV-type (RMSE = 0.7529) and SVR-Linear (RMSE = 0.7534) demonstrate the greatest robustness under elevated geopolitical stress, with QSVR (RMSE = 0.7872) providing a resilient non-linear alternative that outperforms classical GARCH (RMSE = 0.8878) and full-feature SVR-RBF (RMSE = 1.0601).")
    
    # Embed Figure 7 immediately after its narrative discussion
    add_figure_to_docx(doc, "figures/figure_10_regime_comparison.png", 
                       "Figure 7: Forecasting RMSE across Geopolitical Risk Regimes for Selected Representative Specifications (HAR-RV, GARCH, ElasticNet, SVR-RBF, XGBoost, QSVR).", 
                       width_inches=6.0)
    
    add_styled_excel_table(doc, wb, 'RegimeAnalysis', "Table 16: Out-of-Sample Forecasting RMSE across Geopolitical Risk Regimes (Pre-Test Thresholds with 95% Bootstrap CIs)")
    add_styled_excel_table(doc, wb, 'RobustnessTests', "Table 17: Alternative Geopolitical Risk Percentile Threshold Robustness Checks")
    
    # 8. Explainability
    add_heading_1(doc, "8. Model Explainability and Quantum Sensitivity")
    add_body_p(doc, "Permutation importance analysis indicates that for XGBoost, the lagged volatility feature alone accounts for 96.82% of normalized permutation importance, while individual geopolitical risk variables receive relatively small importance weights: GPR_OIL reaches 1.49%, Brent returns contribute 0.66%, and Gas returns contribute 0.46%. In the QSVR model, wire gradient sensitivity indicates that the first wire (Vol_Lag1) contributes 98.68% of aggregate quantum feature-map wire sensitivity, while the geopolitical wire (GPRD_Lag1) contributes 0.50%.")
    
    # Detailed in-text narrative referencing Figure 8
    add_body_p(doc, "Figure 8 visualizes the top 10 normalized feature importances derived from out-of-sample permutation analysis. As demonstrated in Figure 8, autoregressive volatility persistence overwhelmingly dominates predictive attribution across all machine learning specifications, accounting for more than 96% of aggregate predictive importance, while daily geopolitical risk variables and macroeconomic controls act primarily as secondary conditioning signals.")
    
    # Embed Figure 8 immediately after its narrative discussion
    add_figure_to_docx(doc, "figures/figure_11_shap.png", 
                       "Figure 8: Top 10 Normalized Feature Importances from Permutation Analysis (Dominance of Volatility Persistence).", 
                       width_inches=6.0)
    
    # 9. Risk Management & Portfolio
    add_heading_1(doc, "9. Economic Risk Management and Portfolio Backtesting")
    add_body_p(doc, "Table 18 reports 95% Value-at-Risk backtesting results with associated Expected Shortfall (CVaR) estimates using model-consistent innovation distributions. Parametric Student-t GARCH(1,1) and GJR-GARCH models achieve near-nominal 5% coverage (GARCH: 32 breaches, 4.89%, Kupiec p = 0.8927; GJR: 31 breaches, 4.73%, Kupiec p = 0.7517, supporting H5b), whereas EGARCH is overly conservative (19 breaches, 2.90%, Kupiec p = 0.0077). QSVR and SVR-RBF fail to reject the null hypothesis of independent VaR-hit occurrences (Christoffersen p = 0.5904, consistent with H5a), despite higher unconditional breach rates (7.79%, rejecting H5b for ML models). This divergence reflects the combined effect of volatility forecasting and distributional tail modeling, highlighting that point-volatility forecasts alone do not guarantee well-calibrated tail-risk estimates.")
    
    add_styled_excel_table(doc, wb, 'RiskManagement', "Table 18: Economic Risk Management: 95% Value-at-Risk (VaR) Coverage Backtesting with Associated Expected Shortfall (CVaR) Estimates (Model-Consistent Distributions)")
    
    add_body_p(doc, "Table 19 and Table 20 report volatility-targeting portfolio backtest results (using an illustrative 15% baseline volatility budget, leverage cap w_max = 2.0, and 5 bps baseline transaction costs) with Compound Annual Growth Rates (CAGR) and transaction cost sensitivity. In volatility targeting, daily point volatility forecast \\hat{\\sigma}_t is converted to annualized percentage units via \\hat{\\sigma}_t^{\\text{ann}} = \\hat{\\sigma}_t \\times \\sqrt{252}, and portfolio weights are determined dynamically based on the volatility target:")
    
    # Equation 14: Dynamic volatility targeting portfolio weights and net return
    add_equation(doc, EQUATIONS[14], "(14)")
    
    add_body_p(doc, "with maximum leverage w_max = 2.0, and a baseline transaction cost of c = 5 basis points (0.05%). The Compound Annual Growth Rate (CAGR) is defined as:")
    
    # Equation 15: Compound Annual Growth Rate (CAGR)
    add_equation(doc, EQUATIONS[15], "(15)")
    
    add_body_p(doc, "In volatility targeting, scaling the target volatility linearly scales daily position sizes; sensitivity checks across alternative targets (sigma_target in {10%, 15%, 20%}) show broadly similar performance patterns, with HAR-RV-type leading at 10% and 15% (Sharpe 0.367, 0.298), while QSVR achieves the highest Sharpe ratio at 20% (Sharpe 0.261 vs. 0.252 for HAR-RV-type; Supplementary Table 3). Because returns are expressed in percentage points, transaction costs are represented in the same units (5 basis points corresponds to c = 0.05). Passive WTI produces the highest absolute cumulative return (+20.29%, CAGR = 7.37%), but suffers a severe maximum drawdown of -39.26% and an annualized volatility of 41.23%, yielding a Sharpe ratio of 0.172. In contrast, dynamic volatility-targeting strategies deliberately de-risk during turbulent market regimes, substantially curtailing peak-to-trough losses (-15.11% to -20.91% across leading specifications) and cutting annualized volatility by more than half (18.92%--19.32% across the top three forecasting models, and 13.00%--19.32% across all volatility-targeting strategies). Consequently, while passive buy-and-hold delivers higher raw unhedged returns, leading volatility-targeting models achieve superior risk-adjusted performance (HAR-RV-type Sharpe 0.298, SVR-Linear 0.280, QSVR 0.268). Within the specified volatility-targeting strategy, the economic value of the forecasts is reflected primarily in lower realized portfolio volatility, reduced drawdowns, and improved risk-adjusted performance rather than higher raw returns. HAR-RV-type (+16.09%, CAGR = 5.91%, Sharpe 0.298), SVR-Linear (+15.08%, CAGR = 5.55%, Sharpe 0.280), and QSVR (+14.10%, CAGR = 5.20%, Sharpe 0.268) achieve the highest net returns and Sharpe ratios among the reported volatility-targeting strategies, outperforming the Naïve 20-day historical volatility benchmark (+9.19%, CAGR = 3.44%, Sharpe 0.222). Returns remain positive across cost levels from 1 to 10 bps, remaining positive even at 20 bps.")
    
    add_styled_excel_table(doc, wb, 'PortfolioPerformance', "Table 19: Economic Significance: Volatility-Targeting Portfolio Performance (5 bps Cost, 2.0x Leverage Cap)")
    add_styled_excel_table(doc, wb, 'CostSensitivity', "Table 20: Transaction Cost Sensitivity Analysis for Volatility-Targeting Strategies (1 to 20 bps)")
    
    # Detailed in-text narrative referencing Figure 9
    add_body_p(doc, "Figure 9 plots the cumulative portfolio net return paths under the dynamic daily volatility-targeting asset allocation strategy (15% target volatility, 5 bps transaction cost) over the 2024–2026 test window. As shown in Figure 9, dynamic volatility targeting based on HAR-RV-type, SVR-Linear, and QSVR forecasts substantially outperforms the benchmark strategies on a risk-adjusted basis by systematically reducing exposure during high-volatility turbulence and expanding leverage during calm regimes.")
    
    # Embed Figure 9 immediately after its narrative discussion
    add_figure_to_docx(doc, "figures/figure_12_economic_performance.png", 
                       "Figure 9: Cumulative Portfolio Net Return Curves under Daily Volatility Targeting (15% Target Volatility, 5 bps Transaction Cost).", 
                       width_inches=6.2)
    
    # 10. Discussion & Hypothesis Decisions
    add_heading_1(doc, "10. Discussion, Hypothesis Decisions, and Conclusion")
    add_body_p(doc, "Table 21 summarizes the empirical decisions across the four formal testable hypotheses (H1, H2, H5a, H5b), one comparative research question (RQ3), and one descriptive diagnostic (D1).")
    add_styled_excel_table(doc, wb, 'HypothesisSummary', "Table 21: Summary of Formal Hypothesis Testing Decisions")
    
    add_body_p(doc, "Table 22 provides an evidence-based practitioner decision framework mapping specific financial use cases to optimal model selection.")
    headers_df = ["Decision Objective", "Preferred Model", "Evidence Basis"]
    data_df = [
        ["Point volatility forecast (RMSE)", "HAR-RV-type", "Lowest RMSE=0.6708; DM p>0.84 vs SVR-Linear"],
        ["Linear ML forecast", "SVR-Linear", "RMSE=0.6717; near-identical to the HAR-RV-type model"],
        ["Asymmetric QLIKE forecast", "XGBoost", "Lowest QLIKE=0.1574"],
        ["Tail-risk calibration (VaR)", "GARCH / GJR-GARCH", "4.89% / 4.73% breach rates; Kupiec p>0.75"],
        ["Nonlinear kernel research", "QSVR", "Outperforms RBF-SVR in controlled 4-feature setting"],
        ["Portfolio volatility targeting", "HAR-RV-type", "Highest net return (+16.09%) and Sharpe ratio (0.298); SVR-Linear (+15.08%, Sharpe 0.280) provides strong alternative"],
        ["Regime & stress analysis", "GPR indicators", "Best for regime stratification (63% high-GPR test window)"]
    ]
    add_styled_table(doc, headers_df, data_df, "Table 22: Evidence-Based Practitioner Decision Framework: Model Selection by Objective")
    
    add_body_p(doc, "Our findings demonstrate that HAR-RV-type and linear shrinkage baselines achieve the lowest RMSE in daily volatility point forecasting, while 4-qubit Quantum SVR provides empirical evidence of a distinct nonlinear representation under the controlled identical-input setting that outperforms classical Gaussian RBF-SVR in controlled point forecasting. However, QSVR does not achieve statistically significant predictive superiority over the strongest linear benchmarks (p_FDR = 0.1712). Regarding tail-risk calibration, Student-t GARCH specifications provide the best calibrated VaR estimates under their model-specific innovation assumptions, passing both unconditional and conditional coverage tests, whereas EGARCH is overly conservative and QSVR exhibits an elevated breach rate (7.79%) under Gaussian benchmark assumptions despite no evidence of temporal violation clustering. We emphasize the distinction between quantum kernel simulation on classical hardware and genuine quantum computational advantage. Geopolitical risk measures provide descriptive value for stratifying periods of elevated geopolitical stress and tail-risk analysis rather than serving as primary drivers of daily point volatility. The publicly distributable derived datasets, replication code, quantum circuits, and statistical pipelines are openly available to support full replication of the reported empirical analysis.")
    
    # Declarations
    doc.add_page_break()
    
    # Declaration of Funding (Requirement 3)
    add_heading_1(doc, "Declaration of Funding")
    add_body_p(doc, "No funding was received for this work.")
    
    # Data Availability Statement (Requirement 4)
    add_heading_1(doc, "Data Availability Statement")
    add_body_p(doc, "The publicly distributable derived datasets, replication code, model specifications, and quantum circuits are openly available in the project repository at https://github.com/rsoorat/Quantum-Oil-GPR-Benchmark. Any underlying raw market data subject to third-party licensing restrictions are available from their original providers or from the corresponding author, Shylaja H N, where permitted upon reasonable request at shylaja.hn@manipal.edu.")
    
    # Declaration of Generative AI
    add_heading_1(doc, "Declaration of Generative AI and AI-Assisted Technologies in the Writing Process")
    add_body_p(doc, "During the preparation of this work, the authors used Anthropic Claude and Google DeepMind AI tools in order to assist with code optimization, data processing, and manuscript editing for clarity and formatting. After using these tools, the authors reviewed and edited the content as needed and take full responsibility for the content of the published article.")
    
    # Conflict of Interest Statement
    add_heading_1(doc, "Conflict of Interest Statement")
    add_body_p(doc, "The authors declare that they have no known competing financial interests or personal relationships that could have appeared to influence the work reported in this paper.")
    
    # References
    doc.add_page_break()
    add_heading_1(doc, "References")
    
    with open("references.bib", "r", encoding="utf-8") as f:
        bib_content = f.read()
    entries = re.split(r'@\w+\s*\{', bib_content)[1:]
    refs = []
    for entry in entries:
        fields = {}
        for match in re.finditer(r'(\w+)\s*=\s*[\{](.*?)[}]', entry, re.DOTALL):
            fields[match.group(1).lower()] = match.group(2).strip().replace('\n', ' ')
        author = fields.get('author', '')
        year = fields.get('year', '')
        title = fields.get('title', '').replace('{', '').replace('}', '')
        journal = fields.get('journal', fields.get('booktitle', fields.get('publisher', '')))
        volume = fields.get('volume', '')
        pages = fields.get('pages', '').replace('--', '-')
        doi = fields.get('doi', '')
        howpublished = fields.get('howpublished', '')
        author_list = [a.strip() for a in author.split(' and ')]
        clean_authors = []
        for a in author_list:
            if ',' in a:
                parts = a.split(',')
                last = parts[0].strip()
                first = parts[1].strip()
                inits = '.'.join([p[0] for p in first.split() if p]) + '.'
                clean_authors.append(f'{last}, {inits}')
            else:
                parts = a.split()
                if len(parts) > 1:
                    last = parts[-1]
                    first = ' '.join(parts[:-1])
                    inits = '.'.join([p[0] for p in first.split() if p]) + '.'
                    clean_authors.append(f'{last}, {inits}')
                else:
                    clean_authors.append(a)
        if len(clean_authors) > 2:
            auth_str = ', '.join(clean_authors)
        elif len(clean_authors) == 2:
            auth_str = f'{clean_authors[0]}, {clean_authors[1]}'
        elif clean_authors:
            auth_str = clean_authors[0]
        else:
            auth_str = ''
        ref_line = f'{auth_str}, {year}. {title}.'
        if journal:
            ref_line += f' {journal}'
            if volume:
                ref_line += f' {volume}'
            if pages:
                ref_line += f', {pages}.'
            else:
                ref_line += '.'
        elif howpublished:
            ref_line += f' {howpublished}.'
        if doi:
            ref_line += f' https://doi.org/{doi}'
        refs.append(ref_line)
    refs.sort()
    
    for ref_str in refs:
        p_ref = doc.add_paragraph()
        p_ref.paragraph_format.space_before = Pt(0)
        p_ref.paragraph_format.space_after = Pt(4)
        p_ref.paragraph_format.left_indent = Inches(0.5)
        p_ref.paragraph_format.first_line_indent = Inches(-0.5)
        run_ref = p_ref.add_run(ref_str)
        run_ref.font.name = 'Calibri'
        run_ref.font.size = Pt(10)
        
    out_filename = "Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript.docx"
    doc.save(out_filename)
    print(f"Full Word manuscript generated successfully: {out_filename}")

if __name__ == "__main__":
    main()
