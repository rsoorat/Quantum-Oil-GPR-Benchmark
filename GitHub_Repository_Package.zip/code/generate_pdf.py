import os
import subprocess
import shutil
import win32com.client

def main():
    print("=== Step 16: Generate PDF Manuscript ===")
    
    tex_file = "Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript.tex"
    docx_file = "Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript.docx"
    pdf_file = "Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript.pdf"
    
    # 1. Attempt compiling LaTeX if pdflatex exists
    pdflatex_path = shutil.which("pdflatex")
    if pdflatex_path:
        print(f"pdflatex found at: {pdflatex_path}. Compiling LaTeX manuscript...")
        try:
            # Run pdflatex twice to resolve references/citations
            subprocess.run(["pdflatex", "-interaction=nonstopmode", tex_file], check=True)
            # Run bibtex to resolve citations
            subprocess.run(["bibtex", "Quantum_Enhanced_Oil_Geopolitical_Risk_Manuscript"], check=False)
            subprocess.run(["pdflatex", "-interaction=nonstopmode", tex_file], check=True)
            subprocess.run(["pdflatex", "-interaction=nonstopmode", tex_file], check=True)
            print("Successfully compiled LaTeX to PDF.")
            return
        except subprocess.CalledProcessError as e:
            print(f"pdflatex compilation failed: {e}. Falling back to MS Word PDF conversion...")
    else:
        print("pdflatex compiler not found in system path. Falling back to MS Word PDF conversion...")
        
    # 2. Fallback to MS Word PDF conversion
    print("Attempting MS Word COM PDF generation...")
    try:
        doc_abs_path = os.path.abspath(docx_file)
        pdf_abs_path = os.path.abspath(pdf_file)
        
        if not os.path.exists(doc_abs_path):
            raise FileNotFoundError(f"Source file {docx_file} does not exist. Run code/generate_docx.py first.")
            
        word = win32com.client.Dispatch("Word.Application")
        word.Visible = False
        
        print(f"Opening {docx_file} and saving as PDF...")
        doc = word.Documents.Open(doc_abs_path)
        # wdFormatPDF is 17
        doc.SaveAs(pdf_abs_path, FileFormat=17)
        doc.Close()
        word.Quit()
        
        print(f"Successfully generated PDF: {pdf_file}")
    except Exception as e:
        print(f"MS Word PDF generation failed: {e}")
        print("Please make sure Microsoft Word is installed and the docx manuscript exists.")

if __name__ == "__main__":
    main()
