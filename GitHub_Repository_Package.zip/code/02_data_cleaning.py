import pandas as pd
import numpy as np
import yaml
from statsmodels.tsa.stattools import adfuller
from arch.unitroot import PhillipsPerron
import openpyxl

def main():
    print("=== Step 2: Data Cleaning and Stationarity Testing ===")
    
    # Load configuration
    with open("config.yaml", "r") as f:
        config = yaml.safe_load(f)
        
    start_date = config['data']['start_date']
    end_date = config['data']['end_date']
    
    # 1. Load WTI prices
    print("Loading raw WTI prices...")
    df_wti = pd.read_csv(config['data']['raw_wti_path'])
    df_wti['date'] = pd.to_datetime(df_wti['date'])
    # Alpha Vantage values might contain '.' for missing days
    df_wti['value'] = pd.to_numeric(df_wti['value'], errors='coerce')
    df_wti = df_wti.dropna(subset=['value'])
    df_wti = df_wti.rename(columns={'value': 'WTI'})
    df_wti = df_wti.sort_values('date').drop_duplicates(subset=['date'])
    
    # 2. Load GPR daily index
    print("Loading raw GPR index...")
    df_gpr = pd.read_excel("data/raw_gpr_daily.xls")
    df_gpr['date'] = pd.to_datetime(df_gpr['date'])
    df_gpr = df_gpr[['date', 'GPRD', 'GPRD_ACT', 'GPRD_THREAT']].copy()
    df_gpr = df_gpr.sort_values('date').drop_duplicates(subset=['date'])
    
    # 3. Load AI-GPR daily index
    print("Loading raw AI-GPR index...")
    df_ai_gpr = pd.read_csv("data/raw_ai_gpr_daily.csv")
    df_ai_gpr['Date'] = pd.to_datetime(df_ai_gpr['Date'])
    df_ai_gpr = df_ai_gpr.rename(columns={'Date': 'date'})
    df_ai_gpr = df_ai_gpr[['date', 'GPR_AI', 'GPR_OIL']].copy()
    df_ai_gpr = df_ai_gpr.sort_values('date').drop_duplicates(subset=['date'])
    
    # 4. Load Control variables
    print("Loading raw controls...")
    df_controls = pd.read_csv("data/raw_controls.csv")
    df_controls['Date'] = pd.to_datetime(df_controls['Date'])
    df_controls = df_controls.rename(columns={'Date': 'date'})
    df_controls = df_controls.sort_values('date').drop_duplicates(subset=['date'])
    
    # 5. Merge all datasets
    print("Merging datasets...")
    # Use WTI dates as base
    merged = pd.merge(df_wti, df_gpr, on='date', how='left')
    merged = pd.merge(merged, df_ai_gpr, on='date', how='left')
    merged = pd.merge(merged, df_controls, on='date', how='left')
    
    # Sort chronologically
    merged = merged.sort_values('date').reset_index(drop=True)
    
    # Filter for the selected sample period
    merged = merged[(merged['date'] >= start_date) & (merged['date'] <= end_date)].reset_index(drop=True)
    
    # Handle missing observations (using forward fill then backward fill)
    missing_before = merged.isna().sum().sum()
    print(f"Total missing observations before cleaning: {missing_before}")
    merged = merged.ffill().bfill()
    missing_after = merged.isna().sum().sum()
    print(f"Total missing observations after cleaning: {missing_after}")
    
    # Save cleaned dataset
    merged.to_csv(config['data']['clean_wti_path'], index=False)
    print(f"Cleaned dataset saved to {config['data']['clean_wti_path']}. Shape: {merged.shape}")
    
    # 6. Conduct stationarity tests
    print("\n--- Stationarity Tests (ADF and PP) ---")
    variables_to_test = ['WTI', 'GPRD', 'GPR_AI']
    test_results = []
    
    for var in variables_to_test:
        series = merged[var].values
        # ADF test
        adf_res = adfuller(series, autolag='AIC')
        # PP test
        pp_res = PhillipsPerron(series)
        
        print(f"\nVariable: {var}")
        print(f"  ADF Statistic: {adf_res[0]:.4f} (p-value: {adf_res[1]:.4f})")
        print(f"  PP Statistic: {pp_res.stat:.4f} (p-value: {pp_res.pvalue:.4f})")
        
        test_results.append({
            'Variable': var,
            'ADF_Stat': adf_res[0],
            'ADF_p': adf_res[1],
            'PP_Stat': pp_res.stat,
            'PP_p': pp_res.pvalue,
            'Stationary': "Yes" if adf_res[1] < 0.05 and pp_res.pvalue < 0.05 else "No"
        })
        
    # Test WTI returns
    wti_returns = 100 * np.log(merged['WTI'] / merged['WTI'].shift(1)).dropna().values
    adf_ret = adfuller(wti_returns, autolag='AIC')
    pp_ret = PhillipsPerron(wti_returns)
    print(f"\nVariable: WTI Log Returns")
    print(f"  ADF Statistic: {adf_ret[0]:.4f} (p-value: {adf_ret[1]:.4f})")
    print(f"  PP Statistic: {pp_ret.stat:.4f} (p-value: {pp_ret.pvalue:.4f})")
    
    test_results.append({
        'Variable': 'WTI_Returns',
        'ADF_Stat': adf_ret[0],
        'ADF_p': adf_ret[1],
        'PP_Stat': pp_ret.stat,
        'PP_p': pp_ret.pvalue,
        'Stationary': "Yes" if adf_ret[1] < 0.05 and pp_ret.pvalue < 0.05 else "No"
    })
    
    # Save stationarity results to Excel
    df_test_res = pd.DataFrame(test_results)
    # Check if tables.xlsx exists or write a new one
    try:
        wb = openpyxl.load_workbook("tables.xlsx")
    except FileNotFoundError:
        wb = openpyxl.Workbook()
        # Remove default sheet
        if 'Sheet' in wb.sheetnames:
            wb.remove(wb['Sheet'])
            
    if 'Stationarity' in wb.sheetnames:
        wb.remove(wb['Stationarity'])
    ws = wb.create_sheet('Stationarity')
    
    ws.append(['Variable', 'ADF Statistic', 'ADF p-value', 'PP Statistic', 'PP p-value', 'Stationary (p < 0.05)'])
    for row in test_results:
        ws.append([row['Variable'], row['ADF_Stat'], row['ADF_p'], row['PP_Stat'], row['PP_p'], row['Stationary']])
    wb.save("tables.xlsx")
    print("\nStationarity test results successfully saved to tables.xlsx.")

if __name__ == "__main__":
    main()
