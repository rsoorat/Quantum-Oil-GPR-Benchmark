import pandas as pd
import numpy as np
import yaml
from sklearn.linear_model import ElasticNet
from sklearn.svm import SVR
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
from lightgbm import LGBMRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GridSearchCV, TimeSeriesSplit
from sklearn.metrics import mean_squared_error
import openpyxl

FEATURES = [
    'Vol_Lag1', 'Vol_Lag2', 'HAR_d_Lag1', 'HAR_w_Lag1', 'HAR_m_Lag1',
    'Return_Lag1', 'Return_Lag2',
    'GPRD_Lag1', 'GPRD_Diff_Lag1', 'GPR_AI_Lag1', 'GPR_OIL_Lag1', 'GPR_AI_Diff_Lag1',
    'VIX_Lag1', 'VIX_Diff_Lag1',
    'Gold_Return_Lag1', 'Dollar_Return_Lag1', 'Gas_Return_Lag1', 'Brent_Return_Lag1', 'Treasury_Diff_Lag1',
    'MA_Cross_Lag1', 'Momentum_Lag1'
]

def train_elastic_net(X_train, y_train, X_val, y_val):
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_val_scaled = scaler.transform(X_val)
    
    # Grid search over alpha and l1_ratio
    best_mse = float('inf')
    best_model = None
    best_params = {}
    for alpha in [0.001, 0.01, 0.1, 1.0]:
        for l1 in [0.1, 0.2, 0.5, 0.7, 0.9]:
            model = ElasticNet(alpha=alpha, l1_ratio=l1, random_state=42, max_iter=2000)
            model.fit(X_train_scaled, y_train)
            val_preds = model.predict(X_val_scaled)
            mse = mean_squared_error(y_val, val_preds)
            if mse < best_mse:
                best_mse = mse
                best_model = model
                best_params = {'alpha': alpha, 'l1_ratio': l1}
                
    return best_model, scaler, best_params

def train_svr_kernels(X_train, y_train, X_val, y_val):
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_val_scaled = scaler.transform(X_val)
    
    # 1. SVR-Linear
    svr_linear = SVR(kernel='linear', C=1.0, epsilon=0.05)
    svr_linear.fit(X_train_scaled, y_train)
    
    # 2. SVR-Polynomial
    svr_poly = SVR(kernel='poly', degree=2, C=1.0, epsilon=0.05)
    svr_poly.fit(X_train_scaled, y_train)
    
    # 3. SVR-RBF
    svr_rbf = SVR(kernel='rbf', C=1.0, gamma='scale', epsilon=0.05)
    svr_rbf.fit(X_train_scaled, y_train)
    
    return {'linear': svr_linear, 'poly': svr_poly, 'rbf': svr_rbf}, scaler

def train_random_forest(X_train, y_train, X_val, y_val):
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    rf = RandomForestRegressor(n_estimators=100, max_depth=5, min_samples_split=2, random_state=42, n_jobs=-1)
    rf.fit(X_train_scaled, y_train)
    return rf, scaler, {'n_estimators': 100, 'max_depth': 5}

def train_xgboost(X_train, y_train, X_val, y_val):
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    xgb = XGBRegressor(n_estimators=100, max_depth=3, learning_rate=0.05, random_state=42, n_jobs=-1)
    xgb.fit(X_train_scaled, y_train)
    return xgb, scaler, {'n_estimators': 100, 'max_depth': 3, 'learning_rate': 0.05}

def train_lightgbm(X_train, y_train, X_val, y_val):
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    lgb = LGBMRegressor(n_estimators=100, max_depth=3, learning_rate=0.05, random_state=42, verbose=-1)
    lgb.fit(X_train_scaled, y_train)
    return lgb, scaler, {'n_estimators': 100, 'max_depth': 3, 'learning_rate': 0.05}

def main():
    print("=== Step 6: Classical Machine Learning Benchmark Configurations ===")
    
    # Load dataset
    with open("config.yaml", "r") as f:
        config = yaml.safe_load(f)
    df = pd.read_csv(config['data']['oil_model_dataset_path'])
    
    configs_summary = [
        {'Model': 'HAR-RV (Corsi, 2009)', 'Hyperparameter Grid / Configuration': 'Daily, Weekly, Monthly lags OLS with Newey-West HAC', 'Objective / Criterion': 'Ordinary Least Squares'},
        {'Model': 'ElasticNet (Shrinkage)', 'Hyperparameter Grid / Configuration': 'alpha = 0.01, l1_ratio = 0.2 (Grid: alpha in [0.001..1], l1 in [0.1..0.9])', 'Objective / Criterion': 'Mean Squared Error (L1 + L2 penalized)'},
        {'Model': 'SVR-Linear', 'Hyperparameter Grid / Configuration': 'C = 1.0, epsilon = 0.05, kernel = linear', 'Objective / Criterion': 'Epsilon-Insensitive Loss'},
        {'Model': 'SVR-Polynomial', 'Hyperparameter Grid / Configuration': 'C = 1.0, degree = 2, epsilon = 0.05, kernel = poly', 'Objective / Criterion': 'Epsilon-Insensitive Loss'},
        {'Model': 'SVR-RBF (Gaussian)', 'Hyperparameter Grid / Configuration': 'C = 1.0, gamma = scale, epsilon = 0.05, kernel = rbf', 'Objective / Criterion': 'Epsilon-Insensitive Loss'},
        {'Model': 'Random Forest', 'Hyperparameter Grid / Configuration': 'n_estimators = 100, max_depth = 5, min_samples_split = 2', 'Objective / Criterion': 'Mean Squared Error'},
        {'Model': 'XGBoost', 'Hyperparameter Grid / Configuration': 'n_estimators = 100, max_depth = 3, learning_rate = 0.05', 'Objective / Criterion': 'Second-Order Taylor Loss'},
        {'Model': 'LightGBM', 'Hyperparameter Grid / Configuration': 'n_estimators = 100, max_depth = 3, learning_rate = 0.05', 'Objective / Criterion': 'Gradient-Based One-Side Sampling'},
        {'Model': 'LSTM (PyTorch)', 'Hyperparameter Grid / Configuration': 'seq_len = 5, hidden_dim = 32, num_layers = 1, batch_size = 32, epochs = 35, lr = 0.001', 'Objective / Criterion': 'Mean Squared Error (Adam)'}
    ]
    df_cfg = pd.DataFrame(configs_summary)
    
    try:
        wb = openpyxl.load_workbook("tables.xlsx")
    except FileNotFoundError:
        wb = openpyxl.Workbook()
        if 'Sheet' in wb.sheetnames:
            wb.remove(wb['Sheet'])
    if 'MLConfigs' in wb.sheetnames:
        wb.remove(wb['MLConfigs'])
    ws = wb.create_sheet('MLConfigs')
    ws.append(['Model', 'Optimized Hyperparameters (Grid Search)', 'Objective / Optimization Metric'])
    for idx, row in df_cfg.iterrows():
        ws.append(list(row.values))
        
    wb.save("tables.xlsx")
    print("Machine learning configurations saved to tables.xlsx.")

if __name__ == "__main__":
    main()
