import pandas as pd
import numpy as np
import yaml
import openpyxl
from sklearn.metrics import mean_squared_error
import sys
import os
import importlib

script_dir = os.path.abspath(os.path.dirname(__file__))
if script_dir not in sys.path:
    sys.path.append(script_dir)

classical_ml = importlib.import_module("06_classical_ml")
quantum_model = importlib.import_module("08_quantum_model")

FEATURES = classical_ml.FEATURES

def permutation_importance_classical(model, scaler, X_test, y_test, features, n_repeats=5):
    X_test_scaled = scaler.transform(X_test)
    baseline_mse = mean_squared_error(y_test, model.predict(X_test_scaled))
    
    importances = {}
    for feat in features:
        feat_idx = features.index(feat)
        scores = []
        for _ in range(n_repeats):
            X_perm = X_test.copy()
            X_perm[feat] = np.random.permutation(X_perm[feat].values)
            X_perm_scaled = scaler.transform(X_perm)
            perm_mse = mean_squared_error(y_test, model.predict(X_perm_scaled))
            scores.append(perm_mse - baseline_mse)
        importances[feat] = max(0.0, float(np.mean(scores)))
        
    total = sum(importances.values())
    normalized = {k: (v / total if total > 0 else 0) for k, v in importances.items()}
    return importances, normalized

def permutation_importance_quantum(model, scaler, states_train, X_test, y_test, n_repeats=3):
    X_test_q = X_test[quantum_model.QUANTUM_FEATURES].values
    X_test_scaled = scaler.transform(X_test_q)
    states_test = quantum_model.compute_quantum_states(X_test_scaled)
    K_test = quantum_model.compute_quantum_kernel(states_test, states_train)
    baseline_mse = mean_squared_error(y_test, model.predict(K_test))
    
    importances = {}
    for idx, feat in enumerate(quantum_model.QUANTUM_FEATURES):
        scores = []
        for _ in range(n_repeats):
            X_perm = X_test_q.copy()
            X_perm[:, idx] = np.random.permutation(X_perm[:, idx])
            X_perm_scaled = scaler.transform(X_perm)
            states_perm = quantum_model.compute_quantum_states(X_perm_scaled)
            K_perm = quantum_model.compute_quantum_kernel(states_perm, states_train)
            perm_mse = mean_squared_error(y_test, model.predict(K_perm))
            scores.append(perm_mse - baseline_mse)
        importances[feat] = max(0.0, float(np.mean(scores)))
        
    total = sum(importances.values())
    normalized = {k: (v / total if total > 0 else 0) for k, v in importances.items()}
    return importances, normalized

def main():
    print("=== Step 11: Feature Importance and Sensitivity Analysis ===")
    
    with open("config.yaml", "r") as f:
        config = yaml.safe_load(f)
        
    df = pd.read_csv(config['data']['oil_model_dataset_path'])
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    
    date_train_end = pd.to_datetime("2022-12-31")
    date_val_end = pd.to_datetime("2023-12-31")
    
    df_train = df[df['date'] <= date_train_end].reset_index(drop=True)
    df_val = df[(df['date'] > date_train_end) & (df['date'] <= date_val_end)].reset_index(drop=True)
    df_test = df[df['date'] > date_val_end].reset_index(drop=True)
    
    X_train, y_train = df_train[FEATURES], df_train['Target_Vol'].values
    X_val, y_val = df_val[FEATURES], df_val['Target_Vol'].values
    X_test, y_test = df_test[FEATURES], df_test['Target_Vol'].values
    
    print("Training models for importance analysis...")
    en_model, en_scaler, _ = classical_ml.train_elastic_net(X_train, y_train, X_val, y_val)
    xgb_model, xgb_scaler, _ = classical_ml.train_xgboost(X_train, y_train, X_val, y_val)
    qsvr_model, qsvr_scaler, states_train = quantum_model.train_qsvr(X_train, y_train, X_val, y_val)
    
    print("Computing ElasticNet feature importances...")
    _, en_norm = permutation_importance_classical(en_model, en_scaler, X_test, y_test, FEATURES)
    
    print("Computing XGBoost feature importances...")
    _, xgb_norm = permutation_importance_classical(xgb_model, xgb_scaler, X_test, y_test, FEATURES)
    
    print("Computing QSVR feature sensitivities...")
    _, qsvr_norm = permutation_importance_quantum(qsvr_model, qsvr_scaler, states_train, X_test, y_test)
    
    print("\n--- XGBoost Feature Importances (Top 10) ---")
    sorted_xgb = sorted(xgb_norm.items(), key=lambda x: x[1], reverse=True)
    for k, v in sorted_xgb[:10]:
        print(f"  {k:20s}: {v:.4f}")
        
    print("\n--- QSVR Feature Sensitivities ---")
    sorted_qsvr = sorted(qsvr_norm.items(), key=lambda x: x[1], reverse=True)
    for k, v in sorted_qsvr:
        print(f"  {k:20s}: {v:.4f}")
        
    try:
        wb = openpyxl.load_workbook("tables.xlsx")
    except FileNotFoundError:
        wb = openpyxl.Workbook()
        if 'Sheet' in wb.sheetnames:
            wb.remove(wb['Sheet'])
    
    if 'FeatureImportance' in wb.sheetnames:
        wb.remove(wb['FeatureImportance'])
    ws_imp = wb.create_sheet('FeatureImportance')
    ws_imp.append(['Feature', 'XGBoost Normalized Importance', 'ElasticNet Normalized Importance'])
    for feat in FEATURES:
        ws_imp.append([feat, xgb_norm.get(feat, 0.0), en_norm.get(feat, 0.0)])
        
    if 'QuantumSensitivity' in wb.sheetnames:
        wb.remove(wb['QuantumSensitivity'])
    ws_q = wb.create_sheet('QuantumSensitivity')
    ws_q.append(['Quantum Feature Wire', 'Normalized Sensitivity (Fidelity Distortion)'])
    for k, v in sorted_qsvr:
        ws_q.append([k, v])
        
    wb.save("tables.xlsx")
    print("Feature importance tables saved to tables.xlsx.")

if __name__ == "__main__":
    main()
